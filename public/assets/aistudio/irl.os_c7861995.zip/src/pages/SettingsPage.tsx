import React, { useState } from 'react';
import {
  Settings,
  Clock,
  Sparkles,
  Download,
  Trash2,
  RotateCcw,
  Shield,
  ToggleLeft,
  ToggleRight,
  Check,
  LayoutGrid,
  LogOut,
  User,
  ShieldCheck,
  Mail,
  Fingerprint,
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { useAuth } from '../context/AuthContext.tsx';

interface SettingsPageProps {
  onNavigate: (path: string) => void;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({ onNavigate }) => {
  const {
    userStats,
    updateUserStats,
    hasAiConfigured,
    resetToDemoData,
    loadStarterTemplate,
    setShowReferenceModal,
    tasks,
    goals,
    xpLedger,
  } = useApp();
  const { user, userProfile, updateDisplayName, signOut } = useAuth();

  const [savedAlert, setSavedAlert] = useState(false);
  const [editingName, setEditingName] = useState(false);
  const [nameValue, setNameValue] = useState(userProfile?.displayName || userStats.displayName);

  const handleToggleGamification = () => {
    updateUserStats({ gamificationEnabled: !userStats.gamificationEnabled });
    setSavedAlert(true);
    setTimeout(() => setSavedAlert(false), 2500);
  };

  const handleUpdateDefaultMinutes = (minutes: number) => {
    updateUserStats({ defaultAvailabilityMinutes: minutes });
    setSavedAlert(true);
    setTimeout(() => setSavedAlert(false), 2500);
  };

  const handleSaveDisplayName = async (e: React.FormEvent) => {
    e.preventDefault();
    if (nameValue.trim()) {
      if (user) {
        await updateDisplayName(nameValue.trim());
      }
      updateUserStats({ displayName: nameValue.trim() });
      setEditingName(false);
      setSavedAlert(true);
      setTimeout(() => setSavedAlert(false), 2500);
    }
  };

  const handleExportAllData = () => {
    const backup = {
      exportTimestamp: new Date().toISOString(),
      user: {
        uid: user?.uid,
        email: user?.email,
        displayName: userProfile?.displayName || userStats.displayName,
      },
      userStats,
      goals,
      tasks,
      xpLedger,
    };
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(backup, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `irl_os_private_backup_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleSignOut = async () => {
    try {
      await signOut();
      onNavigate('/signin');
    } catch (err) {
      console.error('Sign out error:', err);
    }
  };

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="pb-2 border-b border-[#252B3B] flex items-center justify-between">
        <div>
          <div className="text-xs font-mono text-[#A78BFA] uppercase tracking-wider font-semibold">
            System Preferences
          </div>
          <h2 className="text-2xl font-extrabold text-[#F4F5FA] tracking-tight mt-0.5">
            Application Settings
          </h2>
          <p className="text-xs text-[#939BB0] mt-1">
            Configure availability defaults, gamification mode, private account settings, and data exports.
          </p>
        </div>

        {savedAlert && (
          <span className="text-xs font-mono text-[#4ADE80] flex items-center gap-1 animate-in fade-in">
            <Check size={14} />
            <span>Preferences Saved</span>
          </span>
        )}
      </div>

      {/* Account Settings */}
      <div className="p-6 rounded-2xl bg-[#121622] border border-[#252B3B] space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-[#252B3B]">
          <div className="flex items-center gap-2">
            <User size={16} className="text-cyan-400" />
            <h3 className="text-sm font-bold text-[#F4F5FA]">Account Credentials & Display Name</h3>
          </div>
          <button
            onClick={handleSignOut}
            className="px-3 py-1 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <LogOut size={13} />
            <span>Sign Out</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-mono uppercase text-[#939BB0] mb-1.5">
              Operator Display Name
            </label>
            {editingName ? (
              <form onSubmit={handleSaveDisplayName} className="flex items-center gap-2">
                <input
                  type="text"
                  value={nameValue}
                  onChange={(e) => setNameValue(e.target.value)}
                  className="px-3 py-1.5 rounded-lg bg-[#090A0F] border border-cyan-400 text-sm text-[#F4F5FA] outline-none font-medium flex-1"
                />
                <button
                  type="submit"
                  className="px-3 py-1.5 rounded-lg bg-cyan-400 text-black text-xs font-bold"
                >
                  Save
                </button>
                <button
                  type="button"
                  onClick={() => setEditingName(false)}
                  className="text-xs text-white/50 hover:text-white"
                >
                  Cancel
                </button>
              </form>
            ) : (
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-black/40 border border-white/5">
                <span className="text-sm font-semibold text-white">
                  {userProfile?.displayName || userStats.displayName}
                </span>
                <button
                  onClick={() => {
                    setNameValue(userProfile?.displayName || userStats.displayName);
                    setEditingName(true);
                  }}
                  className="text-xs text-cyan-400 hover:text-cyan-300 font-medium"
                >
                  Change Name
                </button>
              </div>
            )}
          </div>

          <div>
            <label className="block text-xs font-mono uppercase text-[#939BB0] mb-1.5">
              Account Email
            </label>
            <div className="p-2.5 rounded-xl bg-black/40 border border-white/5 text-sm font-mono text-white/70 truncate flex items-center gap-2">
              <Mail size={14} className="text-violet-400 shrink-0" />
              <span className="truncate">{user?.email || userProfile?.email || 'sixtynine9491@gmail.com'}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Planning & Capacity Settings */}
      <div className="p-6 rounded-2xl bg-[#121622] border border-[#252B3B] space-y-4">
        <div className="flex items-center gap-2 pb-2 border-b border-[#252B3B]">
          <Clock size={16} className="text-[#67E8F9]" />
          <h3 className="text-sm font-bold text-[#F4F5FA]">Daily Availability & Planning Defaults</h3>
        </div>

        <div>
          <label className="block text-xs font-mono uppercase text-[#939BB0] mb-2">
            Default Daily Available Window
          </label>
          <div className="flex items-center gap-3">
            {[90, 120, 180, 240, 300].map((mins) => (
              <button
                key={mins}
                onClick={() => handleUpdateDefaultMinutes(mins)}
                className={`px-3 py-1.5 rounded-xl text-xs font-mono border transition-all ${
                  userStats.defaultAvailabilityMinutes === mins
                    ? 'bg-[#A78BFA] text-black font-bold border-[#A78BFA]'
                    : 'bg-[#090A0F] text-[#939BB0] border-[#252B3B] hover:text-[#F4F5FA]'
                }`}
              >
                {mins} mins ({Math.floor(mins / 60)}h {mins % 60 ? `${mins % 60}m` : ''})
              </button>
            ))}
          </div>
          <p className="text-[11px] text-[#939BB0] mt-2">
            The Reality Check dial automatically evaluates planned task minutes against this baseline unless overridden on a specific date.
          </p>
        </div>
      </div>

      {/* Gamification Progression Settings */}
      <div className="p-6 rounded-2xl bg-[#121622] border border-[#252B3B] space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-[#252B3B]">
          <div className="flex items-center gap-2">
            <Shield size={16} className="text-[#A78BFA]" />
            <h3 className="text-sm font-bold text-[#F4F5FA]">RPG Progression & Player HUD</h3>
          </div>
          <button
            onClick={handleToggleGamification}
            className="flex items-center gap-1 text-sm font-semibold text-[#A78BFA]"
          >
            {userStats.gamificationEnabled ? (
              <ToggleRight size={28} className="text-[#A78BFA]" />
            ) : (
              <ToggleLeft size={28} className="text-[#939BB0]" />
            )}
          </button>
        </div>

        <p className="text-xs text-[#939BB0] leading-relaxed">
          When enabled, completing tasks earns XP and increments operator levels and titles. If disabled,
          the player level bar and XP indicators are hidden across the entire application while retaining
          full productivity workflows.
        </p>
      </div>

      {/* AI Advisor Configuration Status */}
      <div className="p-6 rounded-2xl bg-[#121622] border border-[#252B3B] space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-[#252B3B]">
          <div className="flex items-center gap-2">
            <Sparkles size={16} className="text-[#C084FC]" />
            <h3 className="text-sm font-bold text-[#F4F5FA]">Gemini AI Integration Status</h3>
          </div>
          <span
            className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold border ${
              hasAiConfigured
                ? 'bg-[#A78BFA]/20 text-[#A78BFA] border-[#A78BFA]/40'
                : 'bg-[#181D2B] text-[#939BB0] border-[#252B3B]'
            }`}
          >
            {hasAiConfigured ? 'CONNECTED' : 'STANDBY'}
          </span>
        </div>

        <p className="text-xs text-[#939BB0] leading-relaxed">
          {hasAiConfigured
            ? 'Gemini 3.8 Flash is active via server-side configuration. The AI Perspective uses your real stored records to offer objective advice and adaptive replanning.'
            : 'Gemini is running in deterministic mode. Set your GEMINI_API_KEY securely in the AI Studio Secrets panel to enable live intelligent recommendations.'}
        </p>
      </div>

      {/* Visual Reference Spec Board */}
      <div className="p-6 rounded-2xl bg-[#121622] border border-[#252B3B] space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-[#252B3B]">
          <div className="flex items-center gap-2">
            <LayoutGrid size={16} className="text-[#67E8F9]" />
            <h3 className="text-sm font-bold text-[#F4F5FA]">Multi-Page UI Design Reference Board</h3>
          </div>
          <button
            onClick={() => setShowReferenceModal(true)}
            className="px-3 py-1.5 rounded-lg bg-[#181D2B] hover:bg-[#252B3B] text-xs font-semibold text-[#67E8F9] border border-[#67E8F9]/30 transition-colors"
          >
            Inspect Reference Board
          </button>
        </div>
        <p className="text-xs text-[#939BB0]">
          View the high-fidelity multi-screen design specification contact sheet generated for the IRL.OS system.
        </p>
      </div>

      {/* Data Management & Backup */}
      <div className="p-6 rounded-2xl bg-[#121622] border border-[#252B3B] space-y-4">
        <div className="pb-2 border-b border-[#252B3B]">
          <h3 className="text-sm font-bold text-[#F4F5FA]">Data Storage & Template Controls</h3>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={handleExportAllData}
            className="px-4 py-2 rounded-xl bg-[#181D2B] hover:bg-[#252B3B] text-xs font-semibold text-[#F4F5FA] border border-[#252B3B] flex items-center gap-2 transition-colors cursor-pointer"
          >
            <Download size={14} className="text-[#67E8F9]" />
            <span>Export Complete JSON Backup</span>
          </button>

          {goals.length === 0 && tasks.length === 0 && (
            <button
              onClick={() => {
                loadStarterTemplate();
                setSavedAlert(true);
                setTimeout(() => setSavedAlert(false), 2500);
              }}
              className="px-4 py-2 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 text-cyan-300 border border-cyan-500/30 text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer"
            >
              <RotateCcw size={14} />
              <span>Load Starter Template Goals</span>
            </button>
          )}

          <button
            onClick={handleSignOut}
            className="px-4 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 text-xs font-semibold flex items-center gap-2 transition-colors ml-auto cursor-pointer"
          >
            <LogOut size={14} />
            <span>Sign Out of IRL.OS</span>
          </button>
        </div>
      </div>
    </div>
  );
};
