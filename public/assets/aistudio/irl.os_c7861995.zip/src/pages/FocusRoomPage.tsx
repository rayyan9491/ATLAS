import React, { useState } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  CheckCircle2,
  Clock,
  Target,
  Sparkles,
  ArrowRight,
  ChevronDown,
  Volume2,
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { Task } from '../types/index.ts';

interface FocusRoomPageProps {
  onNavigate: (path: string) => void;
}

export const FocusRoomPage: React.FC<FocusRoomPageProps> = ({ onNavigate }) => {
  const {
    tasks,
    goals,
    activeFocusTask,
    setActiveFocusTask,
    focusTimer,
    setFocusTimer,
    finishFocusSession,
    toggleTaskComplete,
  } = useApp();

  const [soundscape, setSoundscape] = useState<string>('Binaural Gamma 40Hz');
  const [sessionNotes, setSessionNotes] = useState('');

  // Fallback if no task selected
  const task =
    activeFocusTask ||
    tasks.find((t) => t.status !== 'completed' && t.slot === 'focus_now') ||
    tasks[0];

  const parentGoal = task?.goalId ? goals.find((g) => g.id === task.goalId) : null;

  // Calculate timer values
  const totalTargetSeconds = (focusTimer.targetMinutes || 45) * 60;
  const remainingSeconds = Math.max(0, totalTargetSeconds - focusTimer.secondsElapsed);

  const displayMinutes = Math.floor(remainingSeconds / 60)
    .toString()
    .padStart(2, '0');
  const displaySeconds = (remainingSeconds % 60).toString().padStart(2, '0');

  const elapsedMinutes = Math.floor(focusTimer.secondsElapsed / 60);

  const handleToggleTimer = () => {
    setFocusTimer((prev) => ({
      ...prev,
      isRunning: !prev.isRunning,
    }));
  };

  const handleResetTimer = () => {
    setFocusTimer((prev) => ({
      ...prev,
      isRunning: false,
      secondsElapsed: 0,
    }));
  };

  const handleFinishSession = () => {
    if (!task) return;
    const minsToRecord = Math.max(1, Math.round(focusTimer.secondsElapsed / 60));
    finishFocusSession(task.id, minsToRecord);
    alert(`Focus session recorded: ${minsToRecord} minutes logged towards "${task.title}".`);
  };

  const handleCompleteTask = () => {
    if (!task) return;
    toggleTaskComplete(task.id);
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] p-6 flex flex-col items-center justify-center max-w-4xl mx-auto relative">
      {/* Ambient background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[350px] bg-gradient-to-tr from-[#A78BFA]/10 to-[#67E8F9]/10 rounded-full blur-3xl pointer-events-none" />

      {/* Task Switcher dropdown / bar */}
      <div className="w-full max-w-lg mb-8 relative z-10">
        <label className="block text-[10px] font-mono uppercase text-[#A78BFA] mb-1.5 text-center">
          ACTIVE DEEP WORK OBJECTIVE
        </label>
        <select
          value={task?.id || ''}
          onChange={(e) => {
            const found = tasks.find((t) => t.id === e.target.value);
            if (found) {
              setActiveFocusTask(found);
              setFocusTimer((prev) => ({
                ...prev,
                activeTaskId: found.id,
                targetMinutes: found.estimatedMinutes || 45,
                secondsElapsed: 0,
              }));
            }
          }}
          className="w-full px-4 py-3 rounded-2xl bg-[#121622] border border-[#252B3B] text-sm font-bold text-[#F4F5FA] text-center focus:border-[#A78BFA] outline-none shadow-xl cursor-pointer"
        >
          {tasks
            .filter((t) => t.status !== 'completed')
            .map((t) => (
              <option key={t.id} value={t.id}>
                {t.title} ({t.estimatedMinutes}m)
              </option>
            ))}
        </select>
      </div>

      {/* Main Focus Room Hub */}
      <div className="w-full max-w-lg p-8 rounded-3xl bg-[#0D1018]/90 border border-[#252B3B] shadow-2xl relative z-10 flex flex-col items-center text-center">
        {/* Goal context */}
        {parentGoal && (
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#181D2B] border border-[#252B3B] text-xs font-medium text-[#A78BFA] mb-4">
            <Target size={13} />
            <span>Advancing Goal: {parentGoal.title}</span>
          </div>
        )}

        <h2 className="text-xl font-bold text-[#F4F5FA] tracking-tight">{task?.title}</h2>
        {task?.description && (
          <p className="text-xs text-[#939BB0] mt-2 max-w-md">{task.description}</p>
        )}

        {/* Large Digital Mono Timer */}
        <div className="my-10 relative">
          <div className="text-7xl sm:text-8xl font-mono font-black tracking-tight text-[#F4F5FA] drop-shadow-[0_0_25px_rgba(167,139,250,0.35)] select-none">
            {displayMinutes}:{displaySeconds}
          </div>
          <div className="flex items-center justify-center gap-2 mt-2 text-xs font-mono text-[#67E8F9]">
            <Clock size={13} />
            <span>
              {focusTimer.isRunning
                ? 'Session in Progress • Focus Locked'
                : 'Paused • Ready when you are'}
            </span>
          </div>
        </div>

        {/* Timer Control Buttons */}
        <div className="flex items-center gap-4 mb-6">
          <button
            onClick={handleToggleTimer}
            className={`px-8 py-3.5 rounded-2xl font-bold text-sm flex items-center gap-2 shadow-xl active:scale-95 transition-all ${
              focusTimer.isRunning
                ? 'bg-[#181D2B] text-[#F4F5FA] border border-[#252B3B] hover:bg-[#252B3B]'
                : 'bg-gradient-to-r from-[#A78BFA] to-[#8B5CF6] text-black shadow-violet-500/25 hover:opacity-95'
            }`}
          >
            {focusTimer.isRunning ? (
              <>
                <Pause size={16} fill="currentColor" />
                <span>Pause Timer</span>
              </>
            ) : (
              <>
                <Play size={16} fill="currentColor" />
                <span>{focusTimer.secondsElapsed > 0 ? 'Resume Timer' : 'Start Focus Session'}</span>
              </>
            )}
          </button>

          <button
            onClick={handleResetTimer}
            className="p-3.5 rounded-2xl bg-[#121622] hover:bg-[#181D2B] text-[#939BB0] hover:text-[#F4F5FA] border border-[#252B3B] transition-colors"
            title="Reset timer to 0"
          >
            <RotateCcw size={16} />
          </button>
        </div>

        {/* Preset Duration Buttons */}
        <div className="flex items-center gap-2 mb-6">
          <span className="text-[11px] font-mono text-[#939BB0]">Duration:</span>
          {[25, 45, 60, 90].map((mins) => (
            <button
              key={mins}
              onClick={() => {
                setFocusTimer((prev) => ({
                  ...prev,
                  targetMinutes: mins,
                  secondsElapsed: 0,
                  isRunning: false,
                }));
              }}
              className={`px-2.5 py-1 rounded-lg text-xs font-mono transition-colors ${
                focusTimer.targetMinutes === mins
                  ? 'bg-[#A78BFA] text-black font-bold'
                  : 'bg-[#121622] text-[#939BB0] hover:text-[#F4F5FA]'
              }`}
            >
              {mins}m
            </button>
          ))}
        </div>

        {/* Soundscape & notes bar */}
        <div className="w-full pt-4 border-t border-[#252B3B] flex items-center justify-between text-xs text-[#939BB0]">
          <div className="flex items-center gap-1.5">
            <Volume2 size={13} className="text-[#67E8F9]" />
            <select
              value={soundscape}
              onChange={(e) => setSoundscape(e.target.value)}
              className="bg-transparent text-[#67E8F9] outline-none text-xs cursor-pointer font-mono"
            >
              <option value="Binaural Gamma 40Hz" className="bg-[#090A0F]">
                Binaural 40Hz Flow
              </option>
              <option value="Deep Rain & Storm" className="bg-[#090A0F]">
                Deep Rain & Storm
              </option>
              <option value="Brown Noise Engine" className="bg-[#090A0F]">
                Brown Noise Engine
              </option>
              <option value="Silent Isolation" className="bg-[#090A0F]">
                Silent Isolation
              </option>
            </select>
          </div>

          <div className="font-mono text-[#F4F5FA]">Logged: {elapsedMinutes}m</div>
        </div>
      </div>

      {/* Completion & Record Bar */}
      <div className="w-full max-w-lg mt-4 flex items-center justify-between gap-3 relative z-10">
        <button
          onClick={handleFinishSession}
          disabled={focusTimer.secondsElapsed < 10}
          className="flex-1 py-2.5 rounded-xl bg-[#121622] hover:bg-[#181D2B] text-xs font-semibold text-[#67E8F9] border border-[#67E8F9]/30 transition-colors disabled:opacity-40"
        >
          Log {elapsedMinutes}m Time to Task
        </button>

        <button
          onClick={handleCompleteTask}
          className="flex-1 py-2.5 rounded-xl bg-[#181D2B] hover:bg-[#252B3B] text-xs font-semibold text-[#4ADE80] border border-[#4ADE80]/30 transition-colors flex items-center justify-center gap-1.5"
        >
          <CheckCircle2 size={14} />
          <span>Mark Task Finished</span>
        </button>
      </div>
    </div>
  );
};
