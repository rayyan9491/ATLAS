import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import {
  collection,
  doc,
  setDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
} from 'firebase/firestore';
import { Goal, Milestone, Task, UserStats, XpLedgerEntry } from '../types/index.ts';
import { INITIAL_GOALS, INITIAL_TASKS, INITIAL_USER_STATS, INITIAL_XP_LEDGER } from '../data/seed.ts';
import { awardTaskCompletionXp } from '../utils/progression.ts';
import { db } from '../lib/firebase.ts';
import { useAuth } from './AuthContext.tsx';

interface AppContextType {
  userStats: UserStats;
  updateUserStats: (updater: Partial<UserStats>) => void;
  goals: Goal[];
  createGoal: (goal: Omit<Goal, 'id' | 'createdAt' | 'milestones'>, initialMilestones?: string[]) => Goal;
  updateGoal: (id: string, updates: Partial<Goal>) => void;
  deleteGoal: (id: string) => void;
  addMilestone: (goalId: string, title: string, criteria?: string) => void;
  toggleMilestone: (goalId: string, milestoneId: string) => void;
  tasks: Task[];
  createTask: (task: Omit<Task, 'id' | 'createdAt' | 'xpReward'>) => Task;
  updateTask: (id: string, updates: Partial<Task>) => void;
  deleteTask: (id: string) => void;
  toggleTaskComplete: (id: string) => void;
  rescheduleTask: (id: string, newDate: string, newSlot?: Task['slot']) => void;
  applyReplan: (keptIds: string[], deferred: { taskId: string; newDate: string }[]) => void;
  todayDate: string;
  setTodayDate: (d: string) => void;
  xpLedger: XpLedgerEntry[];
  activeFocusTask: Task | null;
  setActiveFocusTask: (task: Task | null) => void;
  focusTimer: {
    isRunning: boolean;
    secondsElapsed: number;
    targetMinutes: number;
    activeTaskId: string | null;
  };
  setFocusTimer: React.Dispatch<
    React.SetStateAction<{
      isRunning: boolean;
      secondsElapsed: number;
      targetMinutes: number;
      activeTaskId: string | null;
    }>
  >;
  finishFocusSession: (taskId: string, recordedMinutes: number) => void;
  resetToDemoData: () => void;
  loadStarterTemplate: () => void;
  hasAiConfigured: boolean;
  showReferenceModal: boolean;
  setShowReferenceModal: (show: boolean) => void;
  isSyncing: boolean;
}

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, userProfile } = useAuth();

  const [todayDate, setTodayDate] = useState<string>(() => {
    return new Date().toISOString().split('T')[0];
  });
  const [showReferenceModal, setShowReferenceModal] = useState<boolean>(false);
  const [hasAiConfigured, setHasAiConfigured] = useState<boolean>(false);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);

  // User-scoped private state
  const [userStats, setUserStats] = useState<UserStats>(INITIAL_USER_STATS);
  const [goals, setGoals] = useState<Goal[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [xpLedger, setXpLedger] = useState<XpLedgerEntry[]>([]);

  // Focus room timer state
  const [activeFocusTask, setActiveFocusTask] = useState<Task | null>(null);
  const [focusTimer, setFocusTimer] = useState<{
    isRunning: boolean;
    secondsElapsed: number;
    targetMinutes: number;
    activeTaskId: string | null;
  }>({
    isRunning: false,
    secondsElapsed: 0,
    targetMinutes: 45,
    activeTaskId: null,
  });

  // Track current user UID to ensure instant flush on logout/switching
  const currentUidRef = useRef<string | null>(null);

  // Check server AI status
  useEffect(() => {
    fetch('/api/status')
      .then((r) => r.json())
      .then((data) => {
        if (data && data.hasGeminiKey) {
          setHasAiConfigured(true);
        }
      })
      .catch(() => {
        setHasAiConfigured(false);
      });
  }, []);

  // Sync user profile data to userStats whenever userProfile changes
  useEffect(() => {
    if (userProfile) {
      setUserStats((prev) => ({
        ...prev,
        displayName: userProfile.displayName || prev.displayName,
        title: userProfile.roleTitle || prev.title,
        gamificationEnabled:
          userProfile.gamificationEnabled !== undefined
            ? userProfile.gamificationEnabled
            : prev.gamificationEnabled,
        defaultAvailabilityMinutes:
          userProfile.defaultAvailabilityMinutes || prev.defaultAvailabilityMinutes,
        dailyAvailability: userProfile.dailyAvailability || prev.dailyAvailability || {},
        autoReplanWithAi:
          userProfile.autoReplanWithAi !== undefined
            ? userProfile.autoReplanWithAi
            : prev.autoReplanWithAi,
      }));
    }
  }, [userProfile]);

  // Firestore real-time subscriptions for the authenticated user's private data
  useEffect(() => {
    const uid = user?.uid;

    if (!uid) {
      // User signed out -> IMMEDIATELY purge all private user data from memory!
      currentUidRef.current = null;
      setGoals([]);
      setTasks([]);
      setXpLedger([]);
      setUserStats(INITIAL_USER_STATS);
      setActiveFocusTask(null);
      setFocusTimer({
        isRunning: false,
        secondsElapsed: 0,
        targetMinutes: 45,
        activeTaskId: null,
      });
      return;
    }

    // New user signed in
    if (currentUidRef.current !== uid) {
      // Clear any previous user's cached in-memory state
      setGoals([]);
      setTasks([]);
      setXpLedger([]);
      setActiveFocusTask(null);
      currentUidRef.current = uid;
    }

    setIsSyncing(true);

    // 1. Subscribe to /users/{uid}/goals
    const goalsCol = collection(db, 'users', uid, 'goals');
    const unsubGoals = onSnapshot(
      goalsCol,
      (snapshot) => {
        const loadedGoals: Goal[] = [];
        snapshot.forEach((docSnap) => {
          loadedGoals.push({ id: docSnap.id, ...(docSnap.data() as any) });
        });
        // Sort newest first or by deadline
        loadedGoals.sort(
          (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );
        setGoals(loadedGoals);
        setIsSyncing(false);
      },
      (err) => {
        console.warn('Goals sync subscription error:', err);
        setIsSyncing(false);
      }
    );

    // 2. Subscribe to /users/{uid}/tasks
    const tasksCol = collection(db, 'users', uid, 'tasks');
    const unsubTasks = onSnapshot(
      tasksCol,
      (snapshot) => {
        const loadedTasks: Task[] = [];
        snapshot.forEach((docSnap) => {
          loadedTasks.push({ id: docSnap.id, ...(docSnap.data() as any) });
        });
        // Sort by scheduled date
        loadedTasks.sort(
          (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );
        setTasks(loadedTasks);

        // Auto-assign active focus task if none active
        setActiveFocusTask((current) => {
          if (current && loadedTasks.some((t) => t.id === current.id)) {
            return loadedTasks.find((t) => t.id === current.id) || current;
          }
          const focusNow = loadedTasks.find((t) => t.slot === 'focus_now' && t.status !== 'completed');
          return focusNow || loadedTasks.find((t) => t.status !== 'completed') || loadedTasks[0] || null;
        });
      },
      (err) => {
        console.warn('Tasks sync subscription error:', err);
      }
    );

    // 3. Subscribe to /users/{uid}/xp_ledger
    const xpCol = collection(db, 'users', uid, 'xp_ledger');
    const unsubXp = onSnapshot(
      xpCol,
      (snapshot) => {
        const loadedXp: XpLedgerEntry[] = [];
        snapshot.forEach((docSnap) => {
          loadedXp.push({ id: docSnap.id, ...(docSnap.data() as any) });
        });
        loadedXp.sort(
          (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
        );
        setXpLedger(loadedXp);

        // Calculate dynamic level & xp
        const totalXp = loadedXp.reduce((acc, entry) => acc + (entry.xpAwarded || 0), 0);
        const calcLevel = Math.max(1, Math.floor(totalXp / 300) + 1);
        setUserStats((prev) => ({
          ...prev,
          xp: totalXp,
          level: calcLevel,
        }));
      },
      (err) => {
        console.warn('XP ledger sync subscription error:', err);
      }
    );

    return () => {
      unsubGoals();
      unsubTasks();
      unsubXp();
    };
  }, [user]);

  // Timer interval with elapsed calculation
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (focusTimer.isRunning) {
      interval = setInterval(() => {
        setFocusTimer((prev) => ({
          ...prev,
          secondsElapsed: prev.secondsElapsed + 1,
        }));
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [focusTimer.isRunning]);

  const updateUserStats = (updater: Partial<UserStats>) => {
    setUserStats((prev) => {
      const next = { ...prev, ...updater };
      // If user is authenticated, persist relevant stats in Firestore user doc
      if (user) {
        const userDocRef = doc(db, 'users', user.uid);
        updateDoc(userDocRef, {
          ...(updater.defaultAvailabilityMinutes !== undefined && {
            defaultAvailabilityMinutes: next.defaultAvailabilityMinutes,
          }),
          ...(updater.gamificationEnabled !== undefined && {
            gamificationEnabled: next.gamificationEnabled,
          }),
          ...(updater.autoReplanWithAi !== undefined && {
            autoReplanWithAi: next.autoReplanWithAi,
          }),
          ...(updater.dailyAvailability !== undefined && {
            dailyAvailability: next.dailyAvailability,
          }),
          ...(updater.displayName !== undefined && {
            displayName: next.displayName,
          }),
          ...(updater.title !== undefined && {
            roleTitle: next.title,
          }),
        }).catch((e) => console.warn('Could not sync user stats to Firestore:', e));
      }
      return next;
    });
  };

  const createGoal = (
    goalData: Omit<Goal, 'id' | 'createdAt' | 'milestones'>,
    initialMilestones: string[] = []
  ): Goal => {
    const id = `goal-${Date.now()}`;
    const milestones: Milestone[] = initialMilestones.map((title, idx) => ({
      id: `m-${id}-${idx + 1}`,
      goalId: id,
      title,
      order: idx + 1,
      status: idx === 0 ? 'in_progress' : 'locked',
    }));

    const newGoal: Goal = {
      ...goalData,
      id,
      createdAt: new Date().toISOString(),
      milestones,
    };

    // Optimistic update
    setGoals((prev) => [newGoal, ...prev]);

    // Persist to user's private Firestore subcollection
    if (user) {
      const goalDocRef = doc(db, 'users', user.uid, 'goals', id);
      setDoc(goalDocRef, { ...newGoal, userId: user.uid }).catch((e) =>
        console.error('Failed to save goal to Firestore:', e)
      );
    }

    return newGoal;
  };

  const updateGoal = (id: string, updates: Partial<Goal>) => {
    setGoals((prev) => prev.map((g) => (g.id === id ? { ...g, ...updates } : g)));

    if (user) {
      const goalDocRef = doc(db, 'users', user.uid, 'goals', id);
      updateDoc(goalDocRef, updates).catch((e) =>
        console.error('Failed to update goal in Firestore:', e)
      );
    }
  };

  const deleteGoal = (id: string) => {
    setGoals((prev) => prev.filter((g) => g.id !== id));
    setTasks((prev) => prev.map((t) => (t.goalId === id ? { ...t, goalId: undefined } : t)));

    if (user) {
      const goalDocRef = doc(db, 'users', user.uid, 'goals', id);
      deleteDoc(goalDocRef).catch((e) =>
        console.error('Failed to delete goal in Firestore:', e)
      );
    }
  };

  const addMilestone = (goalId: string, title: string, criteria?: string) => {
    setGoals((prev) =>
      prev.map((g) => {
        if (g.id !== goalId) return g;
        const newMilestone: Milestone = {
          id: `m-${goalId}-${Date.now()}`,
          goalId,
          title,
          order: g.milestones.length + 1,
          status: 'in_progress',
          criteria,
        };
        const updatedGoal = { ...g, milestones: [...g.milestones, newMilestone] };

        if (user) {
          const goalDocRef = doc(db, 'users', user.uid, 'goals', goalId);
          updateDoc(goalDocRef, { milestones: updatedGoal.milestones }).catch((e) =>
            console.error('Failed to add milestone in Firestore:', e)
          );
        }

        return updatedGoal;
      })
    );
  };

  const toggleMilestone = (goalId: string, milestoneId: string) => {
    setGoals((prev) =>
      prev.map((g) => {
        if (g.id !== goalId) return g;
        const updatedMilestones = g.milestones.map((m) => {
          if (m.id !== milestoneId) return m;
          const isNowCompleted = m.status !== 'completed';
          return {
            ...m,
            status: isNowCompleted ? ('completed' as const) : ('in_progress' as const),
            completedAt: isNowCompleted ? new Date().toISOString() : undefined,
          };
        });

        if (user) {
          const goalDocRef = doc(db, 'users', user.uid, 'goals', goalId);
          updateDoc(goalDocRef, { milestones: updatedMilestones }).catch((e) =>
            console.error('Failed to update milestone in Firestore:', e)
          );
        }

        return { ...g, milestones: updatedMilestones };
      })
    );
  };

  const createTask = (taskData: Omit<Task, 'id' | 'createdAt' | 'xpReward'>): Task => {
    const id = `task-${Date.now()}`;
    const estimatedMinutes = taskData.estimatedMinutes || 30;
    const newTask: Task = {
      ...taskData,
      id,
      estimatedMinutes,
      xpReward: Math.round(estimatedMinutes * 1.5),
      createdAt: new Date().toISOString(),
    };

    setTasks((prev) => [newTask, ...prev]);

    if (user) {
      const taskDocRef = doc(db, 'users', user.uid, 'tasks', id);
      setDoc(taskDocRef, { ...newTask, userId: user.uid }).catch((e) =>
        console.error('Failed to save task to Firestore:', e)
      );
    }

    return newTask;
  };

  const updateTask = (id: string, updates: Partial<Task>) => {
    setTasks((prev) => prev.map((t) => (t.id === id ? { ...t, ...updates } : t)));

    if (user) {
      const taskDocRef = doc(db, 'users', user.uid, 'tasks', id);
      updateDoc(taskDocRef, updates).catch((e) =>
        console.error('Failed to update task in Firestore:', e)
      );
    }
  };

  const deleteTask = (id: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== id));

    if (user) {
      const taskDocRef = doc(db, 'users', user.uid, 'tasks', id);
      deleteDoc(taskDocRef).catch((e) =>
        console.error('Failed to delete task in Firestore:', e)
      );
    }
  };

  const toggleTaskComplete = (id: string) => {
    setTasks((prev) => {
      return prev.map((task) => {
        if (task.id !== id) return task;
        const isNowCompleted = task.status !== 'completed';

        if (isNowCompleted) {
          // Award XP deterministically if gamification enabled
          if (userStats.gamificationEnabled) {
            const result = awardTaskCompletionXp(userStats.xp, xpLedger, task);
            if (!result.alreadyAwarded && result.newLedgerEntry) {
              const newEntry = result.newLedgerEntry;
              setXpLedger((l) => [newEntry, ...l]);
              setUserStats((s) => ({
                ...s,
                xp: result.newTotalXp,
                level: result.newLevel,
                title: result.newTitle,
              }));

              if (user) {
                const xpDocRef = doc(db, 'users', user.uid, 'xp_ledger', newEntry.id);
                setDoc(xpDocRef, { ...newEntry, userId: user.uid }).catch(console.warn);
              }
            }
          }

          const completedTask: Task = {
            ...task,
            status: 'completed',
            slot: 'completed',
            completedAt: new Date().toISOString(),
          };

          if (user) {
            const taskDocRef = doc(db, 'users', user.uid, 'tasks', id);
            updateDoc(taskDocRef, {
              status: 'completed',
              slot: 'completed',
              completedAt: completedTask.completedAt,
            }).catch(console.warn);
          }

          return completedTask;
        } else {
          // Undo completion
          const uncompletedTask: Task = {
            ...task,
            status: 'todo',
            slot: 'up_next',
            completedAt: undefined,
          };

          if (user) {
            const taskDocRef = doc(db, 'users', user.uid, 'tasks', id);
            updateDoc(taskDocRef, {
              status: 'todo',
              slot: 'up_next',
              completedAt: null as any,
            }).catch(console.warn);
          }

          return uncompletedTask;
        }
      });
    });
  };

  const rescheduleTask = (id: string, newDate: string, newSlot?: Task['slot']) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id !== id) return t;
        const updated: Task = {
          ...t,
          scheduledDate: newDate,
          slot: newSlot || t.slot,
          status: t.status === 'deferred' ? 'todo' : t.status,
        };

        if (user) {
          const taskDocRef = doc(db, 'users', user.uid, 'tasks', id);
          updateDoc(taskDocRef, {
            scheduledDate: newDate,
            slot: updated.slot,
            status: updated.status,
          }).catch(console.warn);
        }

        return updated;
      })
    );
  };

  const applyReplan = (keptIds: string[], deferred: { taskId: string; newDate: string }[]) => {
    const keptSet = new Set(keptIds);
    const deferredMap = new Map(deferred.map((d) => [d.taskId, d.newDate]));

    setTasks((prev) =>
      prev.map((t) => {
        if (deferredMap.has(t.id)) {
          const newDate = deferredMap.get(t.id)!;
          if (user) {
            const taskDocRef = doc(db, 'users', user.uid, 'tasks', t.id);
            updateDoc(taskDocRef, { scheduledDate: newDate, status: 'deferred' }).catch(console.warn);
          }
          return {
            ...t,
            scheduledDate: newDate,
            status: 'deferred',
          };
        }
        if (keptSet.has(t.id)) {
          if (user) {
            const taskDocRef = doc(db, 'users', user.uid, 'tasks', t.id);
            updateDoc(taskDocRef, { status: t.status === 'deferred' ? 'todo' : t.status }).catch(
              console.warn
            );
          }
          return {
            ...t,
            status: t.status === 'deferred' ? 'todo' : t.status,
          };
        }
        return t;
      })
    );
  };

  const finishFocusSession = (taskId: string, recordedMinutes: number) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id !== taskId) return t;
        const updatedActual = (t.actualMinutes || 0) + recordedMinutes;

        if (user) {
          const taskDocRef = doc(db, 'users', user.uid, 'tasks', taskId);
          updateDoc(taskDocRef, { actualMinutes: updatedActual }).catch(console.warn);
        }

        return {
          ...t,
          actualMinutes: updatedActual,
        };
      })
    );

    setFocusTimer((prev) => ({
      ...prev,
      isRunning: false,
      secondsElapsed: 0,
    }));
  };

  const resetToDemoData = () => {
    setUserStats(INITIAL_USER_STATS);
    setGoals(INITIAL_GOALS);
    setTasks(INITIAL_TASKS);
    setXpLedger(INITIAL_XP_LEDGER);
    setTodayDate(new Date().toISOString().split('T')[0]);
  };

  const loadStarterTemplate = () => {
    if (!user) return;
    INITIAL_GOALS.forEach((goal) => {
      const gRef = doc(db, 'users', user.uid, 'goals', goal.id);
      setDoc(gRef, { ...goal, userId: user.uid }).catch(console.warn);
    });
    INITIAL_TASKS.forEach((task) => {
      const tRef = doc(db, 'users', user.uid, 'tasks', task.id);
      setDoc(tRef, { ...task, userId: user.uid }).catch(console.warn);
    });
  };

  return (
    <AppContext.Provider
      value={{
        userStats,
        updateUserStats,
        goals,
        createGoal,
        updateGoal,
        deleteGoal,
        addMilestone,
        toggleMilestone,
        tasks,
        createTask,
        updateTask,
        deleteTask,
        toggleTaskComplete,
        rescheduleTask,
        applyReplan,
        todayDate,
        setTodayDate,
        xpLedger,
        activeFocusTask,
        setActiveFocusTask,
        focusTimer,
        setFocusTimer,
        finishFocusSession,
        resetToDemoData,
        loadStarterTemplate,
        hasAiConfigured,
        showReferenceModal,
        setShowReferenceModal,
        isSyncing,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
