import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  User,
  onAuthStateChanged,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  sendPasswordResetEmail,
  updateProfile,
} from 'firebase/auth';
import { doc, getDoc, setDoc, updateDoc, onSnapshot } from 'firebase/firestore';
import { auth, db, formatAuthError } from '../lib/firebase.ts';

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  createdAt: string;
  onboardingCompleted: boolean;
  timeZone: string;
  avatarSeed?: string;
  gamificationEnabled: boolean;
  defaultAvailabilityMinutes: number;
  dailyAvailability?: Record<string, number>;
  autoReplanWithAi?: boolean;
  selectedCategories?: string[];
  roleTitle?: string;
}

interface AuthContextType {
  user: User | null;
  userProfile: UserProfile | null;
  loading: boolean;
  authError: string | null;
  clearAuthError: () => void;
  signUp: (displayName: string, email: string, pass: string) => Promise<void>;
  signIn: (email: string, pass: string) => Promise<void>;
  signOut: () => Promise<void>;
  sendPasswordReset: (email: string) => Promise<void>;
  updateDisplayName: (name: string) => Promise<void>;
  updateUserProfile: (updates: Partial<UserProfile>) => Promise<void>;
  completeOnboarding: (prefs: {
    displayName?: string;
    defaultAvailabilityMinutes?: number;
    gamificationEnabled?: boolean;
    selectedCategories?: string[];
    roleTitle?: string;
  }) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [authError, setAuthError] = useState<string | null>(null);

  const clearAuthError = () => setAuthError(null);

  useEffect(() => {
    let unsubscribeSnapshot: (() => void) | null = null;

    const unsubscribeAuth = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);

      if (unsubscribeSnapshot) {
        unsubscribeSnapshot();
        unsubscribeSnapshot = null;
      }

      if (firebaseUser) {
        const userDocRef = doc(db, 'users', firebaseUser.uid);
        
        // Listen to profile updates in real-time
        unsubscribeSnapshot = onSnapshot(
          userDocRef,
          async (snapshot) => {
            if (snapshot.exists()) {
              setUserProfile(snapshot.data() as UserProfile);
              setLoading(false);
            } else {
              // Create default profile if doc not present yet
              const initialProfile: UserProfile = {
                uid: firebaseUser.uid,
                email: firebaseUser.email || '',
                displayName: firebaseUser.displayName || 'Architect',
                createdAt: new Date().toISOString(),
                onboardingCompleted: false,
                timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC',
                avatarSeed: firebaseUser.uid.substring(0, 8),
                gamificationEnabled: true,
                defaultAvailabilityMinutes: 240,
                autoReplanWithAi: true,
                selectedCategories: ['career', 'learning'],
                roleTitle: 'Systems Strategist',
              };
              try {
                await setDoc(userDocRef, initialProfile, { merge: true });
                setUserProfile(initialProfile);
              } catch (err) {
                console.warn('Could not initialize user profile:', err);
                setUserProfile(initialProfile);
              }
              setLoading(false);
            }
          },
          (error) => {
            console.warn('Firestore user profile snapshot error:', error);
            // Fallback user profile in memory so the app doesn't hang
            setUserProfile({
              uid: firebaseUser.uid,
              email: firebaseUser.email || '',
              displayName: firebaseUser.displayName || 'Architect',
              createdAt: new Date().toISOString(),
              onboardingCompleted: true,
              timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC',
              avatarSeed: firebaseUser.uid.substring(0, 8),
              gamificationEnabled: true,
              defaultAvailabilityMinutes: 240,
              autoReplanWithAi: true,
            });
            setLoading(false);
          }
        );
      } else {
        setUserProfile(null);
        setLoading(false);
      }
    });

    return () => {
      unsubscribeAuth();
      if (unsubscribeSnapshot) unsubscribeSnapshot();
    };
  }, []);

  const signUp = async (displayName: string, email: string, pass: string) => {
    setAuthError(null);
    try {
      const cred = await createUserWithEmailAndPassword(auth, email, pass);
      const cleanName = displayName.trim() || 'Architect';
      
      // Update Auth profile
      if (cred.user) {
        await updateProfile(cred.user, { displayName: cleanName });
      }

      // Initialize Firestore document
      const initialProfile: UserProfile = {
        uid: cred.user.uid,
        email: cred.user.email || email,
        displayName: cleanName,
        createdAt: new Date().toISOString(),
        onboardingCompleted: false,
        timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC',
        avatarSeed: cred.user.uid.substring(0, 8),
        gamificationEnabled: true,
        defaultAvailabilityMinutes: 240,
        autoReplanWithAi: true,
        selectedCategories: ['career', 'learning'],
        roleTitle: 'Systems Strategist',
      };

      const userDocRef = doc(db, 'users', cred.user.uid);
      await setDoc(userDocRef, initialProfile);
      setUserProfile(initialProfile);
    } catch (err: any) {
      const msg = formatAuthError(err);
      setAuthError(msg);
      throw new Error(msg);
    }
  };

  const signIn = async (email: string, pass: string) => {
    setAuthError(null);
    try {
      await signInWithEmailAndPassword(auth, email, pass);
    } catch (err: any) {
      const msg = formatAuthError(err);
      setAuthError(msg);
      throw new Error(msg);
    }
  };

  const signOut = async () => {
    setAuthError(null);
    try {
      await firebaseSignOut(auth);
      setUser(null);
      setUserProfile(null);
    } catch (err: any) {
      const msg = formatAuthError(err);
      setAuthError(msg);
      throw new Error(msg);
    }
  };

  const sendPasswordReset = async (email: string) => {
    setAuthError(null);
    try {
      await sendPasswordResetEmail(auth, email);
    } catch (err: any) {
      const msg = formatAuthError(err);
      setAuthError(msg);
      throw new Error(msg);
    }
  };

  const updateDisplayName = async (name: string) => {
    if (!user) throw new Error('No user is currently signed in');
    const cleanName = name.trim();
    if (!cleanName) throw new Error('Display name cannot be empty');

    try {
      await updateProfile(user, { displayName: cleanName });
      const userDocRef = doc(db, 'users', user.uid);
      await updateDoc(userDocRef, { displayName: cleanName });
      setUserProfile((prev) => (prev ? { ...prev, displayName: cleanName } : null));
    } catch (err: any) {
      const msg = formatAuthError(err);
      setAuthError(msg);
      throw new Error(msg);
    }
  };

  const updateUserProfile = async (updates: Partial<UserProfile>) => {
    if (!user) throw new Error('No user is currently signed in');
    try {
      const userDocRef = doc(db, 'users', user.uid);
      await updateDoc(userDocRef, updates);
      setUserProfile((prev) => (prev ? { ...prev, ...updates } : null));
    } catch (err: any) {
      const msg = formatAuthError(err);
      setAuthError(msg);
      throw new Error(msg);
    }
  };

  const completeOnboarding = async (prefs: {
    displayName?: string;
    defaultAvailabilityMinutes?: number;
    gamificationEnabled?: boolean;
    selectedCategories?: string[];
    roleTitle?: string;
  }) => {
    if (!user) throw new Error('No user is currently signed in');
    const updates: Partial<UserProfile> = {
      ...prefs,
      onboardingCompleted: true,
    };
    if (prefs.displayName) {
      await updateProfile(user, { displayName: prefs.displayName });
    }
    await updateUserProfile(updates);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        userProfile,
        loading,
        authError,
        clearAuthError,
        signUp,
        signIn,
        signOut,
        sendPasswordReset,
        updateDisplayName,
        updateUserProfile,
        completeOnboarding,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
