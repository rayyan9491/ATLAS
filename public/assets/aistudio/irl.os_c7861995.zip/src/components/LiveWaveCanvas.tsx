import React, { useEffect, useRef } from 'react';

interface LiveWaveCanvasProps {
  className?: string;
  intensity?: number;
  showParticles?: boolean;
}

export const LiveWaveCanvas: React.FC<LiveWaveCanvasProps> = ({
  className = '',
  intensity = 1,
  showParticles = true,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = canvas.parentElement?.clientWidth || window.innerWidth);
    let height = (canvas.height = canvas.parentElement?.clientHeight || 400);

    const handleResize = () => {
      if (!canvas || !canvas.parentElement) return;
      width = canvas.width = canvas.parentElement.clientWidth;
      height = canvas.height = canvas.parentElement.clientHeight || 400;
    };
    window.addEventListener('resize', handleResize);

    // Interactive mouse / cursor tracking
    let mouseX = width * 0.5;
    let mouseY = height * 0.4;
    let targetMouseX = mouseX;
    let targetMouseY = mouseY;
    let isHovering = false;

    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      targetMouseX = e.clientX - rect.left;
      targetMouseY = e.clientY - rect.top;
      isHovering = true;
    };

    const handleMouseLeave = () => {
      isHovering = false;
      targetMouseX = width * 0.5;
      targetMouseY = height * 0.4;
    };

    window.addEventListener('mousemove', handleMouseMove);
    canvas.addEventListener('mouseleave', handleMouseLeave);

    // Ambient floating particles
    const particleCount = showParticles ? 38 : 0;
    const particles = Array.from({ length: particleCount }).map(() => ({
      x: Math.random() * width,
      y: Math.random() * height,
      size: Math.random() * 2.2 + 0.8,
      speedX: (Math.random() - 0.5) * 0.4,
      speedY: (Math.random() - 0.5) * 0.3,
      alpha: Math.random() * 0.7 + 0.3,
      pulseSpeed: Math.random() * 0.03 + 0.01,
      phase: Math.random() * Math.PI * 2,
      color: Math.random() > 0.45 ? '#67E8F9' : '#A78BFA',
    }));

    let step = 0;
    const lines = 34;
    const pointsPerLine = 70;

    const render = () => {
      step += 0.016 * intensity;
      mouseX += (targetMouseX - mouseX) * 0.06;
      mouseY += (targetMouseY - mouseY) * 0.06;

      ctx.clearRect(0, 0, width, height);

      // Draw floating luminous drift particles
      if (showParticles) {
        for (const p of particles) {
          p.x += p.speedX;
          p.y += p.speedY;
          p.phase += p.pulseSpeed;

          if (p.x < 0) p.x = width;
          if (p.x > width) p.x = 0;
          if (p.y < 0) p.y = height;
          if (p.y > height) p.y = 0;

          const currentAlpha = Math.max(0.1, p.alpha * (0.6 + 0.4 * Math.sin(p.phase)));
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          ctx.fillStyle = p.color === '#67E8F9'
            ? `rgba(103, 232, 249, ${currentAlpha})`
            : `rgba(167, 139, 250, ${currentAlpha})`;
          ctx.shadowColor = p.color;
          ctx.shadowBlur = 6;
          ctx.fill();
        }
      }

      // Draw undulating perspective electric blue wave ribbons
      for (let i = 0; i < lines; i++) {
        const lineFraction = i / lines;
        // Natural curved ground horizon
        const baseY = height * 0.38 + lineFraction * (height * 0.58);
        const zDepth = 1 - lineFraction * 0.55;

        ctx.beginPath();
        let first = true;

        for (let j = 0; j <= pointsPerLine; j++) {
          const xFraction = j / pointsPerLine;
          const x = xFraction * width;

          // Multi-harmonic sine + cosine interference waves
          const wave1 = Math.sin(xFraction * 5.2 + step * 1.1 + i * 0.18) * 26 * zDepth;
          const wave2 = Math.cos(xFraction * 9.4 - step * 1.3 + i * 0.12) * 16 * zDepth;
          const wave3 = Math.sin(xFraction * 2.8 + step * 0.6) * 32 * zDepth;
          const wave4 = Math.sin(xFraction * 14.0 + step * 1.8 + i * 0.08) * 6 * zDepth;

          // Interactive cursor ripple
          const dx = x - mouseX;
          const dy = baseY - mouseY;
          const dist = Math.sqrt(dx * dx + dy * dy);
          const mouseRipple = Math.max(0, 1 - dist / 320) * 32 * Math.sin(step * 3.5 - dist * 0.02);

          const y = baseY + (wave1 + wave2 + wave3 + wave4) * intensity + (isHovering ? mouseRipple : 0);

          if (first) {
            ctx.moveTo(x, y);
            first = false;
          } else {
            ctx.lineTo(x, y);
          }
        }

        // Gradient styling matching electric cyan, sapphire blue and violet
        const gradient = ctx.createLinearGradient(0, 0, width, 0);
        const baseAlpha = Math.max(0.12, (1 - lineFraction * 0.65) * 0.7);

        gradient.addColorStop(0, `rgba(139, 92, 246, ${baseAlpha * 0.35})`); // deep violet
        gradient.addColorStop(0.25, `rgba(56, 189, 248, ${baseAlpha * 0.85})`); // sky cyan
        gradient.addColorStop(0.5, `rgba(103, 232, 249, ${baseAlpha})`); // vibrant electric cyan
        gradient.addColorStop(0.75, `rgba(167, 139, 250, ${baseAlpha * 0.9})`); // luminous violet
        gradient.addColorStop(1, `rgba(56, 189, 248, ${baseAlpha * 0.3})`); // sky cyan

        ctx.strokeStyle = gradient;
        ctx.lineWidth = i % 5 === 0 ? 1.9 : 1.1;

        // Subtle glow effect
        if (i % 3 === 0) {
          ctx.shadowColor = 'rgba(103, 232, 249, 0.5)';
          ctx.shadowBlur = 10;
        } else {
          ctx.shadowBlur = 0;
        }

        ctx.stroke();
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handleMouseMove);
      canvas.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, [intensity, showParticles]);

  return (
    <canvas
      ref={canvasRef}
      className={`absolute inset-0 w-full h-full pointer-events-none select-none ${className}`}
      style={{ filter: 'contrast(120%)' }}
    />
  );
};
