import React, { useState } from 'react';
import {
  Compass,
  Calendar,
  Target,
  Sparkles,
  Zap,
  BarChart2,
  User,
  Settings,
  Flame,
  Clock,
  ArrowRight,
  Maximize2,
  CheckCircle2,
  Play,
  RotateCcw,
  ShieldCheck,
  Send,
  AlertTriangle,
  ChevronRight,
  Plus,
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { calculateWorkload } from '../utils/workload.ts';
import { getNextBestMove } from '../utils/recommendation.ts';
import { LiveWaveCanvas } from '../components/LiveWaveCanvas.tsx';

interface MasterDeckPageProps {
  onNavigate: (path: string) => void;
  onOpenTaskModal: () => void;
  onOpenGoalModal: () => void;
}

export const MasterDeckPage: React.FC<MasterDeckPageProps> = ({
  onNavigate,
  onOpenTaskModal,
  onOpenGoalModal,
}) => {
  const {
    tasks,
    goals,
    userStats,
    todayDate,
    toggleTaskComplete,
    focusTimer,
    setFocusTimer,
    updateUserStats,
  } = useApp();

  const toggleTaskCompletion = toggleTaskComplete;
  const setDailyAvailability = (date: string, mins: number) => {
    updateUserStats({
      dailyAvailability: {
        ...(userStats.dailyAvailability || {}),
        [date]: mins,
      },
    });
  };

  const focusRemainingSeconds = Math.max(0, focusTimer.targetMinutes * 60 - focusTimer.secondsElapsed);
  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const focusState = {
    remainingSeconds: focusRemainingSeconds,
    isRunning: focusTimer.isRunning,
    taskId: focusTimer.activeTaskId,
  };

  const pauseFocusSession = () => {
    setFocusTimer((prev) => ({ ...prev, isRunning: false }));
  };

  const resumeFocusSession = () => {
    setFocusTimer((prev) => ({ ...prev, isRunning: true }));
  };

  const startFocusSession = (taskId: string, targetMinutes: number = 45) => {
    setFocusTimer({
      isRunning: true,
      secondsElapsed: 0,
      targetMinutes,
      activeTaskId: taskId,
    });
  };

  const availableMinutes =
    userStats.dailyAvailability[todayDate] !== undefined
      ? userStats.dailyAvailability[todayDate]
      : userStats.defaultAvailabilityMinutes;

  const workload = calculateWorkload(tasks, availableMinutes, todayDate);
  const nextMove = getNextBestMove(tasks, goals, workload);

  const todayTasks = tasks.filter((t) => t.scheduledDate === todayDate);
  const completedToday = todayTasks.filter((t) => t.status === 'completed');
  const completionPercent =
    todayTasks.length > 0 ? Math.round((completedToday.length / todayTasks.length) * 100) : 0;

  // Mini live AI Perspective state in Deck
  const [deckAiPrompt, setDeckAiPrompt] = useState('');
  const [deckAiResponse, setDeckAiResponse] = useState<string | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);

  const handleAskDeckAi = async (promptText: string) => {
    const q = promptText.trim();
    if (!q || isAiLoading) return;
    setIsAiLoading(true);

    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: q,
          userContext: {
            displayName: userStats.displayName,
            level: userStats.level,
            xp: userStats.xp,
            todayDate,
            availableMinutes,
            workload,
            activeGoals: goals.map((g) => ({ title: g.title, category: g.category })),
            scheduledTasksToday: todayTasks.map((t) => ({
              title: t.title,
              estimatedMinutes: t.estimatedMinutes,
              priority: t.priority,
              status: t.status,
            })),
          },
        }),
      });

      const data = await res.json();
      if (data && data.reply) {
        setDeckAiResponse(data.reply);
      }
    } catch (err) {
      console.error(err);
      setDeckAiResponse(
        `Based on your live dayboard: You have ${workload.remainingMinutes}m of work queued. Prioritize "${nextMove?.task.title || 'Deep Work: Project Phoenix'}" first.`
      );
    } finally {
      setIsAiLoading(false);
      setDeckAiPrompt('');
    }
  };

  const formatHoursMins = (mins: number) => {
    const h = Math.floor(Math.abs(mins) / 60);
    const m = Math.abs(mins) % 60;
    return `${h > 0 ? `${h}h ` : ''}${m}m`;
  };

  return (
    <div className="p-4 sm:p-6 max-w-[1680px] mx-auto space-y-6 relative selection:bg-[#A78BFA] selection:text-black">
      {/* Background Live Blue Wave Canvas for ambient theme */}
      <div className="fixed inset-0 pointer-events-none opacity-20 z-0">
        <LiveWaveCanvas intensity={0.8} />
      </div>

      {/* Master Deck Top Bar */}
      <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-2xl bg-[#121622]/90 border border-[#252B3B] backdrop-blur-md shadow-2xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#A78BFA] to-[#67E8F9] flex items-center justify-center font-mono font-extrabold text-black text-sm shadow-lg shadow-violet-500/20">
            IRL
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-extrabold text-[#F4F5FA] tracking-tight">
                IRL.OS Unified Master Deck
              </h1>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#181D2B] text-[#67E8F9] border border-[#252B3B]">
                All Systems Configured in 1 View
              </span>
            </div>
            <p className="text-xs text-[#939BB0] mt-0.5">
              Live operating telemetry across Today Command, Roadmaps, Planner, Focus Room, Insights, and AI Perspective.
            </p>
          </div>
        </div>

        {/* User Stats Quick Hud */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-3 bg-[#090A0F] px-4 py-2 rounded-xl border border-[#252B3B]">
            <div className="w-7 h-7 rounded-lg bg-[#181D2B] border border-[#A78BFA]/50 flex items-center justify-center font-bold text-xs text-[#A78BFA]">
              AM
            </div>
            <div>
              <div className="text-xs font-bold text-[#F4F5FA]">{userStats.displayName}</div>
              <div className="text-[10px] font-mono text-[#67E8F9]">
                Level {userStats.level} • {userStats.xp.toLocaleString()} XP
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-[#090A0F] px-3.5 py-2 rounded-xl border border-[#252B3B] text-xs font-mono">
            <Clock size={14} className="text-[#A78BFA]" />
            <span className="text-[#939BB0]">Window:</span>
            <span className="font-bold text-[#F4F5FA]">{formatHoursMins(availableMinutes)}</span>
          </div>

          <button
            onClick={() => onNavigate('/app/today')}
            className="px-4 py-2 rounded-xl bg-[#181D2B] hover:bg-[#252B3B] text-[#F4F5FA] border border-[#252B3B] text-xs font-semibold flex items-center gap-2 transition-all"
          >
            <span>Focus Today Mode</span>
            <ArrowRight size={13} />
          </button>
        </div>
      </div>

      {/* TOP ROW: LANDING PREVIEW (Left) + TODAY DASHBOARD (Right) matching image_d5a25b54.png */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 relative z-10">
        {/* PANEL 1: LANDING & SYSTEM IDENTITY (4 cols) */}
        <div className="lg:col-span-5 rounded-2xl bg-[#121622]/90 border border-[#252B3B] p-6 shadow-xl flex flex-col justify-between relative overflow-hidden backdrop-blur-md">
          <div className="absolute top-0 right-0 w-64 h-32 bg-[#A78BFA]/10 rounded-full blur-3xl pointer-events-none" />

          <div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-mono uppercase tracking-wider text-[#A78BFA] font-bold flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#A78BFA] animate-pulse" />
                Landing Page Preview & Pitch
              </span>
              <button
                onClick={() => onNavigate('/')}
                className="text-[11px] font-mono text-[#67E8F9] hover:underline flex items-center gap-1"
              >
                <span>Full Page</span>
                <Maximize2 size={12} />
              </button>
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold text-[#F4F5FA] leading-tight tracking-tight">
              Your life. <br />
              Your system. <br />
              <span className="bg-gradient-to-r from-[#A78BFA] to-[#67E8F9] bg-clip-text text-transparent">
                Your next move.
              </span>
            </h2>

            <p className="text-xs text-[#939BB0] mt-3 leading-relaxed">
              IRL.OS is your personal operating system for clarity, focus, and execution. Connecting goals,
              available time, tasks, actual progress, and intelligent recommendations in one unified engine.
            </p>

            <div className="mt-5 p-3.5 rounded-xl bg-[#090A0F] border border-[#252B3B] space-y-2">
              <div className="text-[11px] font-mono text-[#67E8F9] uppercase font-bold">
                System Capabilities Verified:
              </div>
              <ul className="text-xs text-[#939BB0] space-y-1 font-mono">
                <li className="flex items-center gap-2 text-[#F4F5FA]">
                  <CheckCircle2 size={13} className="text-[#4ADE80]" />
                  <span>Reality Check Workload Math</span>
                </li>
                <li className="flex items-center gap-2 text-[#F4F5FA]">
                  <CheckCircle2 size={13} className="text-[#4ADE80]" />
                  <span>Deterministic Next Best Move Engine</span>
                </li>
                <li className="flex items-center gap-2 text-[#F4F5FA]">
                  <CheckCircle2 size={13} className="text-[#4ADE80]" />
                  <span>Live Gemini Flash AI Perspective</span>
                </li>
                <li className="flex items-center gap-2 text-[#F4F5FA]">
                  <CheckCircle2 size={13} className="text-[#4ADE80]" />
                  <span>Distraction-Free Focus Timer</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="mt-6 flex items-center gap-3">
            <button
              onClick={() => onNavigate('/')}
              className="px-4 py-2.5 rounded-xl bg-[#181D2B] hover:bg-[#252B3B] text-[#F4F5FA] border border-[#252B3B] text-xs font-semibold flex items-center gap-2 transition-all"
            >
              <span>Explore Public Portal</span>
            </button>
            <button
              onClick={() => onNavigate('/app/today')}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#A78BFA] to-[#8B5CF6] text-black text-xs font-bold flex items-center gap-2 shadow-lg shadow-violet-500/20 hover:opacity-95 transition-all"
            >
              <span>Enter Today Command</span>
              <ArrowRight size={14} />
            </button>
          </div>
        </div>

        {/* PANEL 2: TODAY DASHBOARD COCKPIT (7 cols) */}
        <div className="lg:col-span-7 rounded-2xl bg-[#121622]/90 border border-[#252B3B] p-6 shadow-xl space-y-5 backdrop-blur-md">
          <div className="flex items-center justify-between border-b border-[#252B3B] pb-3">
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono uppercase tracking-wider text-[#67E8F9] font-bold">
                Today Dashboard
              </span>
              <span className="text-[11px] font-mono text-[#939BB0]">• {todayDate}</span>
            </div>
            <button
              onClick={() => onNavigate('/app/today')}
              className="text-[11px] font-mono text-[#67E8F9] hover:underline flex items-center gap-1"
            >
              <span>Expand Command View</span>
              <Maximize2 size={12} />
            </button>
          </div>

          {/* Sub-grid: Reality Check + Next Best Move */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Reality Check Card */}
            <div className="p-4 rounded-xl bg-[#090A0F] border border-[#252B3B] space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-[#939BB0] uppercase">Reality Check</span>
                <span
                  className={`text-[11px] font-mono font-bold px-2 py-0.5 rounded ${
                    workload.diffMinutes < 0
                      ? 'bg-[#FB7185]/20 text-[#FB7185]'
                      : 'bg-[#4ADE80]/20 text-[#4ADE80]'
                  }`}
                >
                  {workload.diffMinutes < 0
                    ? `-${formatHoursMins(workload.diffMinutes)} Over plan`
                    : `+${formatHoursMins(workload.diffMinutes)} Available`}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                <div>
                  <div className="text-[10px] text-[#939BB0]">Available Time</div>
                  <div className="text-sm font-bold text-[#F4F5FA]">{formatHoursMins(availableMinutes)}</div>
                </div>
                <div>
                  <div className="text-[10px] text-[#939BB0]">Planned Workload</div>
                  <div className="text-sm font-bold text-[#F4F5FA]">
                    {formatHoursMins(workload.remainingMinutes)}
                  </div>
                </div>
              </div>

              <div className="w-full bg-[#181D2B] h-1.5 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all ${
                    workload.diffMinutes < 0 ? 'bg-[#FB7185]' : 'bg-gradient-to-r from-[#A78BFA] to-[#67E8F9]'
                  }`}
                  style={{ width: `${Math.min(100, workload.percentUtilized)}%` }}
                />
              </div>

              <div className="flex items-center justify-between text-[10px] font-mono text-[#939BB0]">
                <span>Adjust Window:</span>
                <input
                  type="range"
                  min="60"
                  max="600"
                  step="15"
                  value={availableMinutes}
                  onChange={(e) => setDailyAvailability(todayDate, Number(e.target.value))}
                  className="w-24 accent-[#A78BFA]"
                />
              </div>
            </div>

            {/* Next Best Move Card */}
            <div className="p-4 rounded-xl bg-gradient-to-br from-[#181D2B] to-[#121622] border border-[#A78BFA]/40 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-[#A78BFA] uppercase font-bold flex items-center gap-1.5">
                  <Zap size={13} className="text-[#A78BFA]" />
                  Next Best Move
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#A78BFA]/20 text-[#A78BFA] border border-[#A78BFA]/30">
                  High Impact
                </span>
              </div>

              <div>
                <h4 className="text-sm font-bold text-[#F4F5FA]">
                  {nextMove?.task.title || 'Deep Work: Project Phoenix'}
                </h4>
                <p className="text-[11px] text-[#939BB0] mt-1 line-clamp-2">
                  {nextMove?.reason ||
                    'Critical priority linked to core milestone deadline. Highest leverage allocation.'}
                </p>
              </div>

              <div className="flex items-center justify-between pt-1">
                <span className="text-[11px] font-mono text-[#67E8F9]">
                  {nextMove?.task.estimatedMinutes || 90}m focus block
                </span>
                <button
                  onClick={() => {
                    if (nextMove?.task) {
                      startFocusSession(nextMove.task.id, nextMove.task.estimatedMinutes);
                      onNavigate('/app/focus');
                    }
                  }}
                  className="px-3 py-1.5 rounded-lg bg-[#A78BFA] text-black font-bold text-xs flex items-center gap-1 hover:opacity-95"
                >
                  <Play size={11} fill="currentColor" />
                  <span>Start Focus</span>
                </button>
              </div>
            </div>
          </div>

          {/* Today Tasks List preview */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs font-mono text-[#939BB0]">
              <span>Today's Execution List ({completedToday.length}/{todayTasks.length})</span>
              <button onClick={onOpenTaskModal} className="text-[#A78BFA] hover:underline flex items-center gap-1">
                <Plus size={12} />
                <span>Add Task</span>
              </button>
            </div>

            <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
              {todayTasks.map((task) => {
                const isDone = task.status === 'completed';
                return (
                  <div
                    key={task.id}
                    onClick={() => toggleTaskCompletion(task.id)}
                    className={`p-2.5 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                      isDone
                        ? 'bg-[#090A0F]/50 border-[#252B3B] opacity-60'
                        : 'bg-[#090A0F] border-[#252B3B] hover:border-[#A78BFA]/50'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div
                        className={`w-4 h-4 rounded border flex items-center justify-center ${
                          isDone ? 'bg-[#4ADE80] border-[#4ADE80] text-black' : 'border-[#939BB0]/40'
                        }`}
                      >
                        {isDone && <CheckCircle2 size={12} />}
                      </div>
                      <span className={`text-xs font-medium ${isDone ? 'line-through text-[#939BB0]' : 'text-[#F4F5FA]'}`}>
                        {task.title}
                      </span>
                    </div>

                    <div className="flex items-center gap-3 text-[10px] font-mono">
                      <span className="text-[#67E8F9]">{task.estimatedMinutes}m</span>
                      <span
                        className={`px-1.5 py-0.5 rounded ${
                          task.priority === 'critical'
                            ? 'bg-[#FB7185]/20 text-[#FB7185]'
                            : task.priority === 'high'
                            ? 'bg-[#FBBF24]/20 text-[#FBBF24]'
                            : 'bg-[#181D2B] text-[#939BB0]'
                        }`}
                      >
                        {task.priority}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Today's Progress Bar */}
          <div className="p-3 rounded-xl bg-[#090A0F] border border-[#252B3B] flex items-center justify-between text-xs font-mono">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full border-2 border-[#A78BFA] flex items-center justify-center font-bold text-[#A78BFA] text-[10px]">
                {completionPercent}%
              </div>
              <div>
                <div className="text-[#F4F5FA] font-bold">
                  {completedToday.length} of {todayTasks.length} tasks completed
                </div>
                <div className="text-[10px] text-[#939BB0]">12 Day Streak Active • 320 XP Earned Today</div>
              </div>
            </div>
            <div className="text-right">
              <div className="text-[11px] font-bold text-[#67E8F9]">
                {userStats.xp} / {userStats.xp + 1080} XP
              </div>
              <div className="text-[10px] text-[#939BB0]">Level {userStats.level} Progress</div>
            </div>
          </div>
        </div>
      </div>

      {/* BOTTOM 6 PANELS GRID matching image_d5a25b54.png */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-5 relative z-10">
        {/* PANEL 3: GOALS + GOAL MAP */}
        <div className="rounded-2xl bg-[#121622]/90 border border-[#252B3B] p-4 flex flex-col justify-between shadow-lg hover:border-[#A78BFA]/50 transition-all">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-mono uppercase tracking-wider text-[#A78BFA] font-bold flex items-center gap-1.5">
                <Target size={13} />
                Goals & Map
              </span>
              <button onClick={() => onNavigate('/app/goals')} className="text-[#67E8F9] hover:underline">
                <Maximize2 size={12} />
              </button>
            </div>

            <div className="space-y-2">
              {goals.slice(0, 3).map((g) => {
                const completedCount = g.milestones.filter((m) => m.status === 'completed').length;
                const progressPct =
                  g.milestones.length > 0
                    ? Math.round((completedCount / g.milestones.length) * 100)
                    : 0;
                return (
                  <div key={g.id} className="p-2.5 rounded-xl bg-[#090A0F] border border-[#252B3B] space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-[#F4F5FA] truncate">{g.title}</span>
                      <span className="text-[10px] font-mono text-[#67E8F9]">{progressPct}%</span>
                    </div>
                    <div className="w-full bg-[#181D2B] h-1 rounded-full overflow-hidden">
                      <div
                        className="bg-gradient-to-r from-[#A78BFA] to-[#67E8F9] h-full rounded-full"
                        style={{ width: `${progressPct}%` }}
                      />
                    </div>
                    <div className="text-[9px] font-mono text-[#939BB0]">
                      {completedCount}/{g.milestones.length} milestones
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <button
            onClick={() => onNavigate(goals.length > 0 ? `/app/goals/${goals[0].id}` : '/app/goals')}
            className="mt-3 w-full py-2 rounded-xl bg-[#181D2B] hover:bg-[#252B3B] text-xs font-semibold text-[#F4F5FA] flex items-center justify-center gap-1.5 transition-colors"
          >
            <span>Open Goal Map</span>
            <ArrowRight size={12} />
          </button>
        </div>

        {/* PANEL 4: WEEKLY PLANNER */}
        <div className="rounded-2xl bg-[#121622]/90 border border-[#252B3B] p-4 flex flex-col justify-between shadow-lg hover:border-[#67E8F9]/50 transition-all">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-mono uppercase tracking-wider text-[#67E8F9] font-bold flex items-center gap-1.5">
                <Calendar size={13} />
                Weekly Plan
              </span>
              <button onClick={() => onNavigate('/app/plan')} className="text-[#67E8F9] hover:underline">
                <Maximize2 size={12} />
              </button>
            </div>

            <div className="space-y-1.5 text-xs font-mono">
              <div className="p-2 rounded-lg bg-[#090A0F] border border-[#252B3B] flex items-center justify-between">
                <span className="text-[#F4F5FA]">Mon 19</span>
                <span className="text-[#4ADE80]">100% Load</span>
              </div>
              <div className="p-2 rounded-lg bg-[#181D2B] border border-[#A78BFA]/40 flex items-center justify-between font-bold">
                <span className="text-[#A78BFA]">Tue 20 (Today)</span>
                <span className="text-[#FB7185]">120% Over</span>
              </div>
              <div className="p-2 rounded-lg bg-[#090A0F] border border-[#252B3B] flex items-center justify-between">
                <span className="text-[#939BB0]">Wed 21</span>
                <span className="text-[#67E8F9]">85% Balanced</span>
              </div>
              <div className="p-2 rounded-lg bg-[#090A0F] border border-[#252B3B] flex items-center justify-between">
                <span className="text-[#939BB0]">Thu 22</span>
                <span className="text-[#939BB0]">60% Capacity</span>
              </div>
            </div>
          </div>

          <button
            onClick={() => onNavigate('/app/plan')}
            className="mt-3 w-full py-2 rounded-xl bg-[#181D2B] hover:bg-[#252B3B] text-xs font-semibold text-[#F4F5FA] flex items-center justify-center gap-1.5 transition-colors"
          >
            <span>Open Planner</span>
            <ArrowRight size={12} />
          </button>
        </div>

        {/* PANEL 5: FOCUS ROOM */}
        <div className="rounded-2xl bg-[#121622]/90 border border-[#252B3B] p-4 flex flex-col justify-between shadow-lg hover:border-[#A78BFA]/50 transition-all text-center">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-mono uppercase tracking-wider text-[#A78BFA] font-bold flex items-center gap-1.5">
                <Clock size={13} />
                Focus Room
              </span>
              <button onClick={() => onNavigate('/app/focus')} className="text-[#67E8F9] hover:underline">
                <Maximize2 size={12} />
              </button>
            </div>

            <div className="my-3">
              <div className="w-20 h-20 mx-auto rounded-full border-2 border-[#A78BFA] flex flex-col items-center justify-center bg-[#090A0F] shadow-lg shadow-violet-500/10">
                <span className="text-sm font-mono font-extrabold text-[#F4F5FA]">
                  {formatTimer(focusState.remainingSeconds)}
                </span>
                <span className="text-[9px] font-mono text-[#67E8F9]">
                  {focusState.isRunning ? 'RUNNING' : 'PAUSED'}
                </span>
              </div>
              <div className="text-[11px] font-semibold text-[#F4F5FA] mt-2 truncate">
                {focusState.taskId ? tasks.find((t) => t.id === focusState.taskId)?.title : 'Deep Work Block'}
              </div>
              <div className="text-[10px] font-mono text-[#939BB0]">Today: 2h 15m focus logged</div>
            </div>
          </div>

          <div className="flex items-center justify-center gap-2 mt-2">
            {focusState.isRunning ? (
              <button
                onClick={pauseFocusSession}
                className="w-full py-1.5 rounded-lg bg-[#FB7185]/20 text-[#FB7185] border border-[#FB7185]/40 text-xs font-semibold"
              >
                Pause
              </button>
            ) : (
              <button
                onClick={() => {
                  if (focusState.taskId) {
                    resumeFocusSession();
                  } else {
                    startFocusSession('t-phoenix', 90);
                  }
                  onNavigate('/app/focus');
                }}
                className="w-full py-1.5 rounded-lg bg-[#A78BFA] text-black text-xs font-bold hover:opacity-95"
              >
                Enter Focus
              </button>
            )}
          </div>
        </div>

        {/* PANEL 6: INSIGHTS & REALITY REPORT */}
        <div className="rounded-2xl bg-[#121622]/90 border border-[#252B3B] p-4 flex flex-col justify-between shadow-lg hover:border-[#67E8F9]/50 transition-all">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-mono uppercase tracking-wider text-[#67E8F9] font-bold flex items-center gap-1.5">
                <BarChart2 size={13} />
                Reality Report
              </span>
              <button onClick={() => onNavigate('/app/insights')} className="text-[#67E8F9] hover:underline">
                <Maximize2 size={12} />
              </button>
            </div>

            <div className="space-y-2">
              <div className="grid grid-cols-2 gap-2 text-center">
                <div className="p-2 rounded-lg bg-[#090A0F] border border-[#252B3B]">
                  <div className="text-[9px] font-mono text-[#939BB0]">COMPLETION</div>
                  <div className="text-sm font-bold text-[#4ADE80]">81%</div>
                </div>
                <div className="p-2 rounded-lg bg-[#090A0F] border border-[#252B3B]">
                  <div className="text-[9px] font-mono text-[#939BB0]">TOTAL XP</div>
                  <div className="text-sm font-bold text-[#67E8F9]">2,450</div>
                </div>
              </div>

              <div className="p-2 rounded-lg bg-[#090A0F] border border-[#252B3B] text-[10px] font-mono text-[#939BB0]">
                <div>Planned vs Completed:</div>
                <div className="text-[#F4F5FA] font-bold mt-0.5">34h 30m vs 34h 15m</div>
                <div className="text-[#4ADE80] mt-0.5">Execution Delta: 99.3% accuracy</div>
              </div>
            </div>
          </div>

          <button
            onClick={() => onNavigate('/app/insights')}
            className="mt-3 w-full py-2 rounded-xl bg-[#181D2B] hover:bg-[#252B3B] text-xs font-semibold text-[#F4F5FA] flex items-center justify-center gap-1.5 transition-colors"
          >
            <span>View Analytics</span>
            <ArrowRight size={12} />
          </button>
        </div>

        {/* PANEL 7: AI PERSPECTIVE WITH LIVE GEMINI CHAT */}
        <div className="rounded-2xl bg-[#121622]/90 border border-[#A78BFA]/50 p-4 flex flex-col justify-between shadow-lg hover:shadow-violet-500/10 transition-all">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-mono uppercase tracking-wider text-[#A78BFA] font-bold flex items-center gap-1.5">
                <Sparkles size={13} className="text-[#A78BFA]" />
                AI Perspective
              </span>
              <button onClick={() => onNavigate('/app/coach')} className="text-[#67E8F9] hover:underline">
                <Maximize2 size={12} />
              </button>
            </div>

            <div className="text-[10px] text-[#939BB0] mb-2 flex items-center gap-1 font-mono">
              <span className="w-1.5 h-1.5 rounded-full bg-[#4ADE80] animate-pulse" />
              <span>Live Gemini API Configured</span>
            </div>

            {deckAiResponse ? (
              <div className="p-2.5 rounded-xl bg-[#090A0F] border border-[#252B3B] text-[11px] text-[#F4F5FA] max-h-24 overflow-y-auto leading-relaxed">
                {deckAiResponse}
              </div>
            ) : (
              <div className="p-2 rounded-xl bg-[#090A0F] border border-[#252B3B] text-[10px] text-[#939BB0] space-y-1">
                <div className="text-[#A78BFA] font-bold">Evidence Recommendation:</div>
                <div className="line-clamp-2">Protect 2 morning deep work blocks this week. 87% confidence.</div>
              </div>
            )}

            <div className="mt-2 flex gap-1">
              <input
                type="text"
                placeholder="Ask AI advisor..."
                value={deckAiPrompt}
                onChange={(e) => setDeckAiPrompt(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAskDeckAi(deckAiPrompt)}
                className="flex-1 px-2.5 py-1.5 rounded-lg bg-[#090A0F] border border-[#252B3B] text-[11px] text-[#F4F5FA] focus:outline-none focus:border-[#A78BFA]"
              />
              <button
                onClick={() => handleAskDeckAi(deckAiPrompt || 'What should I do right now?')}
                disabled={isAiLoading}
                className="px-2 py-1.5 rounded-lg bg-[#A78BFA] text-black font-bold text-xs flex items-center justify-center hover:opacity-90 disabled:opacity-50"
              >
                {isAiLoading ? <span className="animate-spin text-[10px]">...</span> : <Send size={11} />}
              </button>
            </div>
          </div>

          <button
            onClick={() => onNavigate('/app/coach')}
            className="mt-3 w-full py-2 rounded-xl bg-gradient-to-r from-[#A78BFA] to-[#8B5CF6] text-black text-xs font-bold flex items-center justify-center gap-1.5 hover:opacity-95 transition-all"
          >
            <span>Open AI Advisor</span>
            <ArrowRight size={12} />
          </button>
        </div>

        {/* PANEL 8: PROFILE & SETTINGS */}
        <div className="rounded-2xl bg-[#121622]/90 border border-[#252B3B] p-4 flex flex-col justify-between shadow-lg hover:border-[#252B3B] transition-all">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-mono uppercase tracking-wider text-[#939BB0] font-bold flex items-center gap-1.5">
                <Settings size={13} />
                Profile & OS
              </span>
              <button onClick={() => onNavigate('/app/settings')} className="text-[#67E8F9] hover:underline">
                <Maximize2 size={12} />
              </button>
            </div>

            <div className="space-y-2 text-xs font-mono">
              <div className="p-2 rounded-lg bg-[#090A0F] border border-[#252B3B]">
                <div className="text-[10px] text-[#939BB0]">OPERATOR</div>
                <div className="font-bold text-[#F4F5FA]">{userStats.displayName}</div>
                <div className="text-[10px] text-[#A78BFA]">Title: {userStats.title}</div>
              </div>

              <div className="p-2 rounded-lg bg-[#090A0F] border border-[#252B3B] text-[10px] text-[#939BB0] space-y-0.5">
                <div className="flex justify-between">
                  <span>Theme:</span>
                  <span className="text-[#67E8F9]">Obsidian Violet</span>
                </div>
                <div className="flex justify-between">
                  <span>API Key:</span>
                  <span className="text-[#4ADE80]">System Owned</span>
                </div>
                <div className="flex justify-between">
                  <span>Storage:</span>
                  <span className="text-[#F4F5FA]">Local Verified</span>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-3 flex gap-2">
            <button
              onClick={() => onNavigate('/app/profile')}
              className="flex-1 py-2 rounded-xl bg-[#181D2B] hover:bg-[#252B3B] text-xs font-semibold text-[#F4F5FA] flex items-center justify-center transition-colors"
            >
              Profile
            </button>
            <button
              onClick={() => onNavigate('/app/settings')}
              className="flex-1 py-2 rounded-xl bg-[#181D2B] hover:bg-[#252B3B] text-xs font-semibold text-[#F4F5FA] flex items-center justify-center transition-colors"
            >
              Config
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
