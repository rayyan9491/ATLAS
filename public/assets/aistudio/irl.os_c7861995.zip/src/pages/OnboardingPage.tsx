import React, { useState } from 'react';
import {
  Sparkles,
  ArrowRight,
  Target,
  Clock,
  Flame,
  CheckCircle2,
  Sliders,
  ChevronRight,
  Shield,
  Layers,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext.tsx';
import { useApp } from '../context/AppContext.tsx';
import { LiveWaveCanvas } from '../components/LiveWaveCanvas.tsx';

interface OnboardingPageProps {
  onNavigate: (path: string) => void;
}

export const OnboardingPage: React.FC<OnboardingPageProps> = ({ onNavigate }) => {
  const { userProfile, completeOnboarding } = useAuth();
  const { createGoal, createTask } = useApp();

  const [step, setStep] = useState(1);
  const [displayName, setDisplayName] = useState(userProfile?.displayName || 'Architect');
  const [roleTitle, setRoleTitle] = useState('Systems Strategist');
  const [selectedFocus, setSelectedFocus] = useState<string[]>(['Deep Work', 'Engineering']);
  const [dailyHours, setDailyHours] = useState(4.0);
  const [gamification, setGamification] = useState(true);
  const [createStarterKit, setCreateStarterKit] = useState(true);
  const [saving, setSaving] = useState(false);

  const focusOptions = [
    { id: 'Deep Work', label: 'Deep Work & Coding', desc: 'Distraction-free high leverage sprint sessions' },
    { id: 'Engineering', label: 'Systems & Architecture', desc: 'Building software, infrastructure and APIs' },
    { id: 'Health', label: 'Physical Vitality & Fitness', desc: 'Workout consistency, recovery and nutrition' },
    { id: 'Learning', label: 'Skill Mastery & Research', desc: 'Reading, technical certifications and papers' },
    { id: 'Creative', label: 'Creative & Writing', desc: 'Essays, design projects and side experiments' },
    { id: 'Finance', label: 'Financial Independence', desc: 'Budgeting, portfolio review and savings milestones' },
  ];

  const handleToggleFocus = (id: string) => {
    if (selectedFocus.includes(id)) {
      if (selectedFocus.length > 1) {
        setSelectedFocus(selectedFocus.filter((f) => f !== id));
      }
    } else {
      setSelectedFocus([...selectedFocus, id]);
    }
  };

  const handleFinish = async () => {
    setSaving(true);
    try {
      // Complete onboarding in AuthContext
      await completeOnboarding({
        displayName: displayName.trim() || 'Architect',
        roleTitle,
        defaultAvailabilityMinutes: Math.round(dailyHours * 60),
        gamificationEnabled: gamification,
        selectedCategories: selectedFocus,
      });

      // Optionally create clean personalized starter goals and tasks in the user's private account
      if (createStarterKit) {
        const goal1 = createGoal(
          {
            title: `Q4 Breakthrough: ${selectedFocus[0] || 'Focus Sprint'}`,
            description: `Primary personal objective configured during onboarding for ${displayName}.`,
            category: 'career',
            priority: 'critical',
            status: 'active',
          },
          ['Phase 1: Environment Setup', 'Phase 2: Core Execution', 'Phase 3: Launch Review']
        );

        createTask({
          title: `Configure personal IRL.OS workspace for ${displayName}`,
          description: 'Review default capacity hours and confirm high-priority milestones.',
          goalId: goal1.id,
          scheduledDate: new Date().toISOString().split('T')[0],
          slot: 'focus_now',
          estimatedMinutes: 45,
          priority: 'critical',
          status: 'todo',
        });

        createTask({
          title: 'Establish weekly focus block & review calendar',
          description: 'Ensure time allocation matches available daily capacity.',
          goalId: goal1.id,
          scheduledDate: new Date().toISOString().split('T')[0],
          slot: 'up_next',
          estimatedMinutes: 30,
          priority: 'high',
          status: 'todo',
        });
      }

      onNavigate('/app/today');
    } catch (err) {
      console.error('Failed to complete onboarding:', err);
      onNavigate('/app/today');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="relative min-h-screen bg-[#07080C] text-[#F4F5FA] flex flex-col justify-center items-center px-4 py-12 overflow-hidden selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Background Live Wave Canvas */}
      <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden">
        <LiveWaveCanvas className="w-full h-full opacity-60" intensity={1.0} showParticles={true} />
      </div>

      {/* Ambient gradient glow */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[650px] h-[400px] bg-gradient-to-tr from-cyan-500/15 via-violet-600/15 to-transparent blur-3xl pointer-events-none rounded-full" />

      {/* Main Container */}
      <div className="relative z-10 w-full max-w-xl">
        {/* Step Indicator */}
        <div className="flex items-center justify-between mb-6 px-1">
          <div className="flex items-center gap-2">
            {[1, 2, 3].map((s) => (
              <div
                key={s}
                className={`h-1.5 rounded-full transition-all duration-300 ${
                  s === step
                    ? 'w-10 bg-cyan-400 shadow-[0_0_10px_#06B6D4]'
                    : s < step
                    ? 'w-6 bg-cyan-400/40'
                    : 'w-6 bg-white/10'
                }`}
              />
            ))}
          </div>
          <button
            onClick={handleFinish}
            className="text-xs text-white/50 hover:text-white transition-colors"
          >
            Skip to Dashboard &rarr;
          </button>
        </div>

        {/* Card */}
        <div className="relative rounded-2xl bg-[#0D0F18]/90 border border-white/10 backdrop-blur-xl p-8 shadow-2xl shadow-black/80">
          <div className="absolute top-0 inset-x-8 h-[1px] bg-gradient-to-r from-transparent via-cyan-400/50 to-transparent" />

          {/* STEP 1: IDENTITY & ROLE */}
          {step === 1 && (
            <div className="space-y-6 animate-fadeIn">
              <div>
                <span className="text-xs font-mono text-cyan-400 tracking-wider uppercase">
                  Step 01 / 03 &bull; Profile Calibration
                </span>
                <h2 className="text-2xl font-bold text-white mt-1">
                  How should IRL.OS address you?
                </h2>
                <p className="text-sm text-white/60 mt-1">
                  Your identity and strategic perspective within your private command center.
                </p>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-white/75 mb-1.5">
                    Your Name or Handle
                  </label>
                  <input
                    type="text"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    placeholder="e.g. Elena Vance"
                    className="w-full px-4 py-2.5 bg-black/40 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:border-cyan-400/80 focus:ring-1 focus:ring-cyan-400/40 transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-white/75 mb-1.5">
                    Strategic Role / Focus Persona
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      'Systems Strategist',
                      'Founding Engineer',
                      'Creative Architect',
                      'Deep Work Operator',
                    ].map((title) => (
                      <button
                        key={title}
                        type="button"
                        onClick={() => setRoleTitle(title)}
                        className={`p-3 rounded-xl border text-left text-xs transition-all ${
                          roleTitle === title
                            ? 'bg-cyan-500/10 border-cyan-400/60 text-cyan-300 font-medium shadow-[0_0_12px_rgba(6,182,212,0.15)]'
                            : 'bg-black/30 border-white/5 text-white/60 hover:border-white/20 hover:text-white'
                        }`}
                      >
                        {title}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="pt-4 flex justify-end">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="px-6 py-2.5 rounded-xl text-sm font-medium text-black bg-cyan-400 hover:bg-cyan-300 transition-all shadow-[0_0_15px_rgba(6,182,212,0.3)] flex items-center gap-2"
                >
                  <span>Continue</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 2: FOCUS AREAS */}
          {step === 2 && (
            <div className="space-y-6 animate-fadeIn">
              <div>
                <span className="text-xs font-mono text-cyan-400 tracking-wider uppercase">
                  Step 02 / 03 &bull; Focus Arenas
                </span>
                <h2 className="text-2xl font-bold text-white mt-1">
                  What domains matter most right now?
                </h2>
                <p className="text-sm text-white/60 mt-1">
                  Select 1 to 3 active domains to align your milestone roadmaps.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {focusOptions.map((opt) => {
                  const isSelected = selectedFocus.includes(opt.id);
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => handleToggleFocus(opt.id)}
                      className={`p-3.5 rounded-xl border text-left transition-all ${
                        isSelected
                          ? 'bg-cyan-500/15 border-cyan-400 text-white shadow-[0_0_12px_rgba(6,182,212,0.15)]'
                          : 'bg-black/30 border-white/5 text-white/60 hover:border-white/15 hover:text-white/80'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-semibold">{opt.label}</span>
                        {isSelected && <CheckCircle2 className="w-4 h-4 text-cyan-400" />}
                      </div>
                      <p className="text-[11px] text-white/50">{opt.desc}</p>
                    </button>
                  );
                })}
              </div>

              <div className="pt-4 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="text-xs text-white/50 hover:text-white transition-colors"
                >
                  &larr; Back
                </button>
                <button
                  type="button"
                  onClick={() => setStep(3)}
                  className="px-6 py-2.5 rounded-xl text-sm font-medium text-black bg-cyan-400 hover:bg-cyan-300 transition-all shadow-[0_0_15px_rgba(6,182,212,0.3)] flex items-center gap-2"
                >
                  <span>Continue</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: CAPACITY & PROGRESSION */}
          {step === 3 && (
            <div className="space-y-6 animate-fadeIn">
              <div>
                <span className="text-xs font-mono text-cyan-400 tracking-wider uppercase">
                  Step 03 / 03 &bull; Capacity & Reality Check
                </span>
                <h2 className="text-2xl font-bold text-white mt-1">
                  Calibrate your daily bandwidth
                </h2>
                <p className="text-sm text-white/60 mt-1">
                  IRL.OS prevents over-scheduling by enforcing hard reality checks on your available hours.
                </p>
              </div>

              {/* Slider */}
              <div className="p-4 rounded-xl bg-black/40 border border-white/5 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs text-white/70">
                    <Clock className="w-4 h-4 text-cyan-400" />
                    <span>Daily Available Deep Work Time</span>
                  </div>
                  <span className="text-base font-bold text-cyan-400 font-mono">
                    {dailyHours.toFixed(1)} hrs/day ({Math.round(dailyHours * 60)}m)
                  </span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="10"
                  step="0.5"
                  value={dailyHours}
                  onChange={(e) => setDailyHours(parseFloat(e.target.value))}
                  className="w-full accent-cyan-400 h-1.5 bg-white/10 rounded-lg cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-white/30 font-mono">
                  <span>1h (Minimal)</span>
                  <span>4h (Balanced)</span>
                  <span>8h+ (Intense Sprint)</span>
                </div>
              </div>

              {/* Options */}
              <div className="space-y-2.5">
                <label className="flex items-start gap-3 p-3.5 rounded-xl bg-black/30 border border-white/5 cursor-pointer hover:border-white/10 transition-colors">
                  <input
                    type="checkbox"
                    checked={gamification}
                    onChange={(e) => setGamification(e.target.checked)}
                    className="mt-0.5 accent-cyan-400 rounded"
                  />
                  <div>
                    <div className="flex items-center gap-1.5 text-xs font-medium text-white">
                      <Flame className="w-3.5 h-3.5 text-amber-400" />
                      RPG-Inspired Progression (XP & Level Ups)
                    </div>
                    <p className="text-[11px] text-white/40 mt-0.5">
                      Earn XP deterministically based on focus duration without predatory streaks.
                    </p>
                  </div>
                </label>

                <label className="flex items-start gap-3 p-3.5 rounded-xl bg-black/30 border border-white/5 cursor-pointer hover:border-white/10 transition-colors">
                  <input
                    type="checkbox"
                    checked={createStarterKit}
                    onChange={(e) => setCreateStarterKit(e.target.checked)}
                    className="mt-0.5 accent-cyan-400 rounded"
                  />
                  <div>
                    <div className="flex items-center gap-1.5 text-xs font-medium text-white">
                      <Layers className="w-3.5 h-3.5 text-cyan-400" />
                      Generate Starter Goals & High-Impact Tasks
                    </div>
                    <p className="text-[11px] text-white/40 mt-0.5">
                      Seeds 1 active goal and 2 prioritized tasks into your private workspace so you can begin immediately.
                    </p>
                  </div>
                </label>
              </div>

              <div className="pt-4 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="text-xs text-white/50 hover:text-white transition-colors"
                >
                  &larr; Back
                </button>
                <button
                  type="button"
                  onClick={handleFinish}
                  disabled={saving}
                  className="px-7 py-3 rounded-xl text-sm font-medium text-black bg-gradient-to-r from-cyan-400 via-teal-300 to-cyan-300 hover:from-cyan-300 hover:to-teal-200 transition-all shadow-[0_0_20px_rgba(6,182,212,0.35)] flex items-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {saving ? (
                    <>
                      <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                      <span>Initializing Workspace...</span>
                    </>
                  ) : (
                    <>
                      <span>Launch IRL.OS Command Center</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
