import React, { useState } from 'react';
import { X, Target, Plus, Trash2 } from 'lucide-react';
import { GoalCategory, Priority } from '../types/index.ts';

interface GoalModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (goalData: any, milestones: string[]) => void;
}

export const GoalModal: React.FC<GoalModalProps> = ({ isOpen, onClose, onSave }) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<GoalCategory>('career');
  const [priority, setPriority] = useState<Priority>('high');
  const [deadline, setDeadline] = useState('');
  const [milestones, setMilestones] = useState<string[]>([
    'Define milestone 1 requirements and baseline test',
    'Execute core implementation sprint',
  ]);
  const [newMilestoneText, setNewMilestoneText] = useState('');

  if (!isOpen) return null;

  const handleAddMilestone = () => {
    if (newMilestoneText.trim()) {
      setMilestones([...milestones, newMilestoneText.trim()]);
      setNewMilestoneText('');
    }
  };

  const handleRemoveMilestone = (idx: number) => {
    setMilestones(milestones.filter((_, i) => i !== idx));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    onSave(
      {
        title: title.trim(),
        description: description.trim(),
        category,
        priority,
        deadline: deadline || undefined,
        status: 'active',
      },
      milestones
    );
    onClose();
  };

  const categories: GoalCategory[] = ['career', 'learning', 'fitness', 'creative', 'finance', 'lifestyle'];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-lg bg-[#121622] border border-[#252B3B] rounded-2xl shadow-2xl overflow-hidden animate-in fade-in duration-200">
        <div className="px-6 py-4 border-b border-[#252B3B] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Target size={18} className="text-[#A78BFA]" />
            <h2 className="text-base font-bold text-[#F4F5FA]">Define Life Goal & Roadmap</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-[#939BB0] hover:text-[#F4F5FA] hover:bg-[#181D2B] transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[85vh] overflow-y-auto">
          {/* Title */}
          <div>
            <label className="block text-xs font-mono uppercase text-[#939BB0] mb-1.5">
              Goal Ambition Title *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Master High-Performance Distributed Systems"
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#090A0F] border border-[#252B3B] text-[#F4F5FA] text-sm focus:border-[#A78BFA] outline-none transition-colors placeholder:text-gray-600"
            />
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-mono uppercase text-[#939BB0] mb-1.5">
              Purpose & Success Criteria
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Why this matters, target outcome, measurable impact..."
              className="w-full px-3.5 py-2 rounded-xl bg-[#090A0F] border border-[#252B3B] text-[#F4F5FA] text-xs focus:border-[#A78BFA] outline-none transition-colors placeholder:text-gray-600"
            />
          </div>

          {/* Category */}
          <div>
            <label className="block text-xs font-mono uppercase text-[#939BB0] mb-1.5">
              Category
            </label>
            <div className="grid grid-cols-3 gap-2">
              {categories.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setCategory(cat)}
                  className={`py-1.5 px-2 rounded-lg text-xs font-mono capitalize border transition-all ${
                    category === cat
                      ? 'bg-[#A78BFA]/20 border-[#A78BFA] text-[#A78BFA] font-bold'
                      : 'bg-[#090A0F] border-[#252B3B] text-[#939BB0] hover:text-[#F4F5FA]'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Priority & Deadline */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-mono uppercase text-[#939BB0] mb-1.5">
                Priority Level
              </label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as Priority)}
                className="w-full px-3 py-2 rounded-xl bg-[#090A0F] border border-[#252B3B] text-[#F4F5FA] text-xs focus:border-[#A78BFA] outline-none"
              >
                <option value="critical">Critical</option>
                <option value="high">High</option>
                <option value="medium">Medium</option>
                <option value="low">Low</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-mono uppercase text-[#939BB0] mb-1.5">
                Target Target Date
              </label>
              <input
                type="date"
                value={deadline}
                onChange={(e) => setDeadline(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-[#090A0F] border border-[#252B3B] text-[#F4F5FA] text-xs focus:border-[#A78BFA] outline-none"
              />
            </div>
          </div>

          {/* Roadmap Milestones */}
          <div>
            <label className="block text-xs font-mono uppercase text-[#939BB0] mb-1.5">
              Initial Roadmap Milestones
            </label>
            <div className="space-y-2 mb-2">
              {milestones.map((m, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between gap-2 p-2 rounded-lg bg-[#090A0F] border border-[#252B3B] text-xs text-[#F4F5FA]"
                >
                  <span className="font-mono text-[#67E8F9] shrink-0">#{idx + 1}</span>
                  <span className="flex-1 truncate">{m}</span>
                  <button
                    type="button"
                    onClick={() => handleRemoveMilestone(idx)}
                    className="text-[#939BB0] hover:text-[#FB7185] p-1"
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
              ))}
            </div>

            <div className="flex gap-2">
              <input
                type="text"
                value={newMilestoneText}
                onChange={(e) => setNewMilestoneText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddMilestone();
                  }
                }}
                placeholder="Add milestone checkpoint..."
                className="flex-1 px-3 py-1.5 rounded-lg bg-[#090A0F] border border-[#252B3B] text-xs text-[#F4F5FA] focus:border-[#A78BFA] outline-none"
              />
              <button
                type="button"
                onClick={handleAddMilestone}
                className="px-3 py-1.5 rounded-lg bg-[#181D2B] hover:bg-[#252B3B] text-xs font-medium text-[#67E8F9] border border-[#252B3B] flex items-center gap-1"
              >
                <Plus size={14} />
                <span>Add</span>
              </button>
            </div>
          </div>

          {/* Actions */}
          <div className="pt-3 border-t border-[#252B3B] flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-medium text-[#939BB0] hover:text-[#F4F5FA] hover:bg-[#181D2B] transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#A78BFA] to-[#8B5CF6] text-black font-semibold text-xs shadow-md shadow-violet-500/20 hover:opacity-95 transition-all"
            >
              Create Goal
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
