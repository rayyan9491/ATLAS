import React, { useState } from 'react';
import {
  BarChart2,
  CheckCircle2,
  Clock,
  TrendingUp,
  Download,
  Share2,
  Target,
  Sparkles,
  Calendar,
  AlertCircle,
  Award,
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { generateWeeklyRealityReport } from '../utils/reports.ts';

interface InsightsPageProps {
  onNavigate: (path: string) => void;
}

export const InsightsPage: React.FC<InsightsPageProps> = ({ onNavigate }) => {
  const { tasks, goals, userStats } = useApp();
  const [copiedNotification, setCopiedNotification] = useState(false);

  const weekDates = [
    '2026-10-19',
    '2026-10-20',
    '2026-10-21',
    '2026-10-22',
    '2026-10-23',
    '2026-10-24',
    '2026-10-25',
  ];

  const report = generateWeeklyRealityReport(tasks, goals, weekDates);

  const handleExportJson = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(report, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `irl_os_reality_report_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleShareSummary = () => {
    const summary = `IRL.OS Weekly Reality Report:\n- Completion: ${report.completionRate}% (${report.completedCount}/${report.plannedCount} tasks)\n- Execution: ${report.totalCompletedMinutes} mins logged\n- Observations: ${report.observations.join(' ')}`;
    navigator.clipboard.writeText(summary);
    setCopiedNotification(true);
    setTimeout(() => setCopiedNotification(false), 3000);
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-[#252B3B]">
        <div>
          <div className="text-xs font-mono text-[#A78BFA] uppercase tracking-wider font-semibold">
            Factual Progress Analytics
          </div>
          <h2 className="text-2xl font-extrabold text-[#F4F5FA] tracking-tight mt-0.5">
            Weekly Reality Report
          </h2>
          <p className="text-xs text-[#939BB0] mt-1">
            Data derived strictly from recorded task executions and milestone completions.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleShareSummary}
            className="px-3.5 py-2 rounded-xl bg-[#121622] hover:bg-[#181D2B] text-xs font-medium text-[#F4F5FA] border border-[#252B3B] transition-colors flex items-center gap-1.5"
          >
            <Share2 size={14} className="text-[#67E8F9]" />
            <span>{copiedNotification ? 'Copied to Clipboard!' : 'Share Digest'}</span>
          </button>

          <button
            onClick={handleExportJson}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#A78BFA] to-[#8B5CF6] text-black font-semibold text-xs shadow-md shadow-violet-500/20 hover:opacity-95 transition-all flex items-center gap-1.5"
          >
            <Download size={14} />
            <span>Export Report JSON</span>
          </button>
        </div>
      </div>

      {/* Top 4 Key Metric Tiles */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-[#121622] border border-[#252B3B]">
          <div className="flex items-center justify-between text-xs text-[#939BB0] mb-2 font-mono">
            <span>COMPLETION VELOCITY</span>
            <CheckCircle2 size={16} className="text-[#4ADE80]" />
          </div>
          <div className="text-3xl font-mono font-bold text-[#F4F5FA]">
            {report.completionRate}%
          </div>
          <p className="text-[11px] text-[#939BB0] mt-1">
            {report.completedCount} of {report.plannedCount} planned tasks completed
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-[#121622] border border-[#252B3B]">
          <div className="flex items-center justify-between text-xs text-[#939BB0] mb-2 font-mono">
            <span>TIME EXECUTED</span>
            <Clock size={16} className="text-[#67E8F9]" />
          </div>
          <div className="text-3xl font-mono font-bold text-[#67E8F9]">
            {report.totalCompletedMinutes}m
          </div>
          <p className="text-[11px] text-[#939BB0] mt-1">
            of {report.totalPlannedMinutes}m total work scheduled
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-[#121622] border border-[#252B3B]">
          <div className="flex items-center justify-between text-xs text-[#939BB0] mb-2 font-mono">
            <span>TASKS DEFERRED</span>
            <AlertCircle size={16} className="text-[#FBBF24]" />
          </div>
          <div className="text-3xl font-mono font-bold text-[#F4F5FA]">
            {report.postponedCount}
          </div>
          <p className="text-[11px] text-[#939BB0] mt-1">
            tasks moved without silent dropping
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-[#121622] border border-[#252B3B]">
          <div className="flex items-center justify-between text-xs text-[#939BB0] mb-2 font-mono">
            <span>MILESTONES REACHED</span>
            <Award size={16} className="text-[#A78BFA]" />
          </div>
          <div className="text-3xl font-mono font-bold text-[#A78BFA]">
            {report.milestonesReached.length}
          </div>
          <p className="text-[11px] text-[#939BB0] mt-1">
            verifiable checkpoint gates passed
          </p>
        </div>
      </div>

      {/* Visual Chart Section: Planned vs Completed Daily Velocity */}
      <div className="p-6 rounded-2xl bg-[#0D1018] border border-[#252B3B] space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-[#252B3B]">
          <div className="flex items-center gap-2">
            <TrendingUp size={16} className="text-[#67E8F9]" />
            <h3 className="text-sm font-bold text-[#F4F5FA] tracking-tight">
              Weekly Planned vs Completed Load by Day
            </h3>
          </div>
          <div className="flex items-center gap-4 text-xs font-mono">
            <span className="flex items-center gap-1.5 text-[#939BB0]">
              <span className="w-2.5 h-2.5 rounded bg-[#181D2B] border border-[#252B3B]" />
              <span>Planned (mins)</span>
            </span>
            <span className="flex items-center gap-1.5 text-[#A78BFA]">
              <span className="w-2.5 h-2.5 rounded bg-[#A78BFA]" />
              <span>Completed (mins)</span>
            </span>
          </div>
        </div>

        {/* Bar chart columns */}
        <div className="grid grid-cols-7 gap-3 pt-6 pb-2 h-52 items-end">
          {weekDates.map((dateStr) => {
            const dayName = new Date(dateStr).toLocaleDateString('en-US', { weekday: 'short' });
            const dayTasks = tasks.filter((t) => t.scheduledDate === dateStr);
            const planned = dayTasks.reduce((acc, t) => acc + (t.estimatedMinutes || 0), 0);
            const completed = dayTasks
              .filter((t) => t.status === 'completed')
              .reduce((acc, t) => acc + (t.actualMinutes || t.estimatedMinutes || 0), 0);

            const maxMins = 200;
            const plannedHeight = Math.min(100, Math.round((planned / maxMins) * 100));
            const completedHeight = Math.min(100, Math.round((completed / maxMins) * 100));

            return (
              <div key={dateStr} className="flex flex-col items-center h-full justify-end gap-2 group">
                <div className="w-full flex items-end justify-center gap-1.5 h-36">
                  {/* Planned Bar */}
                  <div
                    className="w-4 sm:w-6 bg-[#181D2B] border border-[#252B3B] rounded-t-md transition-all group-hover:bg-[#252B3B]"
                    style={{ height: `${plannedHeight}%` }}
                    title={`Planned: ${planned}m`}
                  />
                  {/* Completed Bar */}
                  <div
                    className="w-4 sm:w-6 bg-gradient-to-t from-[#8B5CF6] to-[#A78BFA] rounded-t-md transition-all"
                    style={{ height: `${completedHeight}%` }}
                    title={`Completed: ${completed}m`}
                  />
                </div>
                <div className="text-center">
                  <span className="text-xs font-bold text-[#F4F5FA] block">{dayName}</span>
                  <span className="text-[10px] font-mono text-[#939BB0]">{completed}m</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Observations & Realistic Adjustments Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Factual Observations */}
        <div className="p-6 rounded-2xl bg-[#121622] border border-[#252B3B] space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-[#252B3B]">
            <Sparkles size={16} className="text-[#A78BFA]" />
            <h3 className="text-sm font-bold text-[#F4F5FA]">Factual Behavioral Observations</h3>
          </div>
          <div className="space-y-3 text-xs leading-relaxed text-[#939BB0]">
            {report.observations.map((obs, idx) => (
              <div key={idx} className="flex items-start gap-2.5 p-3 rounded-xl bg-[#090A0F] border border-[#252B3B]">
                <span className="font-mono text-[#67E8F9] shrink-0 font-bold">#{idx + 1}</span>
                <span className="text-[#F4F5FA]">{obs}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Realistic Adjustments */}
        <div className="p-6 rounded-2xl bg-[#121622] border border-[#252B3B] space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-[#252B3B]">
            <Target size={16} className="text-[#67E8F9]" />
            <h3 className="text-sm font-bold text-[#F4F5FA]">Recommended Protocol Adjustments</h3>
          </div>
          <div className="space-y-3 text-xs leading-relaxed text-[#939BB0]">
            {report.recommendations.map((rec, idx) => (
              <div key={idx} className="flex items-start gap-2.5 p-3 rounded-xl bg-[#090A0F] border border-[#252B3B]">
                <CheckCircle2 size={16} className="text-[#4ADE80] shrink-0 mt-0.5" />
                <span className="text-[#F4F5FA]">{rec}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
