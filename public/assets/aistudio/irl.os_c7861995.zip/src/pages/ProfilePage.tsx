import React, { useState } from 'react';
import {
  User,
  Award,
  Zap,
  ShieldCheck,
  Edit2,
  Check,
  TrendingUp,
  History,
  Layers,
  Sparkles,
  LogOut,
  Mail,
  Fingerprint,
  Calendar,
  Globe,
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { useAuth } from '../context/AuthContext.tsx';
import { getProgressToNextLevel } from '../utils/progression.ts';

interface ProfilePageProps {
  onNavigate: (path: string) => void;
}

export const ProfilePage: React.FC<ProfilePageProps> = ({ onNavigate }) => {
  const { userStats, updateUserStats, xpLedger, tasks, goals } = useApp();
  const { user, userProfile, updateDisplayName, signOut } = useAuth();

  const [isEditing, setIsEditing] = useState(false);
  const [displayName, setDisplayName] = useState(userProfile?.displayName || userStats.displayName);
  const [saving, setSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const progress = getProgressToNextLevel(userStats.xp);
  const completedTasks = tasks.filter((t) => t.status === 'completed');

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = displayName.trim();
    if (!cleanName) return;

    setSaving(true);
    try {
      if (user) {
        await updateDisplayName(cleanName);
      }
      updateUserStats({ displayName: cleanName });
      setIsEditing(false);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 2500);
    } catch (err) {
      console.error('Failed to update display name:', err);
    } finally {
      setSaving(false);
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut();
      onNavigate('/signin');
    } catch (err) {
      console.error('Sign out error:', err);
    }
  };

  const achievements = [
    {
      title: 'First Milestone Gate',
      desc: 'Completed and verified your first roadmap milestone',
      unlocked: tasks.some((t) => t.status === 'completed'),
      date: 'Earned in System',
    },
    {
      title: 'Reality Balance Master',
      desc: 'Maintained a balanced workload within available time',
      unlocked: true,
      date: 'Active Protocol',
    },
    {
      title: 'Deep Work Flow',
      desc: 'Finished a 45+ minute focused execution block',
      unlocked: tasks.some((t) => (t.actualMinutes || 0) >= 45),
      date: 'Telemetry Verified',
    },
    {
      title: 'Grand System Architect',
      desc: 'Reach Level 25 in personal execution mastery',
      unlocked: userStats.level >= 25,
      date: userStats.level >= 25 ? 'Unlocked' : `Level ${userStats.level}/25`,
    },
  ];

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="pb-2 border-b border-[#252B3B] flex items-center justify-between">
        <div>
          <div className="text-xs font-mono text-[#A78BFA] uppercase tracking-wider font-semibold">
            Operator Dossier
          </div>
          <h2 className="text-2xl font-extrabold text-[#F4F5FA] tracking-tight mt-0.5">
            User Profile & Progression
          </h2>
          <p className="text-xs text-[#939BB0] mt-1">
            Review your verified execution track record, private account credentials, and earned progression.
          </p>
        </div>

        <button
          onClick={handleSignOut}
          className="px-3.5 py-1.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <LogOut size={14} />
          <span>Sign Out</span>
        </button>
      </div>

      {/* Main Profile Card */}
      <div className="p-6 rounded-2xl bg-gradient-to-br from-[#121622] via-[#151A29] to-[#181D2B] border border-[#252B3B] relative overflow-hidden flex flex-col md:flex-row items-center md:items-start justify-between gap-6 shadow-xl">
        <div className="flex flex-col sm:flex-row items-center gap-5 text-center sm:text-left">
          {/* Avatar Icon */}
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-[#181D2B] via-[#252B3B] to-[#A78BFA]/30 border-2 border-[#A78BFA]/60 flex items-center justify-center font-bold text-2xl text-[#F4F5FA] shadow-xl relative">
            <span>{(userProfile?.displayName || userStats.displayName || 'A').charAt(0).toUpperCase()}</span>
            <div className="absolute -bottom-2 -right-2 bg-[#090A0F] border border-[#A78BFA] text-[#A78BFA] text-[10px] font-mono font-bold px-2 py-0.5 rounded-full">
              LVL {progress.currentLevel}
            </div>
          </div>

          <div>
            {isEditing ? (
              <form onSubmit={handleSaveProfile} className="flex items-center gap-2">
                <input
                  type="text"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  className="px-3 py-1.5 rounded-lg bg-[#090A0F] border border-cyan-400 text-sm text-[#F4F5FA] outline-none font-medium"
                />
                <button
                  type="submit"
                  disabled={saving}
                  className="p-1.5 rounded-lg bg-cyan-400 text-black font-semibold cursor-pointer disabled:opacity-50"
                  title="Save Display Name"
                >
                  <Check size={14} />
                </button>
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="text-xs text-white/50 hover:text-white px-2"
                >
                  Cancel
                </button>
              </form>
            ) : (
              <div className="flex items-center gap-2">
                <h3 className="text-xl font-bold text-[#F4F5FA]">
                  {userProfile?.displayName || userStats.displayName}
                </h3>
                <button
                  onClick={() => {
                    setDisplayName(userProfile?.displayName || userStats.displayName);
                    setIsEditing(true);
                  }}
                  className="p-1 rounded text-[#939BB0] hover:text-[#F4F5FA] transition-colors"
                  title="Edit Display Name"
                >
                  <Edit2 size={13} />
                </button>
                {saveSuccess && (
                  <span className="text-[11px] font-mono text-[#4ADE80]">Updated!</span>
                )}
              </div>
            )}
            <div className="text-xs font-mono text-[#A78BFA] mt-0.5 font-semibold">
              {userProfile?.roleTitle || userStats.title}
            </div>
            <p className="text-xs text-[#939BB0] mt-1">
              Private IRL.OS Account • {completedTasks.length} tasks completed • {goals.length} active goals
            </p>
          </div>
        </div>

        {/* Level Progression Progress */}
        <div className="w-full sm:w-64 p-4 rounded-xl bg-[#090A0F] border border-[#252B3B] space-y-2 text-xs">
          <div className="flex justify-between font-mono">
            <span className="text-[#939BB0]">XP PROGRESS</span>
            <span className="text-[#67E8F9] font-bold">{userStats.xp} XP</span>
          </div>
          <div className="w-full bg-[#181D2B] h-2 rounded-full overflow-hidden">
            <div
              className="bg-gradient-to-r from-[#A78BFA] to-[#67E8F9] h-full rounded-full transition-all duration-500"
              style={{ width: `${progress.progressPercent}%` }}
            />
          </div>
          <div className="flex justify-between text-[10px] font-mono text-[#939BB0]">
            <span>Level {progress.currentLevel}</span>
            <span>Next: Level {progress.currentLevel + 1}</span>
          </div>
        </div>
      </div>

      {/* Account Identity & Security Credentials */}
      <div className="p-6 rounded-2xl bg-[#0D1018] border border-[#252B3B] space-y-4">
        <div className="pb-3 border-b border-[#252B3B] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck size={16} className="text-cyan-400" />
            <h3 className="text-sm font-bold text-[#F4F5FA]">Private Account Identity</h3>
          </div>
          <span className="text-[11px] font-mono text-cyan-400 bg-cyan-500/10 border border-cyan-500/30 px-2 py-0.5 rounded">
            ISOLATED TENANT
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
          <div className="p-3.5 rounded-xl bg-[#121622] border border-[#252B3B] space-y-1">
            <div className="flex items-center gap-1.5 text-[11px] text-[#939BB0]">
              <Mail size={13} className="text-violet-400" />
              <span>Email Address</span>
            </div>
            <div className="text-xs font-mono text-[#F4F5FA] truncate">
              {user?.email || userProfile?.email || 'sixtynine9491@gmail.com'}
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-[#121622] border border-[#252B3B] space-y-1">
            <div className="flex items-center gap-1.5 text-[11px] text-[#939BB0]">
              <Fingerprint size={13} className="text-cyan-400" />
              <span>User UID (Tenant Key)</span>
            </div>
            <div className="text-xs font-mono text-white/70 truncate" title={user?.uid || 'N/A'}>
              {user?.uid || 'local-tenant-uid'}
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-[#121622] border border-[#252B3B] space-y-1">
            <div className="flex items-center gap-1.5 text-[11px] text-[#939BB0]">
              <Calendar size={13} className="text-emerald-400" />
              <span>Registered On</span>
            </div>
            <div className="text-xs font-mono text-[#F4F5FA]">
              {userProfile?.createdAt
                ? new Date(userProfile.createdAt).toLocaleDateString()
                : 'Current Cycle'}
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-[#121622] border border-[#252B3B] space-y-1">
            <div className="flex items-center gap-1.5 text-[11px] text-[#939BB0]">
              <Globe size={13} className="text-amber-400" />
              <span>Timezone Baseline</span>
            </div>
            <div className="text-xs font-mono text-[#F4F5FA] truncate">
              {userProfile?.timeZone || Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC'}
            </div>
          </div>
        </div>
      </div>

      {/* Verifiable Achievements */}
      <div className="p-6 rounded-2xl bg-[#0D1018] border border-[#252B3B] space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-[#252B3B]">
          <div className="flex items-center gap-2">
            <Award size={16} className="text-[#67E8F9]" />
            <h3 className="text-sm font-bold text-[#F4F5FA]">Verifiable Milestones & Achievements</h3>
          </div>
          <span className="text-xs font-mono text-[#939BB0]">
            {achievements.filter((a) => a.unlocked).length} / {achievements.length} Unlocked
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {achievements.map((ach, idx) => (
            <div
              key={idx}
              className={`p-3.5 rounded-xl border flex items-center justify-between gap-3 ${
                ach.unlocked
                  ? 'bg-[#121622] border-[#252B3B]'
                  : 'bg-[#121622]/40 border-[#252B3B] opacity-50'
              }`}
            >
              <div className="flex items-center gap-3">
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                    ach.unlocked
                      ? 'bg-[#A78BFA]/20 text-[#A78BFA] border border-[#A78BFA]/40'
                      : 'bg-[#181D2B] text-[#939BB0]'
                  }`}
                >
                  <Award size={18} />
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-[#F4F5FA]">{ach.title}</h4>
                  <p className="text-[11px] text-[#939BB0] mt-0.5">{ach.desc}</p>
                </div>
              </div>
              <span className="text-[10px] font-mono text-[#67E8F9] shrink-0">{ach.date}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Immutable XP Audit Ledger */}
      <div className="p-6 rounded-2xl bg-[#0D1018] border border-[#252B3B] space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-[#252B3B]">
          <div className="flex items-center gap-2">
            <History size={16} className="text-[#A78BFA]" />
            <h3 className="text-sm font-bold text-[#F4F5FA]">XP Award Ledger (Audit Trail)</h3>
          </div>
          <span className="text-xs font-mono text-[#939BB0]">
            {xpLedger.length} events logged in private record
          </span>
        </div>

        <div className="space-y-2 max-h-56 overflow-y-auto">
          {xpLedger.length === 0 ? (
            <div className="text-center py-6 text-xs text-white/40">
              No XP awards recorded yet. Complete planned tasks or milestone checkpoints to earn verifiable progression.
            </div>
          ) : (
            xpLedger.map((entry) => (
              <div
                key={entry.id}
                className="p-2.5 rounded-lg bg-[#121622] border border-[#252B3B] flex items-center justify-between text-xs font-mono"
              >
                <div className="flex items-center gap-2 truncate pr-2">
                  <span className="text-[#4ADE80] font-bold">+{entry.xpAwarded} XP</span>
                  <span className="text-[#F4F5FA] truncate">{entry.reason}</span>
                </div>
                <span className="text-[#939BB0] text-[10px] shrink-0">
                  {entry.timestamp.split('T')[0]}
                </span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
