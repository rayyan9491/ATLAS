import {
  Compass,
  Calendar,
  Target,
  Sparkles,
  Zap,
  BarChart2,
  User,
  Settings,
  Flame,
  LayoutGrid,
  RotateCcw,
  ExternalLink,
  LogOut,
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { useAuth } from '../context/AuthContext.tsx';
import { getProgressToNextLevel } from '../utils/progression.ts';

interface SidebarProps {
  currentPath: string;
  onNavigate: (path: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentPath, onNavigate }) => {
  const { userStats, setShowReferenceModal, resetToDemoData } = useApp();
  const { user, userProfile, signOut } = useAuth();

  const progress = getProgressToNextLevel(userStats.xp);
  const activeDisplayName = userProfile?.displayName || userStats.displayName || 'Architect';

  const navItems = [
    { path: '/app/deck', label: 'Master 1-Page Deck', icon: LayoutGrid, badge: 'All-in-1' },
    { path: '/app/today', label: 'Today Command', icon: Compass, badge: 'Main' },
    { path: '/app/goals', label: 'Goals & Maps', icon: Target },
    { path: '/app/plan', label: 'Planner', icon: Calendar },
    { path: '/app/focus', label: 'Focus Room', icon: Zap },
    { path: '/app/insights', label: 'Reality Report', icon: BarChart2 },
    { path: '/app/coach', label: 'AI Perspective', icon: Sparkles, highlight: true },
  ];

  return (
    <aside className="w-64 bg-[#0D1018] border-r border-[#252B3B] flex flex-col h-screen shrink-0 select-none">
      {/* Brand Wordmark */}
      <div className="p-5 border-b border-[#252B3B] flex items-center justify-between">
        <button
          onClick={() => onNavigate('/')}
          className="flex items-center gap-3 text-left group transition-all"
        >
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#A78BFA] to-[#67E8F9] flex items-center justify-center shadow-lg shadow-violet-500/20 group-hover:scale-105 transition-transform">
            <span className="font-mono text-black font-extrabold text-sm tracking-wider">IRL</span>
          </div>
          <div>
            <div className="text-base font-bold tracking-tight text-[#F4F5FA] flex items-center gap-1.5">
              <span>IRL.OS</span>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#181D2B] text-[#A78BFA] border border-[#252B3B]">
                v1.0
              </span>
            </div>
            <p className="text-[11px] text-[#939BB0] tracking-wide">Personal Operating System</p>
          </div>
        </button>
      </div>

      {/* Profile & Level Progression (RPG-inspired HUD) */}
      {userStats.gamificationEnabled && (
        <div className="p-4 mx-3 my-3 rounded-xl bg-[#121622] border border-[#252B3B] relative overflow-hidden">
          <div className="absolute top-0 right-0 w-24 h-24 bg-violet-500/5 rounded-full blur-xl pointer-events-none" />
          <div className="flex items-center gap-3 mb-2.5">
            <div className="relative">
              <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-[#181D2B] via-[#252B3B] to-[#A78BFA]/40 border border-[#A78BFA]/50 flex items-center justify-center font-bold text-sm text-[#F4F5FA]">
                {(userProfile?.displayName || userStats.displayName || 'A').charAt(0).toUpperCase()}
              </div>
              <div className="absolute -bottom-1 -right-1 bg-[#090A0F] border border-[#A78BFA] text-[#A78BFA] text-[9px] font-mono font-bold px-1 rounded-full">
                L{progress.currentLevel}
              </div>
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold text-[#F4F5FA] truncate">
                  {userProfile?.displayName || userStats.displayName}
                </span>
                <span className="text-[11px] font-mono font-medium text-[#67E8F9]">
                  {userStats.xp} XP
                </span>
              </div>
              <p className="text-[11px] text-[#A78BFA] truncate font-medium">{userProfile?.roleTitle || userStats.title}</p>
            </div>
          </div>

          {/* XP Bar */}
          <div className="space-y-1">
            <div className="w-full bg-[#181D2B] h-1.5 rounded-full overflow-hidden border border-[#252B3B]/60">
              <div
                className="bg-gradient-to-r from-[#A78BFA] to-[#67E8F9] h-full rounded-full transition-all duration-500 ease-out"
                style={{ width: `${progress.progressPercent}%` }}
              />
            </div>
            <div className="flex justify-between text-[10px] font-mono text-[#939BB0]">
              <span>Next Lvl: {progress.xpNeededForNext} XP</span>
              <span>{progress.progressPercent}%</span>
            </div>
          </div>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 px-3 py-2 space-y-1 overflow-y-auto">
        <div className="px-3 py-1 text-[10px] font-mono tracking-wider uppercase text-[#939BB0]/70 font-semibold">
          System Core
        </div>
        {navItems.map((item) => {
          const isActive = currentPath === item.path || (item.path === '/app/goals' && currentPath.startsWith('/app/goals'));
          const Icon = item.icon;
          return (
            <button
              key={item.path}
              onClick={() => onNavigate(item.path)}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all ${
                isActive
                  ? 'bg-[#181D2B] text-[#F4F5FA] border border-[#A78BFA]/40 shadow-sm shadow-violet-500/10'
                  : 'text-[#939BB0] hover:text-[#F4F5FA] hover:bg-[#121622] border border-transparent'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon
                  size={18}
                  className={
                    isActive
                      ? 'text-[#A78BFA]'
                      : item.highlight
                      ? 'text-[#67E8F9]'
                      : 'text-[#939BB0]'
                  }
                />
                <span>{item.label}</span>
              </div>
              {item.highlight && !isActive && (
                <span className="w-2 h-2 rounded-full bg-[#67E8F9] animate-pulse" />
              )}
            </button>
          );
        })}

        <div className="pt-4 px-3 py-1 text-[10px] font-mono tracking-wider uppercase text-[#939BB0]/70 font-semibold">
          Preferences
        </div>
        <button
          onClick={() => onNavigate('/app/profile')}
          className={`w-full flex items-center gap-3 px-3.5 py-2 rounded-xl text-sm font-medium transition-all ${
            currentPath === '/app/profile'
              ? 'bg-[#181D2B] text-[#F4F5FA] border border-[#A78BFA]/40'
              : 'text-[#939BB0] hover:text-[#F4F5FA] hover:bg-[#121622] border border-transparent'
          }`}
        >
          <User size={18} />
          <span>Profile & Stats</span>
        </button>

        <button
          onClick={() => onNavigate('/app/settings')}
          className={`w-full flex items-center gap-3 px-3.5 py-2 rounded-xl text-sm font-medium transition-all ${
            currentPath === '/app/settings'
              ? 'bg-[#181D2B] text-[#F4F5FA] border border-[#A78BFA]/40'
              : 'text-[#939BB0] hover:text-[#F4F5FA] hover:bg-[#121622] border border-transparent'
          }`}
        >
          <Settings size={18} />
          <span>Settings</span>
        </button>
      </nav>

      {/* Footer controls: Design Reference Board viewer & Sign Out */}
      <div className="p-3 border-t border-[#252B3B] space-y-2">
        <button
          onClick={() => setShowReferenceModal(true)}
          className="w-full flex items-center justify-between px-3 py-2 rounded-lg bg-[#121622] hover:bg-[#181D2B] text-[12px] font-medium text-[#67E8F9] border border-[#67E8F9]/30 transition-all group"
          title="Inspect the generated multi-page UI Design Reference Board"
        >
          <div className="flex items-center gap-2">
            <LayoutGrid size={15} />
            <span>UI Reference Board</span>
          </div>
          <span className="text-[10px] font-mono px-1 rounded bg-[#67E8F9]/10 border border-[#67E8F9]/30">
            SPEC
          </span>
        </button>

        {user ? (
          <button
            onClick={async () => {
              await signOut();
              onNavigate('/signin');
            }}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-xs font-semibold text-rose-300 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/25 transition-colors cursor-pointer"
          >
            <LogOut size={13} />
            <span>Sign Out ({activeDisplayName.split(' ')[0]})</span>
          </button>
        ) : (
          <button
            onClick={() => onNavigate('/signin')}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-xs font-semibold text-cyan-300 bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/25 transition-colors cursor-pointer"
          >
            <span>Sign In to IRL.OS</span>
          </button>
        )}
      </div>
    </aside>
  );
};
