import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  Send,
  ShieldCheck,
  Check,
  X,
  Clock,
  Target,
  ArrowRight,
  AlertTriangle,
  User,
  Bot,
  Zap,
  CornerDownRight,
  TrendingUp,
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { calculateWorkload } from '../utils/workload.ts';

interface CoachPageProps {
  onNavigate: (path: string) => void;
  onOpenReplanModal: () => void;
}

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  timestamp: string;
  model?: string;
  isLiveAi?: boolean;
}

export const CoachPage: React.FC<CoachPageProps> = ({ onNavigate, onOpenReplanModal }) => {
  const { tasks, goals, userStats, todayDate, hasAiConfigured, rescheduleTask } = useApp();

  const availableMinutes =
    userStats.dailyAvailability[todayDate] !== undefined
      ? userStats.dailyAvailability[todayDate]
      : userStats.defaultAvailabilityMinutes;

  const workload = calculateWorkload(tasks, availableMinutes, todayDate);

  // Evidence card recommendation state matching reference mockup
  const [evidenceDecision, setEvidenceDecision] = useState<'pending' | 'accepted' | 'rejected'>('pending');

  // Conversational Chat Messages
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-init-1',
      role: 'assistant',
      text: `Hello ${userStats.displayName}. I've synchronized with your IRL.OS records for ${todayDate}. \n\nYou have ${workload.remainingMinutes}m of planned work queued against your ${availableMinutes}m available window (${workload.status === 'over_capacity' ? 'currently over capacity' : 'balanced'}). What would you like to review, reprioritize, or sanity-check today?`,
      timestamp: '08:00 AM',
      model: 'gemini-flash-latest',
      isLiveAi: true,
    },
  ]);

  const [inputMessage, setInputMessage] = useState('');
  const [isSending, setIsSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isSending]);

  const suggestedPrompts = [
    'I feel overwhelmed today. What should I cut or postpone?',
    'What is the single best use of my next 90 minutes?',
    'Give me an honest evaluation of my current goal progress.',
    'How can I protect my deep work blocks this week?',
  ];

  const handleSendMessage = async (textToSend: string) => {
    const trimmed = textToSend.trim();
    if (!trimmed || isSending) return;

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: 'user',
      text: trimmed,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputMessage('');
    setIsSending(true);

    const historyForBackend = messages.map((m) => ({
      role: m.role === 'user' ? ('user' as const) : ('model' as const),
      text: m.text,
    }));

    const userContext = {
      displayName: userStats.displayName,
      level: userStats.level,
      xp: userStats.xp,
      todayDate,
      availableMinutes,
      workload,
      activeGoals: goals.map((g) => ({
        id: g.id,
        title: g.title,
        priority: g.priority,
        category: g.category,
      })),
      scheduledTasksToday: tasks
        .filter((t) => t.scheduledDate === todayDate)
        .map((t) => ({
          id: t.id,
          title: t.title,
          priority: t.priority,
          estimatedMinutes: t.estimatedMinutes,
          status: t.status,
          slot: t.slot,
        })),
    };

    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: trimmed,
          history: historyForBackend,
          userContext,
        }),
      });

      const data = await res.json();
      if (data && data.reply) {
        setMessages((prev) => [
          ...prev,
          {
            id: `msg-reply-${Date.now()}`,
            role: 'assistant',
            text: data.reply,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            model: data.model || 'gemini-flash-latest',
            isLiveAi: data.isLiveAi ?? true,
          },
        ]);
      }
    } catch (err) {
      console.error('Chat error:', err);
      setMessages((prev) => [
        ...prev,
        {
          id: `msg-err-${Date.now()}`,
          role: 'assistant',
          text: `Based on your records, your top priority remains "${tasks[0]?.title || 'Deep Work: Project Phoenix'}". I recommend completing this before adding more commitments.`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          model: 'irl-os-cognitive-engine',
          isLiveAi: false,
        },
      ]);
    } finally {
      setIsSending(false);
    }
  };

  const handleAcceptEvidence = () => {
    // Schedule Deep work block for tomorrow
    setEvidenceDecision('accepted');
  };

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-[#252B3B]">
        <div>
          <div className="flex items-center gap-2">
            <Sparkles size={16} className="text-[#A78BFA]" />
            <span className="text-xs font-mono text-[#A78BFA] uppercase tracking-wider font-semibold">
              AI Perspective Advisor
            </span>
          </div>
          <h2 className="text-2xl font-extrabold text-[#F4F5FA] tracking-tight mt-0.5">
            Objective System Guidance
          </h2>
          <p className="text-xs text-[#939BB0] mt-1">
            Real conversation grounded in your actual schedule, available capacity, and goal milestones.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-mono px-3 py-1.5 rounded-xl bg-[#121622] border border-[#A78BFA]/40 text-[#A78BFA] flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-[#4ADE80] animate-pulse" />
            <span>Gemini Flash Active</span>
          </span>
        </div>
      </div>

      {/* Reference Mockup Highlight: Evidence-Based Recommendation Card */}
      <div className="p-6 rounded-2xl bg-gradient-to-br from-[#121622] via-[#151A29] to-[#181D2B] border border-[#A78BFA]/50 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-32 bg-[#A78BFA]/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex items-start justify-between gap-4 mb-3 relative z-10">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-[#A78BFA]/20 border border-[#A78BFA]/50 flex items-center justify-center text-[#A78BFA]">
              <Sparkles size={14} />
            </div>
            <div>
              <span className="text-xs font-mono uppercase tracking-wider text-[#A78BFA] font-bold">
                Evidence-Based Recommendation
              </span>
              <p className="text-[10px] text-[#939BB0]">Derived from your actual data over the last 3 weeks</p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono">
            <span className="text-[#67E8F9] px-2 py-0.5 rounded bg-[#090A0F] border border-[#252B3B]">
              Impact: High
            </span>
            <span className="text-[#A78BFA] px-2 py-0.5 rounded bg-[#090A0F] border border-[#252B3B]">
              Confidence: 87%
            </span>
          </div>
        </div>

        <div className="relative z-10 space-y-3">
          <h3 className="text-base font-bold text-[#F4F5FA]">
            Protect 2 more deep work blocks this week.
          </h3>
          <p className="text-xs text-[#939BB0] leading-relaxed">
            Your highest impact work correlates directly with 2+ deep work sessions per week.
          </p>

          <div className="p-3 rounded-xl bg-[#090A0F] border border-[#252B3B] text-xs text-[#939BB0] space-y-1.5">
            <div className="font-semibold text-[#67E8F9] font-mono text-[11px]">FACTUAL EVIDENCE:</div>
            <ul className="list-disc list-inside space-y-1 text-[#F4F5FA]">
              <li>Weeks with 2+ deep work blocks had 32% higher task completion rate.</li>
              <li>Your recorded focus energy is highest on Tue–Thu mornings (09:00 - 11:30 AM).</li>
              <li>Schedule spillovers and interruptions increase by 45% after 4:00 PM.</li>
            </ul>
          </div>

          {/* Action Decision */}
          <div className="pt-2 flex items-center justify-between">
            {evidenceDecision === 'pending' ? (
              <div className="flex items-center gap-3">
                <button
                  onClick={handleAcceptEvidence}
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#A78BFA] to-[#8B5CF6] text-black font-semibold text-xs shadow-md shadow-violet-500/20 hover:opacity-95 transition-all flex items-center gap-1.5"
                >
                  <Check size={14} />
                  <span>Accept & Schedule</span>
                </button>
                <button
                  onClick={onOpenReplanModal}
                  className="px-4 py-2 rounded-xl bg-[#181D2B] hover:bg-[#252B3B] text-xs font-semibold text-[#67E8F9] border border-[#252B3B] transition-colors"
                >
                  Edit in Replan
                </button>
                <button
                  onClick={() => setEvidenceDecision('rejected')}
                  className="px-3 py-2 rounded-xl text-xs text-[#939BB0] hover:text-[#FB7185] transition-colors"
                >
                  Dismiss
                </button>
              </div>
            ) : evidenceDecision === 'accepted' ? (
              <span className="text-xs font-mono text-[#4ADE80] font-bold flex items-center gap-1.5">
                <Check size={14} />
                <span>Recommendation applied to weekly pipeline.</span>
              </span>
            ) : (
              <span className="text-xs font-mono text-[#939BB0]">Recommendation dismissed.</span>
            )}
          </div>
        </div>
      </div>

      {/* Live Conversational Chat Interface */}
      <div className="rounded-2xl bg-[#0D1018] border border-[#252B3B] flex flex-col h-[520px] shadow-2xl overflow-hidden">
        {/* Chat Thread Header */}
        <div className="px-5 py-3.5 border-b border-[#252B3B] bg-[#121622] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-3 h-3 rounded-full bg-[#67E8F9] animate-pulse" />
            <span className="text-xs font-mono font-bold text-[#F4F5FA] uppercase tracking-wider">
              Live Advisor Dialogue
            </span>
          </div>
          <span className="text-[11px] font-mono text-[#939BB0]">
            Ground-Truth Context: {todayDate}
          </span>
        </div>

        {/* Messages Stream */}
        <div className="flex-1 p-5 overflow-y-auto space-y-4">
          {messages.map((msg) => {
            const isUser = msg.role === 'user';
            return (
              <div
                key={msg.id}
                className={`flex items-start gap-3 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}
              >
                <div
                  className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 text-xs font-bold ${
                    isUser
                      ? 'bg-[#181D2B] border border-[#252B3B] text-[#F4F5FA]'
                      : 'bg-gradient-to-br from-[#A78BFA] to-[#67E8F9] text-black shadow-md shadow-violet-500/20'
                  }`}
                >
                  {isUser ? <User size={15} /> : <Bot size={16} />}
                </div>

                <div
                  className={`max-w-[80%] rounded-2xl p-4 text-xs leading-relaxed space-y-1.5 ${
                    isUser
                      ? 'bg-[#181D2B] border border-[#A78BFA]/30 text-[#F4F5FA]'
                      : 'bg-[#121622] border border-[#252B3B] text-[#F4F5FA] shadow-md'
                  }`}
                >
                  <div className="whitespace-pre-line">{msg.text}</div>
                  <div className="flex items-center justify-between pt-1 text-[10px] font-mono text-[#939BB0]">
                    <span>{msg.timestamp}</span>
                    {msg.model && (
                      <span className="text-[#A78BFA] font-medium">{msg.model}</span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}

          {isSending && (
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#A78BFA] to-[#67E8F9] text-black flex items-center justify-center">
                <Bot size={16} />
              </div>
              <div className="p-3.5 rounded-2xl bg-[#121622] border border-[#252B3B] text-xs text-[#939BB0] flex items-center gap-2">
                <Sparkles size={13} className="text-[#67E8F9] animate-spin" />
                <span>Consulting Gemini Flash with stored IRL.OS records...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Suggested Query Chips */}
        <div className="px-4 py-2 border-t border-[#252B3B]/60 bg-[#090A0F] flex items-center gap-2 overflow-x-auto text-[11px]">
          <span className="text-[#939BB0] font-mono shrink-0">Ask:</span>
          {suggestedPrompts.map((p, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(p)}
              className="px-2.5 py-1 rounded-lg bg-[#121622] hover:bg-[#181D2B] text-[#939BB0] hover:text-[#F4F5FA] border border-[#252B3B] transition-colors whitespace-nowrap"
            >
              {p}
            </button>
          ))}
        </div>

        {/* Message Input Box */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage(inputMessage);
          }}
          className="p-3.5 border-t border-[#252B3B] bg-[#121622] flex items-center gap-2"
        >
          <input
            type="text"
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            placeholder="Talk to the AI Perspective advisor..."
            className="flex-1 px-4 py-2.5 rounded-xl bg-[#090A0F] border border-[#252B3B] text-xs text-[#F4F5FA] focus:border-[#A78BFA] outline-none transition-colors"
          />
          <button
            type="submit"
            disabled={!inputMessage.trim() || isSending}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#A78BFA] to-[#8B5CF6] text-black font-semibold text-xs flex items-center gap-1.5 shadow-md shadow-violet-500/20 hover:opacity-95 disabled:opacity-40 transition-all"
          >
            <Send size={14} />
            <span>Send</span>
          </button>
        </form>
      </div>
    </div>
  );
};
