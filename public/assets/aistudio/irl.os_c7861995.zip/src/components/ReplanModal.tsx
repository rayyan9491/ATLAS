import React, { useState } from 'react';
import { X, Zap, Sparkles, CheckCircle, ArrowRight, AlertCircle, Clock, Calendar } from 'lucide-react';
import { Goal, Task } from '../types/index.ts';
import { generateDeterministicReplan, ReplanProposal } from '../utils/scheduler.ts';

interface ReplanModalProps {
  isOpen: boolean;
  onClose: () => void;
  tasks: Task[];
  goals: Goal[];
  currentDate: string;
  availableMinutes: number;
  hasAiConfigured: boolean;
  onApplyReplan: (keptIds: string[], deferred: { taskId: string; newDate: string }[]) => void;
}

export const ReplanModal: React.FC<ReplanModalProps> = ({
  isOpen,
  onClose,
  tasks,
  goals,
  currentDate,
  availableMinutes,
  hasAiConfigured,
  onApplyReplan,
}) => {
  const [targetMinutes, setTargetMinutes] = useState(availableMinutes);
  const [userPrompt, setUserPrompt] = useState('');
  const [isLoadingAi, setIsLoadingAi] = useState(false);
  const [replanProposal, setReplanProposal] = useState<ReplanProposal>(() =>
    generateDeterministicReplan(tasks, currentDate, availableMinutes)
  );

  if (!isOpen) return null;

  const handleRunDeterministic = (mins: number) => {
    setTargetMinutes(mins);
    const proposal = generateDeterministicReplan(tasks, currentDate, mins);
    setReplanProposal(proposal);
  };

  const handleRunAiReplan = async () => {
    if (!hasAiConfigured) {
      handleRunDeterministic(targetMinutes);
      return;
    }

    setIsLoadingAi(true);
    try {
      const res = await fetch('/api/ai/replan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          targetDate: currentDate,
          availableMinutes: targetMinutes,
          prompt: userPrompt || 'Optimize day capacity',
          tasks: tasks.filter((t) => t.scheduledDate === currentDate),
          goals,
        }),
      });

      const data = await res.json();
      if (data.configured && data.proposal) {
        const keptIds = new Set(data.proposal.keptTaskIds || []);
        const dayTasks = tasks.filter((t) => t.scheduledDate === currentDate);
        const kept = dayTasks.filter((t) => keptIds.has(t.id));
        const deferred = (data.proposal.deferredItems || []).map((item: any) => {
          const t = dayTasks.find((task) => task.id === item.taskId);
          return {
            task: t || dayTasks[0],
            newDate: item.newDate || currentDate,
            reason: item.reason || 'AI recommendation to defer',
          };
        });

        setReplanProposal({
          targetDate: currentDate,
          availableMinutes: targetMinutes,
          initialTotalMinutes: dayTasks.reduce((acc, t) => acc + (t.estimatedMinutes || 0), 0),
          keptTasks: kept,
          deferredTasks: deferred,
          rationale: data.proposal.rationale,
        });
      } else {
        handleRunDeterministic(targetMinutes);
      }
    } catch (e) {
      console.warn('AI replan failed, falling back', e);
      handleRunDeterministic(targetMinutes);
    } finally {
      setIsLoadingAi(false);
    }
  };

  const handleConfirm = () => {
    const keptIds = replanProposal.keptTasks.map((t) => t.id);
    const deferred = replanProposal.deferredTasks.map((d) => ({
      taskId: d.task.id,
      newDate: d.newDate,
    }));
    onApplyReplan(keptIds, deferred);
    onClose();
  };

  const totalKeptDuration = replanProposal.keptTasks.reduce(
    (acc, t) => acc + (t.estimatedMinutes || 0),
    0
  );

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-2xl bg-[#121622] border border-[#252B3B] rounded-2xl shadow-2xl overflow-hidden animate-in fade-in duration-200">
        <div className="px-6 py-4 border-b border-[#252B3B] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap size={18} className="text-[#67E8F9]" />
            <h2 className="text-base font-bold text-[#F4F5FA]">
              Adaptive Workload Re-Planner
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-[#939BB0] hover:text-[#F4F5FA] hover:bg-[#181D2B] transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        <div className="p-6 space-y-5 max-h-[85vh] overflow-y-auto">
          {/* Target time controls */}
          <div className="p-4 rounded-xl bg-[#090A0F] border border-[#252B3B]">
            <div className="flex justify-between items-center text-xs mb-2">
              <span className="font-mono uppercase text-[#939BB0] flex items-center gap-1.5 font-semibold">
                <Clock size={13} className="text-[#A78BFA]" />
                <span>Adjust Target Available Time for Today</span>
              </span>
              <span className="font-mono font-bold text-[#67E8F9] text-sm">
                {targetMinutes} minutes
              </span>
            </div>
            <div className="flex items-center gap-3">
              <input
                type="range"
                min="20"
                max="300"
                step="10"
                value={targetMinutes}
                onChange={(e) => handleRunDeterministic(Number(e.target.value))}
                className="w-full accent-[#A78BFA] bg-[#121622] cursor-pointer"
              />
            </div>
            <div className="flex items-center justify-between mt-3 gap-2">
              <div className="flex gap-1.5">
                {[30, 60, 90, 120, 180, 240].map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => handleRunDeterministic(m)}
                    className={`px-2 py-1 rounded-md text-[11px] font-mono transition-colors ${
                      targetMinutes === m
                        ? 'bg-[#A78BFA] text-black font-bold'
                        : 'bg-[#181D2B] text-[#939BB0] hover:text-[#F4F5FA]'
                    }`}
                  >
                    {m}m
                  </button>
                ))}
              </div>

              {hasAiConfigured && (
                <button
                  type="button"
                  onClick={handleRunAiReplan}
                  disabled={isLoadingAi}
                  className="px-3 py-1 rounded-lg bg-gradient-to-r from-[#A78BFA]/20 to-[#67E8F9]/20 hover:from-[#A78BFA]/30 hover:to-[#67E8F9]/30 text-[#67E8F9] border border-[#67E8F9]/40 text-xs font-semibold flex items-center gap-1.5 transition-all"
                >
                  <Sparkles size={13} />
                  <span>{isLoadingAi ? 'Consulting Gemini...' : 'AI Proposal'}</span>
                </button>
              )}
            </div>
          </div>

          {/* Rationale explanation */}
          <div className="p-3.5 rounded-xl bg-[#181D2B] border border-[#A78BFA]/30 text-xs">
            <span className="font-mono text-[#A78BFA] font-bold block mb-1">
              PROPOSED RE-PLAN RATIONALE:
            </span>
            <p className="text-[#F4F5FA] leading-relaxed">{replanProposal.rationale}</p>
          </div>

          {/* Side by Side Plan Breakdown */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Kept Tasks */}
            <div className="p-4 rounded-xl bg-[#090A0F] border border-[#252B3B]">
              <div className="flex items-center justify-between mb-3 pb-2 border-b border-[#252B3B]">
                <div className="flex items-center gap-1.5">
                  <CheckCircle size={14} className="text-[#4ADE80]" />
                  <span className="text-xs font-bold text-[#F4F5FA]">
                    Keep for Today ({replanProposal.keptTasks.length})
                  </span>
                </div>
                <span className="text-[11px] font-mono text-[#67E8F9] font-semibold">
                  {totalKeptDuration}m / {targetMinutes}m
                </span>
              </div>

              {replanProposal.keptTasks.length === 0 ? (
                <p className="text-xs text-[#939BB0] italic py-2">No tasks fit in this window.</p>
              ) : (
                <div className="space-y-2">
                  {replanProposal.keptTasks.map((t) => (
                    <div
                      key={t.id}
                      className="p-2.5 rounded-lg bg-[#121622] border border-[#252B3B] text-xs flex items-center justify-between"
                    >
                      <div className="min-w-0 pr-2">
                        <div className="font-medium text-[#F4F5FA] truncate">{t.title}</div>
                        <span className="text-[10px] font-mono text-[#A78BFA] uppercase">
                          {t.priority}
                        </span>
                      </div>
                      <span className="font-mono text-[#939BB0] text-[11px] shrink-0">
                        {t.estimatedMinutes}m
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Deferred Tasks */}
            <div className="p-4 rounded-xl bg-[#090A0F] border border-[#252B3B]">
              <div className="flex items-center justify-between mb-3 pb-2 border-b border-[#252B3B]">
                <div className="flex items-center gap-1.5">
                  <ArrowRight size={14} className="text-[#FB7185]" />
                  <span className="text-xs font-bold text-[#F4F5FA]">
                    Postpone to Preserve Focus ({replanProposal.deferredTasks.length})
                  </span>
                </div>
                <span className="text-[11px] font-mono text-[#939BB0]">Safe defer</span>
              </div>

              {replanProposal.deferredTasks.length === 0 ? (
                <p className="text-xs text-[#4ADE80] py-2">Zero tasks need to be postponed.</p>
              ) : (
                <div className="space-y-2">
                  {replanProposal.deferredTasks.map((d) => (
                    <div
                      key={d.task.id}
                      className="p-2.5 rounded-lg bg-[#121622] border border-[#252B3B] text-xs space-y-1"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-[#F4F5FA] truncate">{d.task.title}</span>
                        <span className="text-[10px] font-mono text-[#FB7185] px-1 rounded bg-[#FB7185]/10">
                          {d.task.estimatedMinutes}m
                        </span>
                      </div>
                      <div className="flex items-center gap-1 text-[10px] text-[#67E8F9] font-mono">
                        <Calendar size={10} />
                        <span>Reschedule: {d.newDate}</span>
                      </div>
                      <p className="text-[10px] text-[#939BB0] leading-tight">{d.reason}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="p-3 rounded-lg bg-[#181D2B]/50 border border-[#252B3B] text-[11px] text-[#939BB0] flex items-center gap-2">
            <AlertCircle size={14} className="text-[#A78BFA] shrink-0" />
            <span>
              Work is never deleted. Deferred items are safely moved to the next day with existing deadlines intact.
            </span>
          </div>

          {/* Action buttons */}
          <div className="pt-3 border-t border-[#252B3B] flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-medium text-[#939BB0] hover:text-[#F4F5FA] hover:bg-[#181D2B] transition-colors"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleConfirm}
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#67E8F9] to-[#38BDF8] text-black font-semibold text-xs shadow-md shadow-cyan-500/20 hover:opacity-95 transition-all"
            >
              Apply Adjusted Plan
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
