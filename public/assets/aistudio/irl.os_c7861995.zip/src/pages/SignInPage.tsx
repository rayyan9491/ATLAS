import React, { useState } from 'react';
import {
  Eye,
  EyeOff,
  ArrowRight,
  ShieldCheck,
  AlertCircle,
  CheckCircle2,
  Lock,
  Mail,
  KeyRound,
  RotateCcw,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext.tsx';
import { LiveWaveCanvas } from '../components/LiveWaveCanvas.tsx';

interface SignInPageProps {
  onNavigate: (path: string) => void;
  redirectPath?: string;
}

export const SignInPage: React.FC<SignInPageProps> = ({
  onNavigate,
  redirectPath = '/app/today',
}) => {
  const { signIn, sendPasswordReset, authError, clearAuthError } = useAuth();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [validationError, setValidationError] = useState<string | null>(null);

  // Forgot password flow state
  const [isResetMode, setIsResetMode] = useState(false);
  const [resetEmail, setResetEmail] = useState('');
  const [resetLoading, setResetLoading] = useState(false);
  const [resetSuccess, setResetSuccess] = useState(false);
  const [resetError, setResetError] = useState<string | null>(null);

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    clearAuthError();
    setValidationError(null);

    const cleanEmail = email.trim();
    if (!cleanEmail) {
      setValidationError('Please enter your email address.');
      return;
    }
    if (!password) {
      setValidationError('Please enter your password.');
      return;
    }

    setLoading(true);
    try {
      await signIn(cleanEmail, password);
      // Successful sign in -> navigate to requested path
      onNavigate(redirectPath);
    } catch (err: any) {
      // Error handled by AuthContext
    } finally {
      setLoading(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setResetError(null);
    setResetSuccess(false);

    const cleanEmail = resetEmail.trim() || email.trim();
    if (!cleanEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      setResetError('Please enter a valid email address.');
      return;
    }

    setResetLoading(true);
    try {
      await sendPasswordReset(cleanEmail);
      setResetSuccess(true);
    } catch (err: any) {
      setResetError(err.message || 'Unable to process reset request. Please check your email.');
    } finally {
      setResetLoading(false);
    }
  };

  return (
    <div className="relative min-h-screen bg-[#07080C] text-[#F4F5FA] flex flex-col justify-center items-center px-4 py-12 overflow-hidden selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Background Live Wave Canvas */}
      <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden">
        <LiveWaveCanvas className="w-full h-full opacity-60" intensity={1.1} showParticles={true} />
      </div>

      {/* Ambient gradient glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[360px] bg-gradient-to-tr from-cyan-500/15 via-violet-600/15 to-transparent blur-3xl pointer-events-none rounded-full" />

      {/* Main Container */}
      <div className="relative z-10 w-full max-w-md">
        {/* Header Branding */}
        <div className="text-center mb-8">
          <button
            onClick={() => onNavigate('/')}
            className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/[0.04] border border-white/10 hover:border-cyan-500/40 transition-all text-xs text-white/70 hover:text-white mb-4"
          >
            <div className="w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_8px_#06B6D4]" />
            <span className="font-mono tracking-wider">IRL.OS</span>
            <span className="text-white/40">/</span>
            <span className="text-cyan-400 font-medium">Authentication</span>
          </button>
          <h1 className="text-3xl font-extrabold tracking-tight text-white mb-2">
            {isResetMode ? 'Reset System Password' : 'Sign In to IRL.OS'}
          </h1>
          <p className="text-sm text-white/60">
            {isResetMode
              ? 'Enter your account email to receive a secure recovery link.'
              : 'Restore your private roadmap, live capacity data, and active goals.'}
          </p>
        </div>

        {/* Card Form */}
        <div className="relative rounded-2xl bg-[#0D0F18]/90 border border-white/10 backdrop-blur-xl p-7 shadow-2xl shadow-black/80">
          {/* Subtle top edge highlight */}
          <div className="absolute top-0 inset-x-8 h-[1px] bg-gradient-to-r from-transparent via-cyan-400/50 to-transparent" />

          {!isResetMode ? (
            /* Normal Sign In Form */
            <>
              {/* Validation or Auth Error */}
              {(validationError || authError) && (
                <div className="mb-5 p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-start gap-2.5 animate-fadeIn">
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  <div className="leading-relaxed">
                    {validationError || authError}
                  </div>
                </div>
              )}

              <form onSubmit={handleSignIn} className="space-y-4">
                {/* Email Address */}
                <div>
                  <label className="block text-xs font-medium text-white/75 mb-1.5">
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="you@domain.com"
                      className="w-full pl-10 pr-4 py-2.5 bg-black/40 border border-white/10 rounded-xl text-sm text-white placeholder-white/30 focus:outline-none focus:border-cyan-400/80 focus:ring-1 focus:ring-cyan-400/40 transition-colors"
                    />
                  </div>
                </div>

                {/* Password */}
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-medium text-white/75">Password</label>
                    <button
                      type="button"
                      onClick={() => {
                        setResetEmail(email);
                        setIsResetMode(true);
                        clearAuthError();
                      }}
                      className="text-[11px] text-cyan-400 hover:text-cyan-300 font-medium hover:underline"
                    >
                      Forgot Password?
                    </button>
                  </div>
                  <div className="relative">
                    <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Enter account password"
                      className="w-full pl-10 pr-10 py-2.5 bg-black/40 border border-white/10 rounded-xl text-sm text-white placeholder-white/30 focus:outline-none focus:border-cyan-400/80 focus:ring-1 focus:ring-cyan-400/40 transition-colors font-mono"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-white/40 hover:text-white/80 p-1"
                      tabIndex={-1}
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Submit Button */}
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full mt-2 py-3 px-4 rounded-xl font-medium text-sm text-black bg-gradient-to-r from-cyan-400 via-teal-300 to-cyan-300 hover:from-cyan-300 hover:to-teal-200 transition-all shadow-[0_0_20px_rgba(6,182,212,0.35)] hover:shadow-[0_0_25px_rgba(6,182,212,0.5)] flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {loading ? (
                    <>
                      <div className="w-4 h-4 border-2 border-black/80 border-t-transparent rounded-full animate-spin" />
                      <span>Verifying Session...</span>
                    </>
                  ) : (
                    <>
                      <span>Sign In</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>
            </>
          ) : (
            /* Reset Password Form */
            <div className="space-y-4">
              {resetError && (
                <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-start gap-2.5">
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  <div className="leading-relaxed">{resetError}</div>
                </div>
              )}

              {resetSuccess ? (
                <div className="space-y-4 text-center py-3">
                  <div className="w-12 h-12 mx-auto rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-base font-semibold text-white">Reset Link Dispatched</h3>
                    <p className="mt-1 text-xs text-white/60 leading-relaxed">
                      If an account exists for <span className="text-cyan-400 font-mono">{resetEmail || email}</span>, a secure password reset link has been sent. Please check your inbox and spam folders.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setIsResetMode(false);
                      setResetSuccess(false);
                    }}
                    className="w-full py-2.5 px-4 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-medium transition-colors"
                  >
                    Return to Sign In
                  </button>
                </div>
              ) : (
                <form onSubmit={handleResetPassword} className="space-y-4">
                  <div>
                    <label className="block text-xs font-medium text-white/75 mb-1.5">
                      Account Email Address
                    </label>
                    <div className="relative">
                      <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
                      <input
                        type="email"
                        required
                        value={resetEmail}
                        onChange={(e) => setResetEmail(e.target.value)}
                        placeholder="you@domain.com"
                        className="w-full pl-10 pr-4 py-2.5 bg-black/40 border border-white/10 rounded-xl text-sm text-white placeholder-white/30 focus:outline-none focus:border-cyan-400/80 focus:ring-1 focus:ring-cyan-400/40 transition-colors"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={resetLoading}
                    className="w-full py-2.5 px-4 rounded-xl font-medium text-sm text-black bg-cyan-400 hover:bg-cyan-300 transition-all shadow-[0_0_15px_rgba(6,182,212,0.3)] flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                  >
                    {resetLoading ? (
                      <>
                        <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                        <span>Sending Request...</span>
                      </>
                    ) : (
                      <>
                        <KeyRound className="w-4 h-4" />
                        <span>Send Password Reset Email</span>
                      </>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setIsResetMode(false);
                      setResetError(null);
                    }}
                    className="w-full py-2 text-xs text-white/50 hover:text-white flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    Back to Sign In
                  </button>
                </form>
              )}
            </div>
          )}

          {/* Privacy & Security note */}
          <div className="mt-5 pt-4 border-t border-white/5 flex items-center justify-between text-[11px] text-white/40">
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
              Isolated Personal Database
            </span>
            <span className="font-mono text-[10px] text-white/30">
              IRL.OS v2.4
            </span>
          </div>
        </div>

        {/* Create account link */}
        <div className="mt-6 text-center text-xs text-white/50">
          Don't have an IRL.OS account?{' '}
          <button
            onClick={() => onNavigate('/signup')}
            className="text-cyan-400 hover:text-cyan-300 font-medium underline underline-offset-4"
          >
            Create an Account
          </button>
        </div>
      </div>
    </div>
  );
};
