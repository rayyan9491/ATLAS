export type GoalCategory = 'career' | 'learning' | 'fitness' | 'creative' | 'finance' | 'lifestyle';

export type Priority = 'critical' | 'high' | 'medium' | 'low';

export type TaskStatus = 'todo' | 'in_progress' | 'completed' | 'deferred';

export type DaySlot = 'focus_now' | 'up_next' | 'later' | 'completed';

export interface Task {
  id: string;
  title: string;
  description?: string;
  goalId?: string;
  milestoneId?: string;
  scheduledDate: string; // YYYY-MM-DD
  slot: DaySlot;
  estimatedMinutes: number;
  actualMinutes?: number;
  priority: Priority;
  status: TaskStatus;
  deadline?: string;
  xpReward: number;
  completedAt?: string;
  createdAt: string;
}

export interface Milestone {
  id: string;
  goalId: string;
  title: string;
  description?: string;
  order: number;
  status: 'locked' | 'in_progress' | 'completed';
  completedAt?: string;
  criteria?: string;
}

export interface Goal {
  id: string;
  title: string;
  description: string;
  category: GoalCategory;
  priority: Priority;
  deadline?: string;
  status: 'active' | 'paused' | 'completed' | 'archived';
  milestones: Milestone[];
  createdAt: string;
  completedAt?: string;
}

export interface UserStats {
  displayName: string;
  avatarSeed: string;
  level: number;
  xp: number;
  title: string;
  gamificationEnabled: boolean;
  defaultAvailabilityMinutes: number;
  dailyAvailability: Record<string, number>; // date YYYY-MM-DD -> minutes
  autoReplanWithAi: boolean;
}

export interface XpLedgerEntry {
  id: string;
  taskId?: string;
  milestoneId?: string;
  xpAwarded: number;
  timestamp: string;
  reason: string;
}

export interface RealityCheckResult {
  availableMinutes: number;
  plannedMinutes: number;
  completedMinutes: number;
  remainingMinutes: number;
  diffMinutes: number; // positive = under capacity (free time), negative = over capacity
  percentUtilized: number;
  status: 'under_capacity' | 'balanced' | 'over_capacity';
  overMinutes: number;
}

export interface NextMoveRecommendation {
  taskId: string;
  task: Task;
  reason: string;
  alternativeTask?: Task;
  confidence: 'High' | 'Direct Match' | 'Recommended';
}

export interface WeeklyReportData {
  plannedCount: number;
  completedCount: number;
  completionRate: number;
  totalPlannedMinutes: number;
  totalCompletedMinutes: number;
  postponedCount: number;
  topGoals: { id: string; title: string; completedTasks: number; totalTasks: number }[];
  milestonesReached: { id: string; title: string; goalTitle: string }[];
  observations: string[];
  recommendations: string[];
}
