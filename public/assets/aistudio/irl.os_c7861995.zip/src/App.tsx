import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { AppProvider, useApp } from './context/AppContext.tsx';
import { Sidebar } from './components/Sidebar.tsx';
import { Header } from './components/Header.tsx';
import { LandingPage } from './pages/LandingPage.tsx';
import { SignUpPage } from './pages/SignUpPage.tsx';
import { SignInPage } from './pages/SignInPage.tsx';
import { OnboardingPage } from './pages/OnboardingPage.tsx';
import { TodayDashboard } from './pages/TodayDashboard.tsx';
import { MasterDeckPage } from './pages/MasterDeckPage.tsx';
import { GoalsPage } from './pages/GoalsPage.tsx';
import { GoalDetailPage } from './pages/GoalDetailPage.tsx';
import { PlannerPage } from './pages/PlannerPage.tsx';
import { FocusRoomPage } from './pages/FocusRoomPage.tsx';
import { InsightsPage } from './pages/InsightsPage.tsx';
import { CoachPage } from './pages/CoachPage.tsx';
import { ProfilePage } from './pages/ProfilePage.tsx';
import { SettingsPage } from './pages/SettingsPage.tsx';
import { TaskModal } from './components/TaskModal.tsx';
import { GoalModal } from './components/GoalModal.tsx';
import { ReplanModal } from './components/ReplanModal.tsx';
import { ReferenceBoardModal } from './components/ReferenceBoardModal.tsx';
import { LiveWaveCanvas } from './components/LiveWaveCanvas.tsx';
import { Task, Goal } from './types/index.ts';

function AppContent() {
  const { user, userProfile, loading: authLoading } = useAuth();
  const {
    tasks,
    goals,
    createTask,
    updateTask,
    createGoal,
    applyReplan,
    todayDate,
    hasAiConfigured,
    userStats,
  } = useApp();

  // Route state
  const [currentPath, setCurrentPath] = useState<string>(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('autostart') === '1') {
      return '/app/today';
    }
    const path = window.location.pathname;
    return path && path !== '' ? path : '/';
  });

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Modals state
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [taskToEdit, setTaskToEdit] = useState<Task | null>(null);
  const [isGoalModalOpen, setIsGoalModalOpen] = useState(false);
  const [isReplanModalOpen, setIsReplanModalOpen] = useState(false);

  // Browser navigation sync
  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(window.location.pathname || '/');
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigate = (path: string) => {
    if (path !== currentPath) {
      window.history.pushState({}, '', path);
      setCurrentPath(path);
      setIsMobileMenuOpen(false);
      window.scrollTo(0, 0);
    }
  };

  const handleOpenTaskModal = (task?: Task | null) => {
    setTaskToEdit(task || null);
    setIsTaskModalOpen(true);
  };

  const handleSaveTask = (taskData: any) => {
    if (taskData.id) {
      updateTask(taskData.id, taskData);
    } else {
      createTask(taskData);
    }
  };

  const handleSaveGoal = (goalData: any, initialMilestones: string[]) => {
    createGoal(goalData, initialMilestones);
  };

  // Route matching based on path without query parameters
  const pathName = currentPath.split('?')[0];
  const isLanding = pathName === '/';
  const isSignUp = pathName === '/signup';
  const isSignIn = pathName === '/signin';
  const isOnboarding = pathName === '/onboarding';
  const isAppRoute = pathName.startsWith('/app/');
  const isGoalDetail = pathName.startsWith('/app/goals/') && pathName !== '/app/goals';
  const goalDetailId = isGoalDetail ? pathName.replace('/app/goals/', '') : null;

  // Handle protected route redirection
  useEffect(() => {
    if (authLoading) return;

    if (!user && (isAppRoute || isOnboarding)) {
      // Unauthenticated visitor trying to access protected route -> send to /signin preserving destination
      const redirectParam = encodeURIComponent(currentPath);
      navigate(`/signin?redirect=${redirectParam}`);
    } else if (user && (isSignUp || isSignIn)) {
      // Authenticated user on signin/signup -> send to /app/today or onboarding
      if (userProfile && userProfile.onboardingCompleted === false) {
        navigate('/onboarding');
      } else {
        const params = new URLSearchParams(window.location.search);
        const redirect = params.get('redirect');
        navigate(redirect ? decodeURIComponent(redirect) : '/app/today');
      }
    } else if (user && isAppRoute && userProfile && userProfile.onboardingCompleted === false) {
      // First-time registered user hasn't completed onboarding -> direct to onboarding
      navigate('/onboarding');
    }
  }, [user, userProfile, authLoading, currentPath]);

  // Loading state while auth is establishing
  if (authLoading) {
    return (
      <div className="relative min-h-screen bg-[#07080C] text-[#F4F5FA] flex flex-col items-center justify-center overflow-hidden">
        <LiveWaveCanvas className="opacity-60" intensity={0.9} showParticles={true} />
        <div className="relative z-10 flex flex-col items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-400 via-violet-500 to-cyan-300 flex items-center justify-center shadow-lg shadow-cyan-500/30 animate-pulse">
            <span className="font-mono text-black font-extrabold text-base">IRL</span>
          </div>
          <div className="flex items-center gap-2 text-xs font-mono text-cyan-400">
            <div className="w-3.5 h-3.5 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
            <span>Establishing Private Session...</span>
          </div>
        </div>
      </div>
    );
  }

  // Public Landing Page
  if (isLanding) {
    return (
      <div className="bg-[#07080C] min-h-screen text-[#F4F5FA]">
        <LandingPage
          onEnterApp={() => navigate(user ? '/app/today' : '/signin')}
          onOpenDeck={() => navigate(user ? '/app/deck' : '/signup')}
          onNavigate={navigate}
        />
        <ReferenceBoardModal />
      </div>
    );
  }

  // Sign Up Page
  if (isSignUp) {
    return <SignUpPage onNavigate={navigate} />;
  }

  // Sign In Page
  if (isSignIn) {
    const params = new URLSearchParams(window.location.search);
    const redirect = params.get('redirect');
    return (
      <SignInPage
        onNavigate={navigate}
        redirectPath={redirect ? decodeURIComponent(redirect) : '/app/today'}
      />
    );
  }

  // Onboarding Page
  if (isOnboarding) {
    return <OnboardingPage onNavigate={navigate} />;
  }

  // Protected route guard: if unauthenticated, directly render SignInPage without exposing private views
  if (!user && (isAppRoute || isOnboarding)) {
    return (
      <SignInPage
        onNavigate={navigate}
        redirectPath={currentPath}
      />
    );
  }

  // Onboarding enforcement: if authenticated user hasn't completed onboarding, render OnboardingPage
  if (user && isAppRoute && userProfile && userProfile.onboardingCompleted === false) {
    return <OnboardingPage onNavigate={navigate} />;
  }

  const getPageTitle = () => {
    if (pathName === '/app/deck') return 'Master 1-Page Deck';
    if (pathName === '/app/today') return 'Today Command Center';
    if (pathName === '/app/goals') return 'Goals & Roadmaps';
    if (isGoalDetail) return 'Goal Roadmap Detail';
    if (pathName === '/app/plan') return 'Capacity Planner';
    if (pathName === '/app/focus') return 'Deep Focus Room';
    if (pathName === '/app/insights') return 'Reality Analytics Report';
    if (pathName === '/app/coach') return 'AI Perspective Advisor';
    if (pathName === '/app/profile') return 'Player Profile & Progression';
    if (pathName === '/app/settings') return 'System Settings';
    return 'IRL.OS';
  };

  const availableMinutesToday =
    userStats.dailyAvailability[todayDate] !== undefined
      ? userStats.dailyAvailability[todayDate]
      : userStats.defaultAvailabilityMinutes;

  return (
    <div className="flex h-screen bg-[#07080C] text-[#F4F5FA] overflow-hidden">
      {/* Desktop Sidebar */}
      <div className="hidden md:block">
        <Sidebar currentPath={pathName} onNavigate={navigate} />
      </div>

      {/* Mobile Drawer */}
      {isMobileMenuOpen && (
        <div
          className="md:hidden fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex"
          onClick={() => setIsMobileMenuOpen(false)}
        >
          <div className="w-72" onClick={(e) => e.stopPropagation()}>
            <Sidebar currentPath={pathName} onNavigate={navigate} />
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col h-screen min-w-0 overflow-hidden">
        <Header
          title={getPageTitle()}
          subtitle="Your life. Your system. Your next move."
          onOpenAddTask={() => handleOpenTaskModal(null)}
          onOpenAddGoal={pathName.startsWith('/app/goals') ? () => setIsGoalModalOpen(true) : undefined}
          onToggleMobileMenu={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          isMobileMenuOpen={isMobileMenuOpen}
        />

        <main className="flex-1 overflow-y-auto">
          {pathName === '/app/deck' && (
            <MasterDeckPage
              onNavigate={navigate}
              onOpenTaskModal={() => handleOpenTaskModal(null)}
              onOpenGoalModal={() => setIsGoalModalOpen(true)}
            />
          )}

          {pathName === '/app/today' && (
            <TodayDashboard
              onNavigate={navigate}
              onOpenTaskModal={handleOpenTaskModal}
              onOpenReplanModal={() => setIsReplanModalOpen(true)}
            />
          )}

          {pathName === '/app/goals' && (
            <GoalsPage
              onNavigate={navigate}
              onOpenGoalModal={() => setIsGoalModalOpen(true)}
            />
          )}

          {isGoalDetail && goalDetailId && (
            <GoalDetailPage
              goalId={goalDetailId}
              onNavigate={navigate}
              onOpenTaskModal={handleOpenTaskModal}
            />
          )}

          {pathName === '/app/plan' && (
            <PlannerPage
              onNavigate={navigate}
              onOpenTaskModal={handleOpenTaskModal}
              onOpenReplanModal={() => setIsReplanModalOpen(true)}
            />
          )}

          {pathName === '/app/focus' && (
            <FocusRoomPage onNavigate={navigate} />
          )}

          {pathName === '/app/insights' && (
            <InsightsPage onNavigate={navigate} />
          )}

          {pathName === '/app/coach' && (
            <CoachPage
              onNavigate={navigate}
              onOpenReplanModal={() => setIsReplanModalOpen(true)}
            />
          )}

          {pathName === '/app/profile' && (
            <ProfilePage onNavigate={navigate} />
          )}

          {pathName === '/app/settings' && (
            <SettingsPage onNavigate={navigate} />
          )}
        </main>
      </div>

      {/* Modals */}
      <TaskModal
        isOpen={isTaskModalOpen}
        onClose={() => setIsTaskModalOpen(false)}
        onSave={handleSaveTask}
        taskToEdit={taskToEdit}
        goals={goals}
        initialDate={todayDate}
      />

      <GoalModal
        isOpen={isGoalModalOpen}
        onClose={() => setIsGoalModalOpen(false)}
        onSave={handleSaveGoal}
      />

      <ReplanModal
        isOpen={isReplanModalOpen}
        onClose={() => setIsReplanModalOpen(false)}
        tasks={tasks}
        goals={goals}
        currentDate={todayDate}
        availableMinutes={availableMinutesToday}
        hasAiConfigured={hasAiConfigured}
        onApplyReplan={applyReplan}
      />

      <ReferenceBoardModal />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppProvider>
        <AppContent />
      </AppProvider>
    </AuthProvider>
  );
}
