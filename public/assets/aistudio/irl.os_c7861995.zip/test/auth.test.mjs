import test from 'node:test';
import assert from 'node:assert/strict';

function validateRegistration(displayName, email, password, confirmPassword) {
  if (!displayName || !displayName.trim()) {
    return { valid: false, error: 'Please enter your display name.' };
  }
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
    return { valid: false, error: 'Please provide a valid email address.' };
  }
  if (!password || password.length < 6) {
    return { valid: false, error: 'Password must be at least 6 characters long.' };
  }
  if (password !== confirmPassword) {
    return { valid: false, error: 'Passwords do not match. Please verify and re-type.' };
  }
  return { valid: true };
}

function formatAuthError(error) {
  if (!error) return 'An unexpected error occurred. Please try again.';
  const code = error.code || '';
  switch (code) {
    case 'auth/invalid-email':
      return 'Please provide a valid email address.';
    case 'auth/user-disabled':
      return 'This IRL.OS account has been disabled.';
    case 'auth/user-not-found':
    case 'auth/wrong-password':
    case 'auth/invalid-credential':
      return 'Incorrect email or password. Please verify your credentials.';
    case 'auth/email-already-in-use':
      return 'An IRL.OS account already exists with this email address. Please sign in instead.';
    case 'auth/weak-password':
      return 'Password must be at least 6 characters long.';
    case 'auth/too-many-requests':
      return 'Access temporarily blocked due to too many failed attempts. Please try again in a few minutes.';
    default:
      return error.message || 'Authentication error. Please try again.';
  }
}

test('validateRegistration accepts valid user inputs', () => {
  const result = validateRegistration('Sarah Connor', 'sarah@resistance.org', 'skynet123', 'skynet123');
  assert.equal(result.valid, true);
});

test('validateRegistration rejects empty display name', () => {
  const result = validateRegistration('   ', 'sarah@resistance.org', 'skynet123', 'skynet123');
  assert.equal(result.valid, false);
  assert.match(result.error, /display name/i);
});

test('validateRegistration rejects invalid email format', () => {
  const result = validateRegistration('Sarah', 'not-an-email', 'skynet123', 'skynet123');
  assert.equal(result.valid, false);
  assert.match(result.error, /valid email/i);
});

test('validateRegistration rejects passwords under 6 chars', () => {
  const result = validateRegistration('Sarah', 'sarah@resistance.org', '123', '123');
  assert.equal(result.valid, false);
  assert.match(result.error, /at least 6 characters/i);
});

test('validateRegistration rejects mismatched passwords', () => {
  const result = validateRegistration('Sarah', 'sarah@resistance.org', 'password123', 'password456');
  assert.equal(result.valid, false);
  assert.match(result.error, /do not match/i);
});

test('formatAuthError humanizes Firebase error codes cleanly', () => {
  assert.match(formatAuthError({ code: 'auth/email-already-in-use' }), /already exists/i);
  assert.match(formatAuthError({ code: 'auth/invalid-credential' }), /Incorrect email or password/i);
  assert.match(formatAuthError({ code: 'auth/weak-password' }), /at least 6 characters/i);
  assert.match(formatAuthError({ code: 'auth/too-many-requests' }), /temporarily blocked/i);
});
