import React, { useState } from 'react';
import {
  ArrowRight,
  Sparkles,
  Zap,
  Target,
  Clock,
  ShieldCheck,
  CheckCircle2,
  Layers,
  BarChart2,
  LayoutGrid,
  ChevronRight,
  Play,
  RotateCcw,
  Sliders,
  Maximize2,
  Send,
  Flame,
  Activity,
  Terminal,
} from 'lucide-react';
import { LiveWaveCanvas } from '../components/LiveWaveCanvas.tsx';
import { useApp } from '../context/AppContext.tsx';
import { useAuth } from '../context/AuthContext.tsx';

interface LandingPageProps {
  onEnterApp: () => void;
  onOpenDeck: () => void;
  onNavigate?: (path: string) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onEnterApp, onOpenDeck, onNavigate }) => {
  const { setShowReferenceModal } = useApp();
  const { user, userProfile } = useAuth();

  // Hands-on Interactive Reality Check Simulation on the Landing Page
  const [demoAvailableMins, setDemoAvailableMins] = useState(375); // 6h 15m default
  const [demoTasks, setDemoTasks] = useState([
    { id: 't1', title: 'Deep Work: Project Phoenix Core Spec', duration: 90, priority: 'critical', category: 'Focus', completed: false },
    { id: 't2', title: 'Client Architecture Review: Acme Corp', duration: 60, priority: 'high', category: 'Meeting', completed: false },
    { id: 't3', title: 'Physical Maintenance: Zone-2 Tempo Run', duration: 45, priority: 'medium', category: 'Health', completed: true },
    { id: 't4', title: 'Data Viz & Analytics Engine Module', duration: 60, priority: 'low', category: 'Growth', completed: false },
    { id: 't5', title: 'Weekly Financial Allocation & Budgeting', duration: 30, priority: 'medium', category: 'Finance', completed: false },
  ]);

  // Mini live AI teaser state
  const [teaserPrompt, setTeaserPrompt] = useState('');
  const [teaserReply, setTeaserReply] = useState<string | null>(null);
  const [isTeaserLoading, setIsTeaserLoading] = useState(false);

  // Active roadmap tab state
  const [activeRoadmapNode, setActiveRoadmapNode] = useState(1);

  // Focus Timer interactive mini preview
  const [miniTimerSeconds, setMiniTimerSeconds] = useState(1500); // 25 mins
  const [isMiniTimerRunning, setIsMiniTimerRunning] = useState(false);

  // Toggle tasks
  const handleToggleTask = (id: string) => {
    setDemoTasks((prev) =>
      prev.map((t) => (t.id === id ? { ...t, completed: !t.completed } : t))
    );
  };

  const totalPlannedMins = demoTasks.reduce((acc, t) => acc + t.duration, 0);
  const completedMins = demoTasks.filter((t) => t.completed).reduce((acc, t) => acc + t.duration, 0);
  const remainingMins = totalPlannedMins - completedMins;
  const netDeltaMins = demoAvailableMins - remainingMins;
  const isOverCapacity = netDeltaMins < 0;

  const formatHoursMins = (mins: number) => {
    const h = Math.floor(Math.abs(mins) / 60);
    const m = Math.abs(mins) % 60;
    return `${h > 0 ? `${h}h ` : ''}${m}m`;
  };

  const handleTestAiTeaser = async (text: string) => {
    const q = text.trim();
    if (!q || isTeaserLoading) return;
    setIsTeaserLoading(true);

    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: q,
          userContext: {
            displayName: 'Alex Morgan',
            level: 24,
            xp: 6420,
            todayDate: '2026-10-20',
            availableMinutes: demoAvailableMins,
            workload: {
              availableMinutes: demoAvailableMins,
              plannedMinutes: totalPlannedMins,
              remainingMinutes: remainingMins,
              diffMinutes: netDeltaMins,
              status: isOverCapacity ? 'over_capacity' : 'balanced',
            },
            scheduledTasksToday: demoTasks.map((t) => ({
              title: t.title,
              estimatedMinutes: t.duration,
              priority: t.priority,
              status: t.completed ? 'completed' : 'todo',
            })),
          },
        }),
      });

      const data = await res.json();
      if (data && data.reply) {
        setTeaserReply(data.reply);
      }
    } catch {
      setTeaserReply(
        `[IRL.OS Advisory]: You have ${remainingMins}m of pending work against a ${formatHoursMins(demoAvailableMins)} window. Prioritize "Deep Work: Project Phoenix" first and defer low-priority tasks.`
      );
    } finally {
      setIsTeaserLoading(false);
    }
  };

  const roadmapMilestones = [
    { id: 0, title: '01. Architecture Foundation', status: 'Completed', criteria: 'Data schema & persistence verification', progress: 100 },
    { id: 1, title: '02. Deterministic Engine', status: 'Active Focus', criteria: 'Workload arithmetic & Next Best Move ranking', progress: 85 },
    { id: 2, title: '03. Live Gemini Advisor', status: 'In Validation', criteria: 'Server-side key security & tactical chat', progress: 60 },
    { id: 3, title: '04. Production Verification', status: 'Scheduled', criteria: 'Browser integration tests & user telemetry', progress: 0 },
  ];

  return (
    <div className="min-h-screen bg-[#07080C] text-[#F4F5FA] flex flex-col relative selection:bg-[#A78BFA] selection:text-black">
      {/* Top Navbar */}
      <header className="h-20 px-6 sm:px-12 border-b border-[#252B3B]/70 bg-[#07080C]/85 backdrop-blur-md flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#A78BFA] via-[#8B5CF6] to-[#67E8F9] flex items-center justify-center shadow-lg shadow-violet-500/20">
            <span className="font-mono text-black font-extrabold text-sm tracking-wider">IRL</span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-lg font-bold tracking-tight text-[#F4F5FA]">IRL.OS</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#121622] text-[#67E8F9] border border-[#252B3B]">
                Personal OS
              </span>
            </div>
            <p className="text-[10px] font-mono text-[#939BB0] hidden sm:block">
              Capacity-constrained personal operating system
            </p>
          </div>
        </div>

        <nav className="hidden md:flex items-center gap-7 text-xs font-mono tracking-wider uppercase text-[#939BB0]">
          <a href="#simulator" className="hover:text-[#F4F5FA] transition-colors flex items-center gap-1.5">
            <Activity size={13} className="text-[#67E8F9]" />
            <span>Interactive Simulator</span>
          </a>
          <a href="#architecture" className="hover:text-[#F4F5FA] transition-colors flex items-center gap-1.5">
            <Layers size={13} className="text-[#A78BFA]" />
            <span>System Architecture</span>
          </a>
          <a href="#roadmaps" className="hover:text-[#F4F5FA] transition-colors">
            <span>Milestone Roadmaps</span>
          </a>
          <button
            onClick={onOpenDeck}
            className="px-3 py-1.5 rounded-lg bg-[#181D2B] text-[#67E8F9] hover:text-white border border-[#252B3B] transition-all flex items-center gap-1.5 font-bold"
          >
            <Maximize2 size={12} />
            <span>Master 1-Page Deck</span>
          </button>
        </nav>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowReferenceModal(true)}
            className="hidden sm:flex text-xs font-mono text-[#939BB0] hover:text-[#67E8F9] transition-colors items-center gap-1.5"
          >
            <LayoutGrid size={14} />
            <span>UI Spec Board</span>
          </button>

          {user ? (
            <button
              onClick={onEnterApp}
              className="px-4 py-2 rounded-xl bg-[#121622] hover:bg-[#181D2B] border border-cyan-500/40 text-cyan-300 font-semibold text-xs transition-all flex items-center gap-2 cursor-pointer"
            >
              <div className="w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_8px_#06B6D4]" />
              <span>Enter Command ({userProfile?.displayName?.split(' ')[0] || 'OS'})</span>
              <ArrowRight size={13} />
            </button>
          ) : (
            <>
              <button
                onClick={() => (onNavigate ? onNavigate('/signin') : onEnterApp())}
                className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-white/80 hover:text-white text-xs font-medium border border-white/10 transition-colors cursor-pointer"
              >
                Sign In
              </button>
              <button
                onClick={() => (onNavigate ? onNavigate('/signup') : onEnterApp())}
                className="px-4.5 py-2 rounded-xl bg-gradient-to-r from-cyan-400 via-teal-300 to-cyan-300 text-black font-extrabold text-xs tracking-tight shadow-lg shadow-cyan-500/20 hover:opacity-95 active:scale-95 transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <span>Create Account</span>
                <ArrowRight size={14} />
              </button>
            </>
          )}
        </div>
      </header>

      {/* HERO SECTION: Authentic, High-Craft, Living Blue Wave Canvas */}
      <section className="relative pt-16 pb-24 px-6 sm:px-12 flex flex-col items-center text-center overflow-hidden">
        {/* Full-bleed Live Blue Wave Canvas with Interactive Ripple */}
        <div className="absolute inset-0 z-0 opacity-45 overflow-hidden pointer-events-auto">
          <LiveWaveCanvas className="w-full h-full" intensity={1.15} showParticles={true} />
        </div>

        <div className="relative z-10 max-w-4xl flex flex-col items-center">
          <div className="inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full bg-[#121622]/90 border border-[#A78BFA]/50 text-xs font-mono text-[#A78BFA] mb-6 shadow-md backdrop-blur-md">
            <span className="w-2 h-2 rounded-full bg-[#67E8F9] animate-pulse" />
            <span className="text-[#F4F5FA] font-medium">IRL.OS v1.2</span>
            <span className="text-[#939BB0]">•</span>
            <span>Deterministic Capacity & Execution Engine</span>
          </div>

          <h1 className="text-4xl sm:text-6xl md:text-7xl font-extrabold tracking-tight text-[#F4F5FA] leading-[1.06]">
            Your life. Your system. <br />
            <span className="bg-gradient-to-r from-[#A78BFA] via-[#C084FC] to-[#67E8F9] bg-clip-text text-transparent">
              Your next move.
            </span>
          </h1>

          <p className="mt-6 text-base sm:text-lg text-[#939BB0] max-w-2xl leading-relaxed">
            Every task manager asks what you want to achieve. None of them ask if you have the hours to do it.
            IRL.OS calculates real available time, connects daily tasks to verifiable milestone roadmaps, and
            surfaces your single highest-leverage next move.
          </p>

          <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
            {user ? (
              <button
                onClick={onEnterApp}
                className="px-8 py-4 rounded-xl bg-gradient-to-r from-cyan-400 via-teal-300 to-cyan-300 text-black font-extrabold text-sm shadow-xl shadow-cyan-500/30 hover:opacity-95 active:scale-95 transition-all flex items-center gap-2.5 cursor-pointer"
              >
                <span>Enter Command Center</span>
                <ArrowRight size={17} />
              </button>
            ) : (
              <button
                onClick={() => (onNavigate ? onNavigate('/signup') : onEnterApp())}
                className="px-8 py-4 rounded-xl bg-gradient-to-r from-cyan-400 via-teal-300 to-cyan-300 text-black font-extrabold text-sm shadow-xl shadow-cyan-500/30 hover:opacity-95 active:scale-95 transition-all flex items-center gap-2.5 cursor-pointer"
              >
                <span>Create Free IRL.OS Account</span>
                <ArrowRight size={17} />
              </button>
            )}

            <button
              onClick={onOpenDeck}
              className="px-6 py-4 rounded-xl bg-[#121622]/90 hover:bg-[#181D2B] text-[#F4F5FA] border border-[#252B3B] font-semibold text-sm transition-all flex items-center gap-2.5 backdrop-blur-md cursor-pointer"
            >
              <Maximize2 size={16} className="text-[#67E8F9]" />
              <span>Live System Sandbox</span>
            </button>

            <a
              href="#simulator"
              className="px-5 py-4 rounded-xl bg-transparent hover:bg-[#121622]/50 text-[#939BB0] hover:text-[#F4F5FA] text-xs font-mono transition-all flex items-center gap-2"
            >
              <Sliders size={14} className="text-[#A78BFA]" />
              <span>Jump to Interactive Simulator ↓</span>
            </a>
          </div>
        </div>
      </section>

      {/* SECTION 2: INTERACTIVE REALITY CHECK SIMULATOR (Hands-on, NOT AI slop) */}
      <section id="simulator" className="py-20 px-6 sm:px-12 border-t border-[#252B3B] bg-[#0A0D14] relative z-10">
        <div className="max-w-5xl mx-auto space-y-8">
          <div className="text-center max-w-2xl mx-auto">
            <span className="text-xs font-mono uppercase tracking-wider text-[#67E8F9] font-bold">
              Hands-On Demonstration
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-[#F4F5FA] tracking-tight mt-1.5">
              Turn Ambition into Arithmetic.
            </h2>
            <p className="text-xs sm:text-sm text-[#939BB0] mt-2 leading-relaxed">
              Drag the daily availability slider below or check off tasks. Watch the Reality Check gauge
              dynamically recalculate capacity limits in real time.
            </p>
          </div>

          {/* Interactive Operating Window Box */}
          <div className="rounded-2xl bg-[#121622] border border-[#252B3B] p-6 sm:p-8 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-80 h-32 bg-[#A78BFA]/10 rounded-full blur-3xl pointer-events-none" />

            {/* Simulated System Header Bar */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-[#252B3B]">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#181D2B] border border-[#A78BFA]/50 flex items-center justify-center font-bold text-xs text-[#A78BFA]">
                  AM
                </div>
                <div>
                  <div className="text-sm font-bold text-[#F4F5FA] flex items-center gap-2">
                    <span>Alex Morgan</span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#090A0F] text-[#4ADE80] border border-[#4ADE80]/30">
                      Live Simulation
                    </span>
                  </div>
                  <div className="text-[11px] font-mono text-[#67E8F9]">Level 24 Operator • 6,420 XP</div>
                </div>
              </div>

              {/* Slider for Daily Available Window */}
              <div className="flex flex-col sm:flex-row sm:items-center gap-3 bg-[#090A0F] px-4 py-2.5 rounded-xl border border-[#252B3B]">
                <div className="flex items-center gap-2">
                  <Clock size={15} className="text-[#A78BFA]" />
                  <span className="text-xs font-mono text-[#939BB0]">Daily Available Window:</span>
                  <span className="text-xs font-mono font-bold text-[#67E8F9]">
                    {formatHoursMins(demoAvailableMins)}
                  </span>
                </div>
                <input
                  type="range"
                  min="120"
                  max="600"
                  step="15"
                  value={demoAvailableMins}
                  onChange={(e) => setDemoAvailableMins(Number(e.target.value))}
                  className="w-full sm:w-36 accent-[#A78BFA] cursor-pointer"
                />
              </div>
            </div>

            {/* Reality Check Workload Bar */}
            <div className="my-6 p-4 rounded-xl bg-[#090A0F] border border-[#252B3B] space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs font-mono">
                <div className="flex items-center gap-2">
                  <span className="text-[#A78BFA] font-bold uppercase">Reality Check Workload:</span>
                  <span className="text-[#939BB0]">
                    Available: {formatHoursMins(demoAvailableMins)} | Remaining: {formatHoursMins(remainingMins)}
                  </span>
                </div>
                <span
                  className={`font-bold px-2.5 py-0.5 rounded ${
                    isOverCapacity
                      ? 'bg-[#FB7185]/20 text-[#FB7185] border border-[#FB7185]/30'
                      : 'bg-[#4ADE80]/20 text-[#4ADE80] border border-[#4ADE80]/30'
                  }`}
                >
                  {isOverCapacity
                    ? `-${formatHoursMins(netDeltaMins)} Over plan! Consider replanning.`
                    : `+${formatHoursMins(netDeltaMins)} Safe capacity buffer`}
                </span>
              </div>

              {/* Dynamic Capacity Fill Bar */}
              <div className="w-full bg-[#181D2B] h-2.5 rounded-full overflow-hidden relative">
                <div
                  className={`h-full rounded-full transition-all duration-300 ${
                    isOverCapacity ? 'bg-[#FB7185]' : 'bg-gradient-to-r from-[#A78BFA] to-[#67E8F9]'
                  }`}
                  style={{
                    width: `${Math.min(100, Math.round((remainingMins / demoAvailableMins) * 100))}%`,
                  }}
                />
              </div>
            </div>

            {/* Today Tasks Interactive Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Task Checklist (7 cols) */}
              <div className="lg:col-span-7 space-y-2">
                <div className="flex items-center justify-between text-xs font-mono text-[#939BB0] mb-1">
                  <span>Dayboard Tasks (Click to toggle completion)</span>
                  <span>{completedMins}m / {totalPlannedMins}m done</span>
                </div>

                {demoTasks.map((t) => (
                  <div
                    key={t.id}
                    onClick={() => handleToggleTask(t.id)}
                    className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                      t.completed
                        ? 'bg-[#090A0F]/50 border-[#252B3B] opacity-60'
                        : 'bg-[#181D2B] border-[#252B3B] hover:border-[#A78BFA]/50'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-5 h-5 rounded border flex items-center justify-center transition-colors ${
                          t.completed ? 'bg-[#4ADE80] border-[#4ADE80] text-black font-bold' : 'border-[#939BB0]/40'
                        }`}
                      >
                        {t.completed && <CheckCircle2 size={13} />}
                      </div>
                      <div>
                        <div
                          className={`text-xs font-semibold ${
                            t.completed ? 'line-through text-[#939BB0]' : 'text-[#F4F5FA]'
                          }`}
                        >
                          {t.title}
                        </div>
                        <div className="text-[10px] font-mono text-[#939BB0]">{t.category}</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2.5 text-[11px] font-mono">
                      <span className="text-[#67E8F9]">{t.duration}m</span>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] ${
                          t.priority === 'critical'
                            ? 'bg-[#FB7185]/20 text-[#FB7185]'
                            : t.priority === 'high'
                            ? 'bg-[#FBBF24]/20 text-[#FBBF24]'
                            : 'bg-[#090A0F] text-[#939BB0]'
                        }`}
                      >
                        {t.priority}
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Next Best Move Algorithmic Box (5 cols) */}
              <div className="lg:col-span-5 flex flex-col justify-between p-5 rounded-xl bg-gradient-to-br from-[#181D2B] via-[#151926] to-[#121622] border border-[#A78BFA]/40 space-y-4">
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono uppercase text-[#A78BFA] font-bold flex items-center gap-1.5">
                      <Zap size={14} className="text-[#A78BFA]" />
                      Next Best Move
                    </span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#A78BFA]/20 text-[#A78BFA]">
                      Algorithmic
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-[#F4F5FA] mt-3">
                    Deep Work: Project Phoenix Core Spec
                  </h3>

                  <p className="text-xs text-[#939BB0] mt-1.5 leading-relaxed">
                    Prioritized because it has critical priority, directly satisfies Milestone #2, and fits
                    within your high-energy morning window.
                  </p>

                  <div className="mt-4 p-3 rounded-lg bg-[#090A0F] border border-[#252B3B] text-[11px] font-mono text-[#939BB0] space-y-1">
                    <div className="flex justify-between">
                      <span>Priority Rank:</span>
                      <span className="text-[#FB7185] font-bold">1 / 5</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Duration Block:</span>
                      <span className="text-[#67E8F9]">90 Minutes</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Linked Milestone:</span>
                      <span className="text-[#F4F5FA]">Engine Integration</span>
                    </div>
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    onClick={onEnterApp}
                    className="w-full py-2.5 rounded-xl bg-[#A78BFA] text-black font-extrabold text-xs flex items-center justify-center gap-2 hover:opacity-95 shadow-lg shadow-violet-500/20"
                  >
                    <Play size={13} fill="currentColor" />
                    <span>Launch This Task in Focus Room</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Bottom Simulation Action Bar */}
            <div className="mt-6 pt-5 border-t border-[#252B3B] flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="text-xs font-mono text-[#939BB0]">
                Like what you see? Enter the full environment with persistent storage and cloud-synced telemetry.
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={onOpenDeck}
                  className="px-4 py-2 rounded-xl bg-[#181D2B] hover:bg-[#252B3B] text-[#F4F5FA] border border-[#252B3B] text-xs font-semibold flex items-center gap-1.5"
                >
                  <Maximize2 size={13} />
                  <span>Open Master Deck</span>
                </button>
                <button
                  onClick={onEnterApp}
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#A78BFA] to-[#8B5CF6] text-black font-extrabold text-xs flex items-center gap-1.5"
                >
                  <span>Enter Application</span>
                  <ArrowRight size={14} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 3: CORE ARCHITECTURAL PILLARS (Authentic Engineering, No AI Slop) */}
      <section id="architecture" className="py-20 px-6 sm:px-12 border-t border-[#252B3B]">
        <div className="max-w-5xl mx-auto space-y-12">
          <div className="text-center max-w-2xl mx-auto">
            <span className="text-xs font-mono uppercase tracking-wider text-[#A78BFA] font-bold">
              Product Architecture
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-[#F4F5FA] tracking-tight mt-1.5">
              Built on Physics, Not Wishful Thinking.
            </h2>
            <p className="text-xs sm:text-sm text-[#939BB0] mt-2">
              Why typical to-do apps and calendar managers break down, and how IRL.OS structures your reality.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 rounded-2xl bg-[#121622] border border-[#252B3B] space-y-4 hover:border-[#A78BFA]/40 transition-colors">
              <div className="w-12 h-12 rounded-xl bg-[#A78BFA]/15 border border-[#A78BFA]/30 flex items-center justify-center text-[#A78BFA]">
                <Clock size={22} />
              </div>
              <div className="text-xs font-mono text-[#A78BFA]">01. THE CAPACITY EQUATION</div>
              <h3 className="text-lg font-bold text-[#F4F5FA]">Arithmetic Over Backlogs</h3>
              <p className="text-xs text-[#939BB0] leading-relaxed">
                When you add 9 hours of tasks to a 4-hour evening, your system has failed before you even begin.
                IRL.OS calculates real available time and alerts you before schedule deficits turn into guilt.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-[#121622] border border-[#252B3B] space-y-4 hover:border-[#67E8F9]/40 transition-colors">
              <div className="w-12 h-12 rounded-xl bg-[#67E8F9]/15 border border-[#67E8F9]/30 flex items-center justify-center text-[#67E8F9]">
                <Target size={22} />
              </div>
              <div className="text-xs font-mono text-[#67E8F9]">02. GOAL ROADMAP PIPELINES</div>
              <h3 className="text-lg font-bold text-[#F4F5FA]">Hierarchical Milestone Nodes</h3>
              <p className="text-xs text-[#939BB0] leading-relaxed">
                Goals do not complete because calendar dates pass. They complete when tangible criteria are met.
                Every goal in IRL.OS is a connected milestone node tree with dependent execution gates.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-[#121622] border border-[#252B3B] space-y-4 hover:border-[#4ADE80]/40 transition-colors">
              <div className="w-12 h-12 rounded-xl bg-[#4ADE80]/15 border border-[#4ADE80]/30 flex items-center justify-center text-[#4ADE80]">
                <Sparkles size={22} />
              </div>
              <div className="text-xs font-mono text-[#4ADE80]">03. GROUND-TRUTH AI ADVISOR</div>
              <h3 className="text-lg font-bold text-[#F4F5FA]">Shared Gemini Flash Intelligence</h3>
              <p className="text-xs text-[#939BB0] leading-relaxed">
                No cheerleading bots. The AI Perspective uses a system-owned Gemini API key to audit your real
                scheduled tasks, past completion velocity, and workload conflicts with objective clarity.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 4: INTERACTIVE MILESTONE ROADMAP INSPECTOR */}
      <section id="roadmaps" className="py-20 px-6 sm:px-12 border-t border-[#252B3B] bg-[#0A0D14]">
        <div className="max-w-5xl mx-auto space-y-8">
          <div className="text-center max-w-2xl mx-auto">
            <span className="text-xs font-mono uppercase tracking-wider text-[#67E8F9] font-bold">
              Visual Roadmaps
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-[#F4F5FA] tracking-tight mt-1.5">
              Inspect Your Goal Pipelines.
            </h2>
            <p className="text-xs sm:text-sm text-[#939BB0] mt-2">
              Click milestone nodes below to see how IRL.OS turns high-level visions into verifiable sequence steps.
            </p>
          </div>

          <div className="p-6 sm:p-8 rounded-2xl bg-[#121622] border border-[#252B3B] space-y-6">
            {/* Interactive Milestone Nodes Ribbon */}
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              {roadmapMilestones.map((node) => {
                const isSelected = activeRoadmapNode === node.id;
                return (
                  <div
                    key={node.id}
                    onClick={() => setActiveRoadmapNode(node.id)}
                    className={`p-4 rounded-xl border cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-[#181D2B] border-[#A78BFA] shadow-lg shadow-violet-500/10'
                        : 'bg-[#090A0F] border-[#252B3B] hover:border-[#67E8F9]/40'
                    }`}
                  >
                    <div className="flex items-center justify-between text-[11px] font-mono mb-2">
                      <span className={isSelected ? 'text-[#67E8F9] font-bold' : 'text-[#939BB0]'}>
                        Node 0{node.id + 1}
                      </span>
                      <span
                        className={`px-1.5 py-0.5 rounded text-[9px] ${
                          node.progress === 100
                            ? 'bg-[#4ADE80]/20 text-[#4ADE80]'
                            : node.progress > 0
                            ? 'bg-[#A78BFA]/20 text-[#A78BFA]'
                            : 'bg-[#181D2B] text-[#939BB0]'
                        }`}
                      >
                        {node.status}
                      </span>
                    </div>
                    <div className="text-xs font-bold text-[#F4F5FA]">{node.title}</div>
                    <div className="w-full bg-[#181D2B] h-1 rounded-full overflow-hidden mt-3">
                      <div
                        className="bg-gradient-to-r from-[#A78BFA] to-[#67E8F9] h-full rounded-full transition-all"
                        style={{ width: `${node.progress}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Selected Node Details Display */}
            <div className="p-5 rounded-xl bg-[#090A0F] border border-[#252B3B] flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <div className="text-xs font-mono text-[#A78BFA] uppercase">Active Milestone Gate</div>
                <div className="text-base font-bold text-[#F4F5FA] mt-0.5">
                  {roadmapMilestones[activeRoadmapNode].title}
                </div>
                <div className="text-xs text-[#939BB0] mt-1 font-mono">
                  Completion Criterion: {roadmapMilestones[activeRoadmapNode].criteria}
                </div>
              </div>

              <button
                onClick={onEnterApp}
                className="px-5 py-2.5 rounded-xl bg-[#181D2B] hover:bg-[#252B3B] text-[#F4F5FA] border border-[#252B3B] text-xs font-semibold flex items-center gap-2 self-start md:self-auto"
              >
                <span>View Full Roadmaps in App</span>
                <ChevronRight size={14} />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 5: LIVE AI PERSPECTIVE TEST BED ON LANDING PAGE */}
      <section className="py-20 px-6 sm:px-12 border-t border-[#252B3B] relative z-10">
        <div className="max-w-4xl mx-auto space-y-6">
          <div className="text-center max-w-2xl mx-auto">
            <span className="text-xs font-mono uppercase tracking-wider text-[#A78BFA] font-bold flex items-center justify-center gap-1.5">
              <Sparkles size={14} />
              Live AI Perspective Sandbox
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-[#F4F5FA] tracking-tight mt-1.5">
              Test Real Objective Guidance.
            </h2>
            <p className="text-xs sm:text-sm text-[#939BB0] mt-2">
              Powered by the server-side application Gemini API key. Zero setup required by visitors.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-[#121622] border border-[#A78BFA]/50 shadow-2xl space-y-4">
            <div className="flex flex-wrap items-center gap-2 text-xs font-mono">
              <span className="text-[#939BB0]">Try asking:</span>
              <button
                onClick={() => handleTestAiTeaser('Am I overloaded with 5 tasks today?')}
                className="px-2.5 py-1 rounded-lg bg-[#090A0F] border border-[#252B3B] text-[#67E8F9] hover:border-[#67E8F9]"
              >
                "Am I overloaded today?"
              </button>
              <button
                onClick={() => handleTestAiTeaser('What is my single highest leverage task?')}
                className="px-2.5 py-1 rounded-lg bg-[#090A0F] border border-[#252B3B] text-[#A78BFA] hover:border-[#A78BFA]"
              >
                "What is my next best move?"
              </button>
            </div>

            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Ask the AI advisor about schedule conflicts or priorities..."
                value={teaserPrompt}
                onChange={(e) => setTeaserPrompt(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleTestAiTeaser(teaserPrompt)}
                className="flex-1 px-4 py-3 rounded-xl bg-[#090A0F] border border-[#252B3B] text-xs text-[#F4F5FA] focus:outline-none focus:border-[#A78BFA]"
              />
              <button
                onClick={() => handleTestAiTeaser(teaserPrompt || 'What is my next best move?')}
                disabled={isTeaserLoading}
                className="px-5 py-3 rounded-xl bg-gradient-to-r from-[#A78BFA] to-[#8B5CF6] text-black font-extrabold text-xs flex items-center gap-2 hover:opacity-95 disabled:opacity-50"
              >
                {isTeaserLoading ? (
                  <span className="animate-pulse">Thinking...</span>
                ) : (
                  <>
                    <span>Ask AI</span>
                    <Send size={13} />
                  </>
                )}
              </button>
            </div>

            {teaserReply && (
              <div className="p-4 rounded-xl bg-[#090A0F] border border-[#252B3B] text-xs text-[#F4F5FA] leading-relaxed font-mono whitespace-pre-wrap">
                {teaserReply}
              </div>
            )}
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="mt-auto py-12 px-6 sm:px-12 border-t border-[#252B3B] bg-[#07080C] flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#939BB0] relative z-10">
        <div className="flex items-center gap-3">
          <div className="w-6 h-6 rounded-lg bg-[#181D2B] border border-[#A78BFA]/50 flex items-center justify-center font-bold text-[10px] text-[#A78BFA]">
            IRL
          </div>
          <span className="font-bold text-[#F4F5FA]">IRL.OS</span>
          <span>© 2026 Personal Operating System</span>
        </div>

        <div className="flex items-center gap-5">
          <button
            onClick={() => setShowReferenceModal(true)}
            className="hover:text-[#67E8F9] transition-colors font-mono"
          >
            UI Spec Board
          </button>
          <button
            onClick={onOpenDeck}
            className="hover:text-[#A78BFA] transition-colors font-mono"
          >
            Master 1-Page Deck
          </button>
          <button
            onClick={onEnterApp}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#A78BFA] to-[#8B5CF6] text-black font-bold text-xs hover:opacity-95 transition-all"
          >
            Launch Command Center →
          </button>
        </div>
      </footer>
    </div>
  );
};
