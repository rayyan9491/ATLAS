import React from 'react';
import { Plus, Sparkles, Calendar, Menu, X, LayoutGrid, LogOut, User as UserIcon } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { useAuth } from '../context/AuthContext.tsx';

interface HeaderProps {
  title: string;
  subtitle?: string;
  onOpenAddTask: () => void;
  onOpenAddGoal?: () => void;
  onToggleMobileMenu?: () => void;
  isMobileMenuOpen?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  title,
  subtitle,
  onOpenAddTask,
  onOpenAddGoal,
  onToggleMobileMenu,
  isMobileMenuOpen,
}) => {
  const { todayDate, setTodayDate, hasAiConfigured, setShowReferenceModal, userStats } = useApp();
  const { user, userProfile, signOut } = useAuth();

  return (
    <header className="h-16 px-6 border-b border-[#252B3B] bg-[#090A0F]/80 backdrop-blur-md flex items-center justify-between sticky top-0 z-30">
      <div className="flex items-center gap-4">
        {onToggleMobileMenu && (
          <button
            onClick={onToggleMobileMenu}
            className="md:hidden p-2 rounded-lg bg-[#121622] text-[#939BB0] hover:text-[#F4F5FA] border border-[#252B3B]"
            aria-label="Toggle Navigation Menu"
          >
            {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        )}
        <div>
          <h1 className="text-lg font-bold text-[#F4F5FA] tracking-tight flex items-center gap-2">
            {title}
          </h1>
          {subtitle && <p className="text-xs text-[#939BB0] hidden sm:block">{subtitle}</p>}
        </div>
      </div>

      <div className="flex items-center gap-3">
        {/* Date Selector */}
        <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#121622] border border-[#252B3B] text-xs font-mono text-[#F4F5FA]">
          <Calendar size={14} className="text-[#A78BFA]" />
          <input
            type="date"
            value={todayDate}
            onChange={(e) => setTodayDate(e.target.value)}
            className="bg-transparent text-[#F4F5FA] outline-none cursor-pointer text-xs"
          />
        </div>

        {/* Reference Board shortcut */}
        <button
          onClick={() => setShowReferenceModal(true)}
          className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#121622] hover:bg-[#181D2B] text-xs font-medium text-[#67E8F9] border border-[#67E8F9]/30 transition-all"
        >
          <LayoutGrid size={14} />
          <span>Spec Board</span>
        </button>

        {/* AI Status Badge */}
        <div
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium border ${
            hasAiConfigured
              ? 'bg-[#181D2B] border-[#A78BFA]/50 text-[#A78BFA]'
              : 'bg-[#121622] border-[#252B3B] text-[#939BB0]'
          }`}
          title={
            hasAiConfigured
              ? 'Gemini 3.8 Flash integrated server-side'
              : 'Deterministic algorithms active. Set GEMINI_API_KEY for AI Perspective.'
          }
        >
          <Sparkles size={13} className={hasAiConfigured ? 'text-[#A78BFA]' : 'text-[#939BB0]'} />
          <span className="hidden md:inline font-mono text-[11px]">
            {hasAiConfigured ? 'Gemini Active' : 'Deterministic'}
          </span>
        </div>

        {/* Action Buttons */}
        {onOpenAddGoal && (
          <button
            onClick={onOpenAddGoal}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#121622] hover:bg-[#181D2B] text-xs font-medium text-[#F4F5FA] border border-[#252B3B] transition-colors"
          >
            <Plus size={14} />
            <span>Add Goal</span>
          </button>
        )}

        <button
          onClick={onOpenAddTask}
          className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-[#A78BFA] to-[#8B5CF6] hover:opacity-95 text-xs font-semibold text-black shadow-md shadow-violet-500/20 transition-all active:scale-95 cursor-pointer"
        >
          <Plus size={15} />
          <span>New Task</span>
        </button>

        {/* User Account Pill */}
        {user && (
          <div className="hidden lg:flex items-center gap-2 pl-2 border-l border-[#252B3B]">
            <div className="w-7 h-7 rounded-lg bg-[#181D2B] border border-[#A78BFA]/50 flex items-center justify-center text-xs font-bold text-[#A78BFA]">
              {(userProfile?.displayName || userStats.displayName || 'A').charAt(0).toUpperCase()}
            </div>
            <div className="text-left text-xs leading-none">
              <div className="font-semibold text-white truncate max-w-[100px]">
                {userProfile?.displayName || userStats.displayName}
              </div>
              <div className="text-[10px] text-white/40 truncate max-w-[100px] font-mono mt-0.5">
                {user.email?.split('@')[0]}
              </div>
            </div>
            <button
              onClick={() => signOut()}
              title="Sign Out"
              className="p-1.5 rounded-lg text-white/40 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
            >
              <LogOut size={13} />
            </button>
          </div>
        )}
      </div>
    </header>
  );
};
