import React, { useState } from 'react';
import {
  Target,
  Plus,
  ArrowRight,
  CheckCircle,
  Clock,
  Layers,
  Flag,
  Calendar,
  MoreVertical,
  Trash2,
  ChevronRight,
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { Goal, GoalCategory, Priority } from '../types/index.ts';

interface GoalsPageProps {
  onNavigate: (path: string) => void;
  onOpenGoalModal: () => void;
}

export const GoalsPage: React.FC<GoalsPageProps> = ({ onNavigate, onOpenGoalModal }) => {
  const { goals, deleteGoal, tasks } = useApp();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const categories = ['all', 'career', 'learning', 'fitness', 'creative', 'finance', 'lifestyle'];

  const filteredGoals =
    selectedCategory === 'all' ? goals : goals.filter((g) => g.category === selectedCategory);

  const getPriorityStyle = (priority: Priority) => {
    switch (priority) {
      case 'critical':
        return 'text-[#FB7185] bg-[#FB7185]/15 border-[#FB7185]/40';
      case 'high':
        return 'text-[#FBBF24] bg-[#FBBF24]/15 border-[#FBBF24]/40';
      case 'medium':
        return 'text-[#A78BFA] bg-[#A78BFA]/15 border-[#A78BFA]/40';
      default:
        return 'text-[#939BB0] bg-[#181D2B] border-[#252B3B]';
    }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-[#252B3B]">
        <div>
          <div className="text-xs font-mono text-[#A78BFA] uppercase tracking-wider font-semibold">
            Goal Architecture & Roadmaps
          </div>
          <h2 className="text-2xl font-extrabold text-[#F4F5FA] tracking-tight mt-0.5">
            Active Life Ambitions
          </h2>
          <p className="text-xs text-[#939BB0] mt-1">
            Connect high-level ambitions directly to concrete milestones, tasks, and daily execution.
          </p>
        </div>

        <button
          onClick={onOpenGoalModal}
          className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#A78BFA] to-[#8B5CF6] text-black font-semibold text-xs shadow-md shadow-violet-500/20 hover:opacity-95 transition-all flex items-center gap-2 self-start sm:self-auto"
        >
          <Plus size={15} />
          <span>New Goal Ambition</span>
        </button>
      </div>

      {/* Category filter tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs font-mono">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3 py-1.5 rounded-xl capitalize transition-all border shrink-0 ${
              selectedCategory === cat
                ? 'bg-[#181D2B] text-[#A78BFA] border-[#A78BFA]/50 font-bold'
                : 'bg-[#121622] text-[#939BB0] border-[#252B3B] hover:text-[#F4F5FA]'
            }`}
          >
            {cat === 'all' ? 'All Goals' : cat}
          </button>
        ))}
      </div>

      {/* Goal Cards Grid with distinct visual hierarchies */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredGoals.map((goal, idx) => {
          const completedMilestones = goal.milestones.filter((m) => m.status === 'completed').length;
          const totalMilestones = Math.max(1, goal.milestones.length);
          const percent = Math.round((completedMilestones / totalMilestones) * 100);

          const linkedTasks = tasks.filter((t) => t.goalId === goal.id);
          const completedTasksCount = linkedTasks.filter((t) => t.status === 'completed').length;

          // Find current next milestone
          const currentMilestone =
            goal.milestones.find((m) => m.status === 'in_progress') ||
            goal.milestones.find((m) => m.status !== 'completed');

          const isFeatured = idx === 0 || goal.priority === 'critical';

          return (
            <div
              key={goal.id}
              className={`rounded-2xl border transition-all flex flex-col justify-between p-6 relative overflow-hidden ${
                isFeatured
                  ? 'bg-gradient-to-br from-[#121622] via-[#151A29] to-[#181D2B] border-[#A78BFA]/40 shadow-lg shadow-violet-500/5'
                  : 'bg-[#121622] border-[#252B3B] hover:border-[#A78BFA]/30'
              }`}
            >
              {isFeatured && (
                <div className="absolute top-0 right-0 w-36 h-36 bg-[#A78BFA]/10 rounded-full blur-2xl pointer-events-none" />
              )}

              <div>
                {/* Header row */}
                <div className="flex items-start justify-between gap-4 mb-3">
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded-full uppercase font-bold border ${getPriorityStyle(
                        goal.priority
                      )}`}
                    >
                      {goal.priority}
                    </span>
                    <span className="text-[11px] font-mono text-[#67E8F9] px-2 py-0.5 rounded-md bg-[#181D2B]">
                      {goal.category}
                    </span>
                  </div>

                  {goal.deadline && (
                    <span className="text-[11px] font-mono text-[#939BB0] flex items-center gap-1">
                      <Calendar size={12} className="text-[#A78BFA]" />
                      <span>{goal.deadline}</span>
                    </span>
                  )}
                </div>

                {/* Title & Description */}
                <h3
                  onClick={() => onNavigate(`/app/goals/${goal.id}`)}
                  className="text-lg font-bold text-[#F4F5FA] hover:text-[#A78BFA] cursor-pointer tracking-tight transition-colors"
                >
                  {goal.title}
                </h3>
                <p className="text-xs text-[#939BB0] mt-1.5 line-clamp-2 leading-relaxed">
                  {goal.description}
                </p>

                {/* Progress bar */}
                <div className="mt-5 space-y-1.5">
                  <div className="flex justify-between items-center text-xs font-mono">
                    <span className="text-[#939BB0]">Milestone Progress</span>
                    <span className="font-bold text-[#67E8F9]">{percent}%</span>
                  </div>
                  <div className="w-full bg-[#090A0F] h-2 rounded-full overflow-hidden border border-[#252B3B]">
                    <div
                      className="bg-gradient-to-r from-[#A78BFA] to-[#67E8F9] h-full rounded-full transition-all duration-500"
                      style={{ width: `${percent}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-[10px] font-mono text-[#939BB0]">
                    <span>
                      {completedMilestones} of {totalMilestones} milestones reached
                    </span>
                    <span>
                      {completedTasksCount} / {linkedTasks.length} tasks executed
                    </span>
                  </div>
                </div>

                {/* Current Active Milestone Node */}
                {currentMilestone && (
                  <div className="mt-4 p-3 rounded-xl bg-[#090A0F] border border-[#252B3B] text-xs">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="w-2 h-2 rounded-full bg-[#67E8F9] animate-pulse" />
                      <span className="font-mono text-[10px] uppercase text-[#67E8F9] font-semibold">
                        Next Milestone Node
                      </span>
                    </div>
                    <div className="font-medium text-[#F4F5FA] truncate">
                      #{currentMilestone.order}: {currentMilestone.title}
                    </div>
                    {currentMilestone.criteria && (
                      <p className="text-[11px] text-[#939BB0] mt-0.5 line-clamp-1">
                        Criteria: {currentMilestone.criteria}
                      </p>
                    )}
                  </div>
                )}
              </div>

              {/* Bottom Card Actions */}
              <div className="mt-6 pt-3 border-t border-[#252B3B] flex items-center justify-between">
                <button
                  onClick={() => onNavigate(`/app/goals/${goal.id}`)}
                  className="text-xs font-semibold text-[#A78BFA] hover:text-[#C084FC] flex items-center gap-1.5 transition-colors"
                >
                  <span>Open Interactive Goal Map</span>
                  <ArrowRight size={14} />
                </button>

                <button
                  onClick={() => {
                    if (confirm(`Delete goal "${goal.title}"?`)) {
                      deleteGoal(goal.id);
                    }
                  }}
                  className="p-1.5 rounded-lg text-[#939BB0] hover:text-[#FB7185] hover:bg-[#181D2B] transition-colors"
                  title="Delete goal"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
