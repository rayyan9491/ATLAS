import React from 'react';
import { X, ExternalLink, Check, Sparkles, LayoutGrid } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';

// Image reference generated in accordance with requirement
const REFERENCE_IMAGE_PATH = '/src/assets/images/irl_os_reference_board_1792506954328.jpg';

export const ReferenceBoardModal: React.FC = () => {
  const { showReferenceModal, setShowReferenceModal } = useApp();

  if (!showReferenceModal) return null;

  const screens = [
    { name: '1. LANDING PAGE', route: '/', desc: 'Public identity, value proposition, and hero preview' },
    { name: '2. TODAY DASHBOARD', route: '/app/today', desc: 'Command center, Reality Check dial, Next Best Move' },
    { name: '3. GOALS PAGE', route: '/app/goals', desc: 'Tiered goals with milestone status, categories, priority' },
    { name: '4. GOAL ROADMAP MAP', route: '/app/goals/:id', desc: 'Interactive node graph connecting milestones and tasks' },
    { name: '5. WEEKLY PLANNER', route: '/app/plan', desc: 'Daily workload meters, multi-day scheduling, replan' },
    { name: '6. FOCUS ROOM', route: '/app/focus', desc: 'Distraction-free single task timer and actual log' },
    { name: '7. REALITY REPORT', route: '/app/insights', desc: 'Progress velocity, completion rates, weekly digest' },
    { name: '8. AI PERSPECTIVE', route: '/app/coach', desc: 'Gemini adviser with structured recommendations' },
    { name: '9. PROFILE & SETTINGS', route: '/app/settings', desc: 'Progression toggles, data export, and preferences' },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6">
      <div className="w-full max-w-5xl bg-[#121622] border border-[#252B3B] rounded-2xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden animate-in fade-in duration-200">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-[#252B3B] flex items-center justify-between bg-[#0D1018]">
          <div className="flex items-center gap-2.5">
            <LayoutGrid size={20} className="text-[#67E8F9]" />
            <div>
              <h2 className="text-base font-bold text-[#F4F5FA] flex items-center gap-2">
                <span>IRL.OS Multi-Page UI Reference Board</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#181D2B] text-[#A78BFA] border border-[#A78BFA]/30">
                  DESIGN SPEC
                </span>
              </h2>
              <p className="text-xs text-[#939BB0]">
                Design architecture board connecting all live routes to the charcoal, violet & cyan visual system.
              </p>
            </div>
          </div>
          <button
            onClick={() => setShowReferenceModal(false)}
            className="p-1.5 rounded-lg text-[#939BB0] hover:text-[#F4F5FA] hover:bg-[#181D2B] transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-6 overflow-y-auto">
          {/* Visual Reference Image */}
          <div className="rounded-xl border border-[#252B3B] overflow-hidden bg-[#090A0F] shadow-xl relative group">
            <img
              src={REFERENCE_IMAGE_PATH}
              alt="IRL.OS Multi-Page UI Design Reference Board"
              className="w-full h-auto object-cover max-h-[500px]"
            />
            <div className="absolute bottom-3 right-3 px-3 py-1.5 rounded-lg bg-black/80 backdrop-blur-sm border border-[#252B3B] text-[11px] font-mono text-[#67E8F9] flex items-center gap-1.5">
              <Sparkles size={12} />
              <span>Full UI System Reference Board</span>
            </div>
          </div>

          {/* Interactive Screen Mapping Grid */}
          <div>
            <h3 className="text-xs font-mono uppercase tracking-wider text-[#A78BFA] font-bold mb-3">
              IMPLEMENTED ROUTES & SPEC FIDELITY
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {screens.map((s, idx) => (
                <div
                  key={idx}
                  className="p-3.5 rounded-xl bg-[#090A0F] border border-[#252B3B] hover:border-[#A78BFA]/40 transition-colors"
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="font-bold text-xs text-[#F4F5FA]">{s.name}</span>
                    <span className="text-[10px] font-mono text-[#4ADE80] flex items-center gap-1">
                      <Check size={11} />
                      <span>Live</span>
                    </span>
                  </div>
                  <span className="text-[11px] font-mono text-[#67E8F9] block mb-1">{s.route}</span>
                  <p className="text-[11px] text-[#939BB0] leading-snug">{s.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-[#252B3B] bg-[#0D1018] flex items-center justify-between">
          <span className="text-xs text-[#939BB0]">
            Every screen shown on the reference board is fully interactive with live state.
          </span>
          <button
            onClick={() => setShowReferenceModal(false)}
            className="px-4 py-2 rounded-xl bg-[#181D2B] hover:bg-[#252B3B] text-xs font-semibold text-[#F4F5FA] transition-colors"
          >
            Close Reference
          </button>
        </div>
      </div>
    </div>
  );
};
