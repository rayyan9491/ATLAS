import React, { useState } from 'react';
import {
  Clock,
  CheckCircle2,
  AlertTriangle,
  Play,
  MoreVertical,
  Plus,
  Flame,
  ArrowRight,
  Target,
  Edit2,
  Trash2,
  Zap,
  ChevronRight,
  TrendingUp,
  Info,
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { calculateWorkload } from '../utils/workload.ts';
import { Task, DaySlot } from '../types/index.ts';

interface TodayDashboardProps {
  onNavigate: (path: string) => void;
  onOpenTaskModal: (task?: Task | null) => void;
  onOpenReplanModal: () => void;
}

export const TodayDashboard: React.FC<TodayDashboardProps> = ({
  onNavigate,
  onOpenTaskModal,
  onOpenReplanModal,
}) => {
  const {
    tasks,
    goals,
    userStats,
    updateUserStats,
    todayDate,
    toggleTaskComplete,
    deleteTask,
    rescheduleTask,
    setActiveFocusTask,
    setFocusTimer,
  } = useApp();

  const [activeMenuTaskId, setActiveMenuTaskId] = useState<string | null>(null);

  // Available minutes for current date (default 375 = 6h 15m)
  const availableMinutes =
    userStats.dailyAvailability[todayDate] !== undefined
      ? userStats.dailyAvailability[todayDate]
      : userStats.defaultAvailabilityMinutes;

  const workload = calculateWorkload(tasks, availableMinutes, todayDate);

  const formatHoursMins = (mins: number) => {
    const absMins = Math.abs(mins);
    const h = Math.floor(absMins / 60);
    const m = absMins % 60;
    return `${h > 0 ? `${h}h ` : ''}${m}m`;
  };

  const handleIncrementAvailability = (deltaMins: number) => {
    const nextVal = Math.max(30, Math.min(720, availableMinutes + deltaMins));
    updateUserStats({
      dailyAvailability: {
        ...userStats.dailyAvailability,
        [todayDate]: nextVal,
      },
    });
  };

  const handleStartFocus = (task: Task) => {
    setActiveFocusTask(task);
    setFocusTimer({
      isRunning: true,
      secondsElapsed: 0,
      targetMinutes: task.estimatedMinutes || 45,
      activeTaskId: task.id,
    });
    onNavigate('/app/focus');
  };

  const handleDeferTask = (taskId: string) => {
    const todayObj = new Date(todayDate);
    const tomorrowObj = new Date(todayObj.getTime() + 24 * 60 * 60 * 1000);
    const tomorrowStr = tomorrowObj.toISOString().split('T')[0];
    rescheduleTask(taskId, tomorrowStr);
    setActiveMenuTaskId(null);
  };

  const dayTasks = tasks.filter((t) => t.scheduledDate === todayDate);
  const completedTasks = dayTasks.filter((t) => t.status === 'completed');
  const pendingTasks = dayTasks.filter((t) => t.status !== 'completed');

  const topNextMoveTask =
    pendingTasks.find((t) => t.slot === 'focus_now') ||
    pendingTasks.find((t) => t.priority === 'critical') ||
    pendingTasks[0];

  const parentGoal = topNextMoveTask?.goalId
    ? goals.find((g) => g.id === topNextMoveTask.goalId)
    : null;

  const percentCompleted =
    dayTasks.length > 0 ? Math.round((completedTasks.length / dayTasks.length) * 100) : 0;

  const totalFocusRecordedMins = completedTasks.reduce(
    (acc, t) => acc + (t.actualMinutes || t.estimatedMinutes || 0),
    0
  );

  const isOver = workload.diffMinutes < 0;

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header Bar matching Reference Mockup */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-2xl bg-[#0D1018] border border-[#252B3B]">
        {/* User profile & level info */}
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-[#181D2B] via-[#252B3B] to-[#A78BFA]/40 border border-[#A78BFA]/50 flex items-center justify-center font-bold text-sm text-[#F4F5FA] shadow-md">
            AM
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-[#F4F5FA]">{userStats.displayName}</h2>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-[#181D2B] text-[#A78BFA] border border-[#252B3B]">
                Level {userStats.level}
              </span>
            </div>
            <div className="flex items-center gap-2 text-xs font-mono text-[#939BB0] mt-0.5">
              <span>{userStats.xp} / 7,500 XP</span>
              <div className="w-24 bg-[#181D2B] h-1.5 rounded-full overflow-hidden inline-block">
                <div
                  className="bg-gradient-to-r from-[#A78BFA] to-[#67E8F9] h-full rounded-full"
                  style={{ width: `${Math.min(100, (userStats.xp / 7500) * 100)}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Top-Right Direct Available Time Quick Controller */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-[#121622] px-3.5 py-2 rounded-xl border border-[#252B3B]">
            <Clock size={15} className="text-[#67E8F9]" />
            <span className="text-xs font-mono text-[#939BB0]">Available Today:</span>
            <button
              onClick={() => handleIncrementAvailability(-15)}
              className="w-6 h-6 rounded bg-[#181D2B] hover:bg-[#252B3B] text-[#F4F5FA] text-xs font-bold flex items-center justify-center"
              title="Decrease available time by 15m"
            >
              -
            </button>
            <span className="text-xs font-mono font-bold text-[#F4F5FA] min-w-[55px] text-center">
              {formatHoursMins(availableMinutes)}
            </span>
            <button
              onClick={() => handleIncrementAvailability(15)}
              className="w-6 h-6 rounded bg-[#181D2B] hover:bg-[#252B3B] text-[#F4F5FA] text-xs font-bold flex items-center justify-center"
              title="Increase available time by 15m"
            >
              +
            </button>
          </div>

          <button
            onClick={() => onOpenTaskModal(null)}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#A78BFA] to-[#8B5CF6] text-black font-semibold text-xs shadow-md shadow-violet-500/20 hover:opacity-95 transition-all flex items-center gap-1.5"
          >
            <Plus size={14} />
            <span>Add Task</span>
          </button>
        </div>
      </div>

      {/* Main Two-Card Row: Reality Check & Next Best Move */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Reality Check Card */}
        <div className="lg:col-span-6 p-6 rounded-2xl bg-[#121622] border border-[#252B3B] flex flex-col justify-between relative overflow-hidden">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-1.5 text-xs font-mono uppercase tracking-wider text-[#A78BFA] font-bold">
              <span>Reality Check</span>
              <Info size={13} className="text-[#939BB0]" />
            </div>

            <button
              onClick={onOpenReplanModal}
              className="text-xs text-[#67E8F9] hover:underline font-mono flex items-center gap-1"
            >
              <Zap size={12} />
              <span>Replan Schedule</span>
            </button>
          </div>

          {/* Metric Row */}
          <div className="grid grid-cols-3 gap-4 mb-4">
            <div>
              <span className="text-[11px] text-[#939BB0] block">Available Time</span>
              <span className="text-xl font-mono font-bold text-[#F4F5FA]">
                {formatHoursMins(availableMinutes)}
              </span>
            </div>

            <div>
              <span className="text-[11px] text-[#939BB0] block">Planned Workload</span>
              <span className="text-xl font-mono font-bold text-[#F4F5FA]">
                {formatHoursMins(workload.plannedMinutes)}
              </span>
            </div>

            <div>
              <span className="text-[11px] text-[#939BB0] block">Delta</span>
              <span
                className={`text-xl font-mono font-bold ${
                  isOver ? 'text-[#FB7185]' : 'text-[#4ADE80]'
                }`}
              >
                {isOver
                  ? `-${formatHoursMins(workload.diffMinutes)}`
                  : `+${formatHoursMins(workload.diffMinutes)}`}
              </span>
              <span className="text-[10px] text-[#939BB0] block">
                {isOver ? 'Over plan' : 'Under plan'}
              </span>
            </div>
          </div>

          {/* Progress Bar & Subtext */}
          <div className="space-y-2">
            <div className="w-full bg-[#090A0F] h-2.5 rounded-full overflow-hidden border border-[#252B3B]">
              <div
                className={`h-full rounded-full transition-all duration-500 ${
                  isOver ? 'bg-[#FB7185]' : 'bg-gradient-to-r from-[#A78BFA] to-[#67E8F9]'
                }`}
                style={{
                  width: `${Math.min(100, Math.round((workload.plannedMinutes / availableMinutes) * 100))}%`,
                }}
              />
            </div>
            <p className="text-xs text-[#939BB0]">
              {isOver
                ? "You're over plan. Consider adjusting your plan or deferring non-urgent items."
                : 'Workload comfortably balances within available hours.'}
            </p>
          </div>
        </div>

        {/* Next Best Move Card */}
        <div className="lg:col-span-6 p-6 rounded-2xl bg-gradient-to-br from-[#121622] via-[#151A29] to-[#181D2B] border border-[#A78BFA]/50 shadow-lg shadow-violet-500/5 flex flex-col justify-between relative overflow-hidden">
          <div className="absolute top-0 right-0 w-48 h-32 bg-[#A78BFA]/10 rounded-full blur-2xl pointer-events-none" />

          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-1.5 text-xs font-mono uppercase tracking-wider text-[#A78BFA] font-bold">
                <Zap size={14} className="text-[#A78BFA]" />
                <span>Next Best Move</span>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#181D2B] border border-[#252B3B] text-[#67E8F9]">
                Single Impact
              </span>
            </div>

            {topNextMoveTask ? (
              <>
                <h3 className="text-lg font-bold text-[#F4F5FA] tracking-tight">
                  {topNextMoveTask.title}
                </h3>
                <div className="flex items-center gap-2 mt-1.5 text-xs text-[#939BB0]">
                  <span className="font-mono text-[#67E8F9]">
                    {topNextMoveTask.estimatedMinutes} min focus block
                  </span>
                  {parentGoal && <span>• Goal: {parentGoal.title}</span>}
                </div>
              </>
            ) : (
              <h3 className="text-base font-bold text-[#4ADE80]">
                All daily priorities completed!
              </h3>
            )}
          </div>

          <div className="pt-4 flex items-center gap-3">
            {topNextMoveTask && (
              <>
                <button
                  onClick={() => handleStartFocus(topNextMoveTask)}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#A78BFA] to-[#8B5CF6] text-black font-semibold text-xs shadow-md shadow-violet-500/20 hover:opacity-95 transition-all flex items-center gap-2"
                >
                  <Play size={14} fill="currentColor" />
                  <span>Start Focus</span>
                </button>
                <button
                  onClick={() => toggleTaskComplete(topNextMoveTask.id)}
                  className="px-4 py-2.5 rounded-xl bg-[#181D2B] hover:bg-[#252B3B] text-xs font-semibold text-[#4ADE80] border border-[#4ADE80]/30 transition-colors"
                >
                  Complete (+{topNextMoveTask.xpReward} XP)
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Main Grid: Today Task List + Today's Progress Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Today Task List (Clean linear rows matching reference mockup) */}
        <div className="lg:col-span-8 p-6 rounded-2xl bg-[#0D1018] border border-[#252B3B] space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#252B3B]">
            <h3 className="text-base font-bold text-[#F4F5FA] tracking-tight">Today</h3>
            <span className="text-xs font-mono text-[#939BB0]">
              {completedTasks.length} / {dayTasks.length} Completed
            </span>
          </div>

          <div className="space-y-2.5">
            {dayTasks.map((t) => {
              const isCompleted = t.status === 'completed';
              const pGoal = t.goalId ? goals.find((g) => g.id === t.goalId) : null;

              return (
                <div
                  key={t.id}
                  className={`p-3.5 rounded-xl border flex items-center justify-between gap-3 transition-all ${
                    isCompleted
                      ? 'bg-[#121622]/40 border-[#252B3B] opacity-60'
                      : 'bg-[#121622] border-[#252B3B] hover:border-[#A78BFA]/40'
                  }`}
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    <button
                      onClick={() => toggleTaskComplete(t.id)}
                      className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 transition-colors ${
                        isCompleted
                          ? 'bg-[#A78BFA] border-[#A78BFA] text-black font-bold'
                          : 'border-[#939BB0]/40 hover:border-[#A78BFA]'
                      }`}
                    >
                      {isCompleted && <CheckCircle2 size={13} />}
                    </button>

                    <div className="min-w-0">
                      <div
                        onClick={() => onOpenTaskModal(t)}
                        className={`text-sm font-semibold truncate cursor-pointer ${
                          isCompleted ? 'line-through text-[#939BB0]' : 'text-[#F4F5FA]'
                        }`}
                      >
                        {t.title}
                      </div>
                      {pGoal && (
                        <span className="text-[10px] font-mono text-[#A78BFA] block">
                          {pGoal.title}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0 text-xs font-mono">
                    <span className="text-[#67E8F9] flex items-center gap-1">
                      <Clock size={12} />
                      <span>{t.estimatedMinutes}m</span>
                    </span>

                    <span className="px-2 py-0.5 rounded bg-[#181D2B] text-[#939BB0] capitalize text-[11px]">
                      {t.priority}
                    </span>

                    <button
                      onClick={() => handleStartFocus(t)}
                      className="p-1 rounded text-[#939BB0] hover:text-[#A78BFA]"
                      title="Focus on this task"
                    >
                      <ChevronRight size={16} />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Today's Progress & Streak Widget */}
        <div className="lg:col-span-4 space-y-6">
          <div className="p-6 rounded-2xl bg-[#121622] border border-[#252B3B] space-y-5">
            <h4 className="text-xs font-mono uppercase tracking-wider text-[#939BB0] font-bold">
              Today's Progress
            </h4>

            {/* Circular Gauge */}
            <div className="flex items-center gap-5">
              <div className="relative w-20 h-20 flex items-center justify-center shrink-0">
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                  <circle
                    cx="50"
                    cy="50"
                    r="40"
                    stroke="#181D2B"
                    strokeWidth="8"
                    fill="transparent"
                  />
                  <circle
                    cx="50"
                    cy="50"
                    r="40"
                    stroke="#A78BFA"
                    strokeWidth="8"
                    fill="transparent"
                    strokeDasharray="251.2"
                    strokeDashoffset={251.2 - (251.2 * percentCompleted) / 100}
                    strokeLinecap="round"
                    className="transition-all duration-700"
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center font-mono font-bold text-base text-[#F4F5FA]">
                  {percentCompleted}%
                </div>
              </div>

              <div className="space-y-1 text-xs">
                <div className="text-[#F4F5FA]">
                  <span className="text-[#939BB0]">Tasks completed: </span>
                  <span className="font-mono font-bold">{completedTasks.length} / {dayTasks.length}</span>
                </div>
                <div className="text-[#F4F5FA]">
                  <span className="text-[#939BB0]">Focus time: </span>
                  <span className="font-mono font-bold">{formatHoursMins(totalFocusRecordedMins)}</span>
                </div>
                <div className="text-[#F4F5FA]">
                  <span className="text-[#939BB0]">XP earned: </span>
                  <span className="font-mono font-bold text-[#67E8F9]">320 XP</span>
                </div>
              </div>
            </div>

            {/* Streak Counter with Mini Weekly Sparkline */}
            <div className="pt-4 border-t border-[#252B3B] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Flame size={20} className="text-[#FB7185] animate-pulse" />
                <div>
                  <span className="font-mono text-base font-bold text-[#F4F5FA]">12</span>
                  <span className="text-xs text-[#939BB0] ml-1">Day Streak</span>
                </div>
              </div>

              {/* Mini 7-day sparkline bar */}
              <div className="flex items-end gap-1 h-8">
                {[60, 80, 95, 70, 100, 85, 90].map((h, i) => (
                  <div
                    key={i}
                    className="w-1.5 bg-[#A78BFA] rounded-t-sm"
                    style={{ height: `${h}%` }}
                    title={`Day ${i + 1}`}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Bottom XP Notification Banner matching reference image */}
          <div className="p-4 rounded-xl bg-gradient-to-r from-[#181D2B] to-[#121622] border border-[#A78BFA]/40 flex items-center justify-between text-xs font-mono">
            <span className="text-[#A78BFA] font-bold">You earned 320 XP today</span>
            <span className="text-[#67E8F9] font-bold">4,820 / 7,500 XP +</span>
          </div>
        </div>
      </div>
    </div>
  );
};
