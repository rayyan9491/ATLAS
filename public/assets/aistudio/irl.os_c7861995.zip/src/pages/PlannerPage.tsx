import React, { useState } from 'react';
import {
  Calendar,
  Clock,
  Plus,
  ArrowRight,
  ArrowLeft,
  Zap,
  CheckCircle2,
  AlertTriangle,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { calculateWorkload } from '../utils/workload.ts';
import { Task } from '../types/index.ts';

interface PlannerPageProps {
  onNavigate: (path: string) => void;
  onOpenTaskModal: (task?: Task | null) => void;
  onOpenReplanModal: () => void;
}

export const PlannerPage: React.FC<PlannerPageProps> = ({
  onNavigate,
  onOpenTaskModal,
  onOpenReplanModal,
}) => {
  const {
    tasks,
    goals,
    userStats,
    updateUserStats,
    todayDate,
    setTodayDate,
    rescheduleTask,
    toggleTaskComplete,
  } = useApp();

  // Generate 7 days starting from 2026-10-19 (Monday)
  const baseDate = new Date('2026-10-19T00:00:00Z');
  const days = Array.from({ length: 7 }).map((_, i) => {
    const d = new Date(baseDate.getTime() + i * 24 * 60 * 60 * 1000);
    const dateStr = d.toISOString().split('T')[0];
    const dayName = d.toLocaleDateString('en-US', { weekday: 'short' });
    const monthDay = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    return { dateStr, dayName, monthDay };
  });

  const [activeDayStr, setActiveDayStr] = useState<string>(todayDate);

  const handleMoveTaskDay = (taskId: string, currentDayStr: string, deltaDays: number) => {
    const d = new Date(currentDayStr);
    const target = new Date(d.getTime() + deltaDays * 24 * 60 * 60 * 1000);
    const newDateStr = target.toISOString().split('T')[0];
    rescheduleTask(taskId, newDateStr);
  };

  const handleUpdateDayAvailability = (dateStr: string, minutes: number) => {
    updateUserStats({
      dailyAvailability: {
        ...userStats.dailyAvailability,
        [dateStr]: minutes,
      },
    });
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header with week navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-[#252B3B]">
        <div>
          <div className="text-xs font-mono text-[#A78BFA] uppercase tracking-wider font-semibold">
            Capacity-Aware Weekly Schedule
          </div>
          <h2 className="text-2xl font-extrabold text-[#F4F5FA] tracking-tight mt-0.5">
            Planner & Workload Balance
          </h2>
          <p className="text-xs text-[#939BB0] mt-1">
            Distribute tasks across real-world available windows without overloading individual days.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenReplanModal}
            className="px-3.5 py-2 rounded-xl bg-[#121622] hover:bg-[#181D2B] text-xs font-medium text-[#67E8F9] border border-[#67E8F9]/30 transition-colors flex items-center gap-1.5"
          >
            <Zap size={14} />
            <span>Adaptive Replan</span>
          </button>
          <button
            onClick={() => onOpenTaskModal(null)}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#A78BFA] to-[#8B5CF6] text-black font-semibold text-xs shadow-md shadow-violet-500/20 hover:opacity-95 transition-all flex items-center gap-1.5"
          >
            <Plus size={14} />
            <span>Schedule Task</span>
          </button>
        </div>
      </div>

      {/* Week Grid Columns */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-7 gap-3">
        {days.map((day) => {
          const isToday = day.dateStr === todayDate;
          const isSelected = day.dateStr === activeDayStr;

          const dayAvailableMinutes =
            userStats.dailyAvailability[day.dateStr] !== undefined
              ? userStats.dailyAvailability[day.dateStr]
              : userStats.defaultAvailabilityMinutes;

          const dayWorkload = calculateWorkload(tasks, dayAvailableMinutes, day.dateStr);
          const dayTasks = tasks.filter((t) => t.scheduledDate === day.dateStr);

          const isOverCapacity = dayWorkload.status === 'over_capacity';

          return (
            <div
              key={day.dateStr}
              className={`rounded-2xl border transition-all flex flex-col justify-between p-3.5 ${
                isToday
                  ? 'bg-[#151A29] border-[#A78BFA]/60 ring-1 ring-[#A78BFA]/30'
                  : 'bg-[#121622] border-[#252B3B]'
              }`}
            >
              {/* Day Header */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-xs text-[#F4F5FA]">{day.dayName}</span>
                    <span className="text-[11px] font-mono text-[#939BB0]">{day.monthDay}</span>
                  </div>
                  {isToday && (
                    <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-[#A78BFA] text-black font-bold">
                      TODAY
                    </span>
                  )}
                </div>

                {/* Workload Capacity Meter */}
                <div className="p-2 rounded-xl bg-[#090A0F] border border-[#252B3B] mb-3 space-y-1">
                  <div className="flex justify-between items-center text-[10px] font-mono">
                    <span className="text-[#939BB0]">Workload</span>
                    <span
                      className={`font-bold ${
                        isOverCapacity
                          ? 'text-[#FB7185]'
                          : dayWorkload.status === 'under_capacity'
                          ? 'text-[#67E8F9]'
                          : 'text-[#A78BFA]'
                      }`}
                    >
                      {dayWorkload.percentUtilized}%
                    </span>
                  </div>
                  <div className="w-full bg-[#181D2B] h-1.5 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        isOverCapacity ? 'bg-[#FB7185]' : 'bg-gradient-to-r from-[#A78BFA] to-[#67E8F9]'
                      }`}
                      style={{ width: `${Math.min(100, dayWorkload.percentUtilized)}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-[9px] font-mono text-[#939BB0]">
                    <span>{dayWorkload.remainingMinutes}m work</span>
                    <button
                      onClick={() => {
                        const newTime = prompt(
                          `Set available minutes for ${day.dayName}:`,
                          String(dayAvailableMinutes)
                        );
                        if (newTime && !isNaN(Number(newTime))) {
                          handleUpdateDayAvailability(day.dateStr, Number(newTime));
                        }
                      }}
                      className="text-[#67E8F9] hover:underline"
                    >
                      {dayAvailableMinutes}m cap
                    </button>
                  </div>
                </div>

                {/* Task Cards in this Day */}
                <div className="space-y-2">
                  {dayTasks.map((t) => {
                    const isCompleted = t.status === 'completed';
                    return (
                      <div
                        key={t.id}
                        className={`p-2.5 rounded-xl border text-xs group transition-all relative ${
                          isCompleted
                            ? 'bg-[#090A0F]/60 border-[#252B3B] opacity-70'
                            : 'bg-[#181D2B] border-[#252B3B] hover:border-[#A78BFA]/40'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-1.5 mb-1">
                          <button
                            onClick={() => toggleTaskComplete(t.id)}
                            className={`w-3.5 h-3.5 rounded border mt-0.5 shrink-0 flex items-center justify-center ${
                              isCompleted
                                ? 'bg-[#4ADE80] border-[#4ADE80]'
                                : 'border-[#939BB0]/40'
                            }`}
                          >
                            {isCompleted && <CheckCircle2 size={10} className="text-black" />}
                          </button>
                          <span
                            onClick={() => onOpenTaskModal(t)}
                            className={`font-semibold cursor-pointer truncate flex-1 ${
                              isCompleted ? 'line-through text-[#939BB0]' : 'text-[#F4F5FA]'
                            }`}
                          >
                            {t.title}
                          </span>
                        </div>

                        <div className="flex items-center justify-between text-[10px] font-mono text-[#939BB0]">
                          <span className="text-[#67E8F9]">{t.estimatedMinutes}m</span>
                          <span className="uppercase text-[#A78BFA]">{t.priority}</span>
                        </div>

                        {/* Move day controls */}
                        <div className="mt-2 pt-1 border-t border-[#252B3B] flex items-center justify-between text-[10px] text-[#939BB0]">
                          <button
                            onClick={() => handleMoveTaskDay(t.id, day.dateStr, -1)}
                            className="p-1 hover:text-[#F4F5FA] hover:bg-[#121622] rounded"
                            title="Move to previous day"
                          >
                            <ChevronLeft size={12} />
                          </button>
                          <span className="text-[9px]">Move</span>
                          <button
                            onClick={() => handleMoveTaskDay(t.id, day.dateStr, 1)}
                            className="p-1 hover:text-[#F4F5FA] hover:bg-[#121622] rounded"
                            title="Move to next day"
                          >
                            <ChevronRight size={12} />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Bottom day action */}
              <button
                onClick={() => {
                  setTodayDate(day.dateStr);
                  onOpenTaskModal(null);
                }}
                className="mt-3 py-1.5 rounded-lg bg-[#090A0F] hover:bg-[#181D2B] text-[11px] text-[#939BB0] hover:text-[#F4F5FA] border border-[#252B3B] flex items-center justify-center gap-1 transition-colors"
              >
                <Plus size={11} />
                <span>Add Task</span>
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};
